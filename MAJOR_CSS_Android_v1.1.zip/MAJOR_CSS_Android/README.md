# MAJOR CSS — Android Native v1.1

Нативный Android-клиент турнира MAJOR CSS (Kotlin + Jetpack Compose).

## Реализовано

- **Регистрация через приложение** — вкладка «Рег.»: название, тег, контакт, состав до 5 игроков → `POST /api/register`
- **Авторизация администраторов** — вкладка «Админ»: пароль → `POST /api/admin/login`, токен хранится локально
- **Полноценная турнирная сетка** — Single Elimination, раунды/матчи/счёт/победитель. Если сервер отдаёт `matches` — показываются они; иначе строится локальная предварительная сетка по списку команд
- **Управление турниром** (только админ):
  - открыть/закрыть регистрацию (`POST /api/admin/reg`)
  - сгенерировать сетку (`POST /api/admin/bracket/generate`)
  - ввести результат матча прямо в сетке (`POST /api/admin/match`)
- **Подключение к опубликованному серверу** — Настройки → HTTPS (или HTTP) базовый URL
- Навигация: Главная / Команды / Сетка / Рег. / Админ / Настр.
- Тёмная тема MAJOR CSS (чёрный/красный)

## Ожидаемый контракт API сервера

```
GET  /api/data
  → { site: { teams[], news[], prizes[], schedule[], cfg: { size }, regOpen, matches?, bracketGenerated? } }

POST /api/register
  body: { team, tag, contact, players: string[] }
  → { message }

POST /api/admin/login
  body: { password }
  → { token }

POST /api/admin/reg          Authorization: Bearer <token>
  body: { regOpen: boolean }

POST /api/admin/bracket/generate
  → { message }

POST /api/admin/match
  body: { id, score1, score2 }
```

Поле `matches` (массив):
```
{ id, round, slot, team1, team2, score1?, score2?, winner? }
```

## Сборка APK (финальная)

1. Установите **Android Studio** (поддержка AGP 8.7.3+).
2. Откройте папку `MAJOR_CSS_Android` как проект.
3. Дождитесь Gradle Sync (JDK 17, Android SDK 35).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Готовый файл: `app/build/outputs/apk/debug/app-debug.apk`.

Для release-сборки создайте keystore и настройте `signingConfigs` в `app/build.gradle.kts`.

## Подключение к серверу

После публикации Node.js-бэкенда с HTTPS:

1. Приложение → **Настр.**
2. Введите базовый адрес, например `https://major-css.example.com` (без `/api/data`).
3. «Сохранить и подключиться».

## Архитектура

```
Android (Kotlin/Compose)
    ↓ HTTPS
Node.js API  →  SQLite major.db
```

Не коммитьте SQLite, пароли администратора и секреты в репозиторий.

Версия приложения: **1.1.0**
