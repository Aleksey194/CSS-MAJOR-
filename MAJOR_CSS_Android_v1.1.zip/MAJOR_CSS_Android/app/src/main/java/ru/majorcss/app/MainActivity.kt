package ru.majorcss.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF08090B)
private val Panel = Color(0xFF14161B)
private val Red = Color(0xFFE32636)
private val Muted = Color(0xFFA3A5AD)
private val White = Color(0xFFF4F4F5)
private val Green = Color(0xFF79C98A)
private val Orange = Color(0xFFF0A500)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MajorCssApp(this) }
    }
}

data class MajorData(
    val teams: List<String> = emptyList(),
    val news: List<Pair<String, String>> = emptyList(),
    val prizes: List<Pair<String, String>> = emptyList(),
    val schedule: List<Pair<String, String>> = emptyList(),
    val size: Int = 64,
    val regOpen: Boolean = true,
    val matches: List<Match> = emptyList(),
    val bracketGenerated: Boolean = false
)

data class Match(
    val id: String,
    val round: Int,
    val slot: Int,
    val team1: String?,
    val team2: String?,
    val score1: Int?,
    val score2: Int?,
    val winner: String?
)

data class RegisterResult(val ok: Boolean, val message: String)
data class LoginResult(val ok: Boolean, val token: String?, val message: String)

private class MajorApi(private val context: Context) {
    private val prefs = context.getSharedPreferences("major_css", Context.MODE_PRIVATE)

    fun baseUrl(): String = prefs.getString("server_url", "") ?: ""
    fun saveBaseUrl(value: String) {
        prefs.edit().putString("server_url", value.trim().trimEnd('/')).apply()
    }

    fun adminToken(): String = prefs.getString("admin_token", "") ?: ""
    fun saveAdminToken(token: String) {
        prefs.edit().putString("admin_token", token).apply()
    }
    fun clearAdminToken() {
        prefs.edit().remove("admin_token").apply()
    }
    fun isAdmin(): Boolean = adminToken().isNotBlank()

    private fun connection(path: String, method: String = "GET"): HttpURLConnection {
        val base = baseUrl().trim().trimEnd('/')
        require(base.startsWith("https://") || base.startsWith("http://")) {
            "Укажи адрес сервера (https://...) в настройках."
        }
        return (URL("$base$path").openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val token = adminToken()
            if (token.isNotBlank()) setRequestProperty("Authorization", "Bearer $token")
        }
    }

    private fun readBody(conn: HttpURLConnection): String {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        return stream?.bufferedReader()?.use { it.readText() } ?: ""
    }

    suspend fun load(): MajorData = withContext(Dispatchers.IO) {
        val conn = connection("/api/data")
        try {
            val raw = readBody(conn)
            val code = conn.responseCode
            if (code !in 200..299) error("Сервер ответил HTTP $code")
            val root = JSONObject(raw)
            val site = root.optJSONObject("site") ?: JSONObject()
            fun pairs(key: String, a: String, b: String): List<Pair<String, String>> {
                val arr = site.optJSONArray(key) ?: return emptyList()
                return (0 until arr.length()).mapNotNull { i ->
                    val o = arr.optJSONObject(i) ?: return@mapNotNull null
                    o.optString(a) to o.optString(b)
                }
            }
            val teamArr = site.optJSONArray("teams")
            val teams = if (teamArr == null) emptyList()
            else (0 until teamArr.length()).map { teamArr.optString(it) }

            val cfg = site.optJSONObject("cfg") ?: JSONObject()
            val matches = parseMatches(site.optJSONArray("matches") ?: root.optJSONArray("matches"))
            MajorData(
                teams = teams,
                news = pairs("news", "title", "text"),
                prizes = pairs("prizes", "place", "sum"),
                schedule = pairs("schedule", "stage", "when"),
                size = cfg.optInt("size", 64),
                regOpen = site.optBoolean("regOpen", true),
                matches = matches,
                bracketGenerated = matches.isNotEmpty() || site.optBoolean("bracketGenerated", false)
            )
        } finally {
            conn.disconnect()
        }
    }

    private fun parseMatches(arr: JSONArray?): List<Match> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Match(
                id = o.optString("id", "m$i"),
                round = o.optInt("round", 1),
                slot = o.optInt("slot", i),
                team1 = o.optString("team1").takeIf { it.isNotBlank() },
                team2 = o.optString("team2").takeIf { it.isNotBlank() },
                score1 = if (o.has("score1") && !o.isNull("score1")) o.optInt("score1") else null,
                score2 = if (o.has("score2") && !o.isNull("score2")) o.optInt("score2") else null,
                winner = o.optString("winner").takeIf { it.isNotBlank() }
            )
        }
    }

    suspend fun registerTeam(
        teamName: String,
        players: List<String>,
        contact: String,
        tag: String = ""
    ): RegisterResult = withContext(Dispatchers.IO) {
        val conn = connection("/api/register", "POST")
        try {
            conn.doOutput = true
            val body = JSONObject().apply {
                put("team", teamName.trim())
                put("tag", tag.trim())
                put("contact", contact.trim())
                put("players", JSONArray(players.map { it.trim() }.filter { it.isNotBlank() }))
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val raw = readBody(conn)
            val code = conn.responseCode
            val msg = try {
                JSONObject(raw).optString("message", raw.ifBlank { "HTTP $code" })
            } catch (_: Exception) {
                raw.ifBlank { "HTTP $code" }
            }
            if (code in 200..299) RegisterResult(true, msg.ifBlank { "Команда зарегистрирована" })
            else RegisterResult(false, msg)
        } catch (e: Exception) {
            RegisterResult(false, e.message ?: "Ошибка сети")
        } finally {
            conn.disconnect()
        }
    }

    suspend fun adminLogin(password: String): LoginResult = withContext(Dispatchers.IO) {
        val conn = connection("/api/admin/login", "POST")
        try {
            conn.doOutput = true
            val body = JSONObject().put("password", password)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val raw = readBody(conn)
            val code = conn.responseCode
            val json = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
            if (code in 200..299) {
                val token = json.optString("token").ifBlank { json.optString("accessToken") }
                if (token.isNotBlank()) {
                    saveAdminToken(token)
                    LoginResult(true, token, "Успешный вход")
                } else {
                    LoginResult(false, null, "Сервер не вернул токен")
                }
            } else {
                LoginResult(false, null, json.optString("message", "Неверный пароль или HTTP $code"))
            }
        } catch (e: Exception) {
            LoginResult(false, null, e.message ?: "Ошибка сети")
        } finally {
            conn.disconnect()
        }
    }

    suspend fun setMatchResult(matchId: String, score1: Int, score2: Int): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            val conn = connection("/api/admin/match", "POST")
            try {
                conn.doOutput = true
                val body = JSONObject().apply {
                    put("id", matchId)
                    put("score1", score1)
                    put("score2", score2)
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val raw = readBody(conn)
                val code = conn.responseCode
                val msg = try {
                    JSONObject(raw).optString("message", raw.ifBlank { "OK" })
                } catch (_: Exception) {
                    raw.ifBlank { "HTTP $code" }
                }
                (code in 200..299) to msg
            } catch (e: Exception) {
                false to (e.message ?: "Ошибка")
            } finally {
                conn.disconnect()
            }
        }

    suspend fun setRegOpen(open: Boolean): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val conn = connection("/api/admin/reg", "POST")
        try {
            conn.doOutput = true
            val body = JSONObject().put("regOpen", open)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val raw = readBody(conn)
            val code = conn.responseCode
            val msg = try {
                JSONObject(raw).optString("message", if (open) "Регистрация открыта" else "Регистрация закрыта")
            } catch (_: Exception) {
                "HTTP $code"
            }
            (code in 200..299) to msg
        } catch (e: Exception) {
            false to (e.message ?: "Ошибка")
        } finally {
            conn.disconnect()
        }
    }

    suspend fun generateBracket(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val conn = connection("/api/admin/bracket/generate", "POST")
        try {
            conn.doOutput = true
            conn.outputStream.use { it.write("{}".toByteArray()) }
            val raw = readBody(conn)
            val code = conn.responseCode
            val msg = try {
                JSONObject(raw).optString("message", "Сетка сгенерирована")
            } catch (_: Exception) {
                "HTTP $code"
            }
            (code in 200..299) to msg
        } catch (e: Exception) {
            false to (e.message ?: "Ошибка")
        } finally {
            conn.disconnect()
        }
    }
}

@Composable
private fun MajorCssApp(context: Context) {
    val api = remember { MajorApi(context) }
    var tab by remember { mutableStateOf("Главная") }
    var data by remember { mutableStateOf(MajorData()) }
    var serverUrl by remember { mutableStateOf(api.baseUrl()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var isAdmin by remember { mutableStateOf(api.isAdmin()) }
    var statusMsg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun refresh() {
        scope.launch {
            loading = true
            statusMsg = ""
            try {
                data = api.load()
                error = ""
            } catch (e: Exception) {
                error = e.message ?: "Не удалось загрузить данные"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (api.baseUrl().isNotBlank()) refresh()
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            background = Bg,
            surface = Panel,
            onBackground = White,
            onSurface = White,
            secondary = Muted
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0D0E11))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .background(Red, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("M", fontSize = 22.sp, fontWeight = FontWeight.Black, color = White)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("MAJOR CSS", fontWeight = FontWeight.Black, letterSpacing = 1.5.sp, fontSize = 17.sp)
                        Text(
                            if (isAdmin) "АДМИН-РЕЖИМ" else "COUNTER SHOT: SOURCE",
                            color = if (isAdmin) Orange else Muted,
                            fontSize = 9.sp,
                            letterSpacing = 1.sp
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    if (loading) {
                        CircularProgressIndicator(Modifier.size(20.dp), color = Red, strokeWidth = 2.dp)
                    } else {
                        IconButton(onClick = { refresh() }) {
                            Icon(Icons.Default.Refresh, "Обновить", tint = White)
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101115), contentColor = White) {
                    val items = listOf(
                        "Главная" to Icons.Default.Home,
                        "Команды" to Icons.Default.Groups,
                        "Сетка" to Icons.Default.AccountTree,
                        "Рег." to Icons.Default.PersonAdd,
                        "Админ" to Icons.Default.AdminPanelSettings,
                        "Настр." to Icons.Default.Settings
                    )
                    items.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = tab == label,
                            onClick = { tab = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 9.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = White,
                                selectedTextColor = White,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted,
                                indicatorColor = Red.copy(alpha = .18f)
                            )
                        )
                    }
                }
            }
        ) { padding ->
            val mod = Modifier.padding(padding)
            when (tab) {
                "Главная" -> HomeScreen(data, error, loading, mod, ::refresh, isAdmin)
                "Команды" -> TeamsScreen(data, mod)
                "Сетка" -> BracketScreen(data, mod, isAdmin, api, scope) { refresh(); statusMsg = it }
                "Рег." -> RegisterScreen(data, mod, api, scope) { refresh(); statusMsg = it }
                "Админ" -> AdminScreen(
                    data, mod, api, isAdmin,
                    onLogin = { isAdmin = true; refresh() },
                    onLogout = { api.clearAdminToken(); isAdmin = false },
                    onAction = { refresh(); statusMsg = it },
                    scope = scope
                )
                else -> SettingsScreen(
                    mod, serverUrl, { serverUrl = it },
                    {
                        api.saveBaseUrl(serverUrl)
                        refresh()
                    },
                    loading, error, isAdmin
                )
            }
            if (statusMsg.isNotBlank()) {
                LaunchedEffect(statusMsg) {
                    kotlinx.coroutines.delay(3500)
                    statusMsg = ""
                }
                Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.BottomCenter) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        modifier = Modifier.padding(16.dp).fillMaxWidth()
                    ) {
                        Text(
                            statusMsg,
                            Modifier.padding(14.dp),
                            color = White,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Column(verticalArrangement = Arrangement.spacedBy(12.dp), content = content) }
    }
}

@Composable
private fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            content = content
        )
    }
}

@Composable
private fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier,
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(value, fontWeight = FontWeight.Black, fontSize = 18.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun PrimaryButton(
    text: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = Red, disabledContainerColor = Red.copy(0.35f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun OutlinedField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    singleLine: Boolean = true,
    password: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = singleLine,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Red,
            unfocusedBorderColor = Muted.copy(0.5f),
            focusedTextColor = White,
            unfocusedTextColor = White,
            focusedLabelColor = Red,
            unfocusedLabelColor = Muted,
            cursorColor = Red
        )
    )
}

@Composable
private fun HomeScreen(
    data: MajorData,
    error: String,
    loading: Boolean,
    modifier: Modifier,
    refresh: () -> Unit,
    isAdmin: Boolean
) {
    Page(modifier) {
        Text("ОФИЦИАЛЬНЫЙ ТУРНИР", color = Red, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, fontSize = 11.sp)
        Text("MAJOR\nCSS", fontSize = 48.sp, lineHeight = 46.sp, fontWeight = FontWeight.Black)
        Text("Это не просто турнир. Это — Major.", color = Muted, fontSize = 14.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("КОМАНДЫ", "${data.teams.size}/${data.size}", Modifier.weight(1f))
            StatCard(
                "РЕГИСТРАЦИЯ",
                if (data.regOpen) "ОТКРЫТА" else "ЗАКРЫТА",
                Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("ФОРМАТ", "SINGLE\nELIM", Modifier.weight(1f))
            StatCard(
                "СЕТКА",
                if (data.bracketGenerated || data.matches.isNotEmpty()) "ГОТОВА" else "НЕТ",
                Modifier.weight(1f)
            )
        }

        CardBlock {
            Text("ПРИЗОВОЙ ФОНД", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("100 000 ₽", color = White, fontSize = 30.sp, fontWeight = FontWeight.Black)
            if (data.prizes.isNotEmpty()) {
                data.prizes.forEach { (place, sum) ->
                    Text("$place — $sum", color = Muted, fontSize = 13.sp)
                }
            } else {
                Text("Общий призовой фонд турнира", color = Muted, fontSize = 12.sp)
            }
        }

        CardBlock {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("СЕРВЕР", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                if (loading) CircularProgressIndicator(Modifier.size(16.dp), color = Red, strokeWidth = 2.dp)
            }
            Text(
                if (error.isBlank()) "Данные загружены" else error,
                color = if (error.isBlank()) Green else Muted,
                fontSize = 13.sp
            )
            if (error.isNotBlank()) {
                TextButton(onClick = refresh) { Text("Повторить", color = Red) }
            }
            if (isAdmin) {
                Text("Вы вошли как администратор", color = Orange, fontSize = 12.sp)
            }
        }

        if (data.schedule.isNotEmpty()) {
            Text("БЛИЖАЙШИЕ ЭТАПЫ", color = Muted, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            data.schedule.take(5).forEach { (a, b) ->
                CardBlock {
                    Text(a, fontWeight = FontWeight.Bold)
                    Text(b, color = Muted, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun TeamsScreen(data: MajorData, modifier: Modifier) {
    Page(modifier) {
        Text("УЧАСТНИКИ", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("${data.teams.size} из ${data.size} команд", color = Muted)
        if (data.teams.isEmpty()) {
            CardBlock { Text("Команды пока не зарегистрированы", color = Muted) }
        } else {
            data.teams.forEachIndexed { index, team ->
                CardBlock {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "%02d".format(index + 1),
                            color = Red,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(team, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun BracketScreen(
    data: MajorData,
    modifier: Modifier,
    isAdmin: Boolean,
    api: MajorApi,
    scope: kotlinx.coroutines.CoroutineScope,
    onStatus: (String) -> Unit
) {
    val matches = data.matches
    val maxRound = matches.maxOfOrNull { it.round } ?: 0
    val displayMatches = if (matches.isNotEmpty()) matches else generateLocalBracket(data.teams, data.size)

    Page(modifier) {
        Text("ТУРНИРНАЯ СЕТКА", fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(
            "Single Elimination · ${data.size} слотов · ${data.teams.size} команд",
            color = Muted,
            fontSize = 13.sp
        )

        if (matches.isEmpty() && data.teams.isNotEmpty()) {
            CardBlock {
                Text("ЛОКАЛЬНАЯ СЕТКА", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(
                    "Сервер ещё не отдал структуру матчей. Показана предварительная сетка по текущему списку команд.",
                    color = Muted,
                    fontSize = 12.sp
                )
            }
        }

        if (displayMatches.isEmpty()) {
            CardBlock {
                Text("Сетка пока пуста", fontWeight = FontWeight.Bold)
                Text(
                    "Зарегистрируйте команды и сгенерируйте сетку в админ-панели.",
                    color = Muted,
                    fontSize = 13.sp
                )
            }
        } else {
            val rounds = displayMatches.groupBy { it.round }.toSortedMap()
            rounds.forEach { (round, list) ->
                val title = when {
                    maxRound > 0 && round == maxRound -> "ФИНАЛ"
                    maxRound > 1 && round == maxRound - 1 -> "ПОЛУФИНАЛ"
                    else -> "РАУНД $round"
                }
                Text(title, fontWeight = FontWeight.Black, fontSize = 14.sp, color = Red)
                list.sortedBy { it.slot }.forEach { m ->
                    MatchCard(m, isAdmin && matches.isNotEmpty(), api, scope, onStatus)
                }
            }
        }
    }
}

@Composable
private fun MatchCard(
    m: Match,
    canEdit: Boolean,
    api: MajorApi,
    scope: kotlinx.coroutines.CoroutineScope,
    onStatus: (String) -> Unit
) {
    var showEdit by remember { mutableStateOf(false) }
    var s1 by remember { mutableStateOf(m.score1?.toString() ?: "") }
    var s2 by remember { mutableStateOf(m.score2?.toString() ?: "") }
    var busy by remember { mutableStateOf(false) }

    CardBlock {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("M${m.slot + 1}", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            if (m.winner != null) {
                Text("Победитель: ${m.winner}", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        TeamLine(m.team1, m.score1, m.winner == m.team1)
        HorizontalDivider(color = Muted.copy(0.2f))
        TeamLine(m.team2, m.score2, m.winner == m.team2)

        if (canEdit) {
            TextButton(onClick = { showEdit = !showEdit }) {
                Text(if (showEdit) "Скрыть" else "Ввести счёт", color = Red, fontSize = 12.sp)
            }
            if (showEdit) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = s1,
                        onValueChange = { s1 = it.filter { c -> c.isDigit() }.take(2) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("Счёт 1") },
                        colors = fieldColors()
                    )
                    OutlinedTextField(
                        value = s2,
                        onValueChange = { s2 = it.filter { c -> c.isDigit() }.take(2) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("Счёт 2") },
                        colors = fieldColors()
                    )
                }
                PrimaryButton("Сохранить результат", enabled = !busy && s1.isNotBlank() && s2.isNotBlank()) {
                    val a = s1.toIntOrNull() ?: return@PrimaryButton
                    val b = s2.toIntOrNull() ?: return@PrimaryButton
                    busy = true
                    scope.launch {
                        val (ok, msg) = api.setMatchResult(m.id, a, b)
                        busy = false
                        onStatus(if (ok) "Результат сохранён" else msg)
                        showEdit = false
                    }
                }
            }
        }
    }
}

@Composable
private fun TeamLine(name: String?, score: Int?, isWinner: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            name ?: "TBD",
            modifier = Modifier.weight(1f),
            fontWeight = if (isWinner) FontWeight.Black else FontWeight.Normal,
            color = if (name == null) Muted else White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (score != null) {
            Text(
                score.toString(),
                fontWeight = FontWeight.Black,
                color = if (isWinner) Green else White,
                fontSize = 16.sp
            )
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Red,
    unfocusedBorderColor = Muted.copy(0.4f),
    focusedTextColor = White,
    unfocusedTextColor = White,
    cursorColor = Red
)

private fun generateLocalBracket(teams: List<String>, size: Int): List<Match> {
    if (teams.isEmpty()) return emptyList()
    var slots = 2
    while (slots < size.coerceAtLeast(2)) slots *= 2
    val padded = teams.toMutableList()
    while (padded.size < slots) padded.add("")
    val list = mutableListOf<Match>()
    var round = 1
    var current = padded
    var matchId = 0
    while (current.size >= 2) {
        val next = mutableListOf<String>()
        for (i in current.indices step 2) {
            val t1 = current.getOrNull(i)?.takeIf { it.isNotBlank() }
            val t2 = current.getOrNull(i + 1)?.takeIf { it.isNotBlank() }
            list.add(
                Match(
                    id = "local-${matchId++}",
                    round = round,
                    slot = i / 2,
                    team1 = t1,
                    team2 = t2,
                    score1 = null,
                    score2 = null,
                    winner = null
                )
            )
            next.add("")
        }
        current = next
        round++
        if (round > 8) break
    }
    return list
}

@Composable
private fun RegisterScreen(
    data: MajorData,
    modifier: Modifier,
    api: MajorApi,
    scope: kotlinx.coroutines.CoroutineScope,
    onDone: (String) -> Unit
) {
    var team by remember { mutableStateOf("") }
    var tag by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf("") }
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var p3 by remember { mutableStateOf("") }
    var p4 by remember { mutableStateOf("") }
    var p5 by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var localMsg by remember { mutableStateOf("") }

    Page(modifier) {
        Text("РЕГИСТРАЦИЯ", fontSize = 26.sp, fontWeight = FontWeight.Black)
        if (!data.regOpen) {
            CardBlock {
                Text("Регистрация закрыта", color = Red, fontWeight = FontWeight.Bold)
                Text("Администратор закрыл приём заявок.", color = Muted, fontSize = 13.sp)
            }
            return@Page
        }

        Text("Заявка на участие в MAJOR CSS", color = Muted)
        CardBlock {
            OutlinedField(team, { team = it }, "Название команды *")
            OutlinedField(tag, { tag = it }, "Тег (короткий)")
            OutlinedField(contact, { contact = it }, "Контакт (Discord / Telegram) *")
            Text("Состав (до 5 игроков)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Muted)
            OutlinedField(p1, { p1 = it }, "Игрок 1 *")
            OutlinedField(p2, { p2 = it }, "Игрок 2")
            OutlinedField(p3, { p3 = it }, "Игрок 3")
            OutlinedField(p4, { p4 = it }, "Игрок 4")
            OutlinedField(p5, { p5 = it }, "Игрок 5")
        }

        if (localMsg.isNotBlank()) {
            Text(localMsg, color = if (localMsg.startsWith("OK")) Green else Muted, fontSize = 13.sp)
        }

        PrimaryButton(
            if (busy) "Отправка…" else "Отправить заявку",
            enabled = !busy && team.isNotBlank() && contact.isNotBlank() && p1.isNotBlank()
        ) {
            busy = true
            localMsg = ""
            scope.launch {
                val players = listOf(p1, p2, p3, p4, p5)
                val res = api.registerTeam(team, players, contact, tag)
                busy = false
                localMsg = if (res.ok) "OK: ${res.message}" else res.message
                if (res.ok) {
                    onDone(res.message)
                    team = ""; tag = ""; contact = ""
                    p1 = ""; p2 = ""; p3 = ""; p4 = ""; p5 = ""
                }
            }
        }

        CardBlock {
            Text("Требования", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(
                "• Команда 1–5 человек\n• Уникальное название\n• Рабочий контакт\n• После регистрации следите за новостями и сеткой",
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun AdminScreen(
    data: MajorData,
    modifier: Modifier,
    api: MajorApi,
    isAdmin: Boolean,
    onLogin: () -> Unit,
    onLogout: () -> Unit,
    onAction: (String) -> Unit,
    scope: kotlinx.coroutines.CoroutineScope
) {
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    Page(modifier) {
        Text("АДМИН-ПАНЕЛЬ", fontSize = 26.sp, fontWeight = FontWeight.Black)

        if (!isAdmin) {
            CardBlock {
                Text("Вход администратора", fontWeight = FontWeight.Bold)
                Text("Пароль задаётся на сервере.", color = Muted, fontSize = 12.sp)
                OutlinedField(password, { password = it }, "Пароль", password = true)
                if (msg.isNotBlank()) Text(msg, color = Muted, fontSize = 13.sp)
                PrimaryButton(if (busy) "Вход…" else "Войти", enabled = !busy && password.isNotBlank()) {
                    busy = true
                    msg = ""
                    scope.launch {
                        val res = api.adminLogin(password)
                        busy = false
                        if (res.ok) {
                            password = ""
                            onLogin()
                            onAction("Вы вошли как администратор")
                        } else {
                            msg = res.message
                        }
                    }
                }
            }
            CardBlock {
                Text("После входа доступны:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(
                    "• Открытие / закрытие регистрации\n• Генерация турнирной сетки\n• Ввод результатов матчей (вкладка Сетка)\n• Управление турниром",
                    color = Muted,
                    fontSize = 12.sp
                )
            }
            return@Page
        }

        CardBlock {
            Text("Сессия администратора активна", color = Green, fontWeight = FontWeight.Bold)
            TextButton(onClick = {
                onLogout()
                onAction("Вы вышли из админ-режима")
            }) {
                Text("Выйти", color = Red)
            }
        }

        CardBlock {
            Text("РЕГИСТРАЦИЯ", fontWeight = FontWeight.Bold)
            Text(
                if (data.regOpen) "Сейчас открыта" else "Сейчас закрыта",
                color = if (data.regOpen) Green else Muted
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        busy = true
                        scope.launch {
                            val (ok, m) = api.setRegOpen(true)
                            busy = false
                            onAction(if (ok) m else "Ошибка: $m")
                        }
                    },
                    enabled = !busy && !data.regOpen,
                    colors = ButtonDefaults.buttonColors(containerColor = Green.copy(0.8f)),
                    modifier = Modifier.weight(1f)
                ) { Text("Открыть") }
                Button(
                    onClick = {
                        busy = true
                        scope.launch {
                            val (ok, m) = api.setRegOpen(false)
                            busy = false
                            onAction(if (ok) m else "Ошибка: $m")
                        }
                    },
                    enabled = !busy && data.regOpen,
                    colors = ButtonDefaults.buttonColors(containerColor = Red),
                    modifier = Modifier.weight(1f)
                ) { Text("Закрыть") }
            }
        }

        CardBlock {
            Text("ТУРНИРНАЯ СЕТКА", fontWeight = FontWeight.Bold)
            Text(
                if (data.matches.isNotEmpty() || data.bracketGenerated)
                    "Сетка уже есть (${data.matches.size} матчей)"
                else
                    "Сетка ещё не сгенерирована",
                color = Muted,
                fontSize = 13.sp
            )
            PrimaryButton(
                if (busy) "Генерация…" else "Сгенерировать сетку",
                enabled = !busy && data.teams.size >= 2
            ) {
                busy = true
                scope.launch {
                    val (ok, m) = api.generateBracket()
                    busy = false
                    onAction(if (ok) m else "Ошибка: $m")
                }
            }
            Text(
                "Минимум 2 команды. Генерация фиксирует состав и создаёт матчи.",
                color = Muted,
                fontSize = 11.sp
            )
        }

        CardBlock {
            Text("БЫСТРАЯ СТАТИСТИКА", fontWeight = FontWeight.Bold)
            Text("Команд: ${data.teams.size} / ${data.size}", color = Muted)
            Text("Матчей в API: ${data.matches.size}", color = Muted)
            Text("Регистрация: ${if (data.regOpen) "открыта" else "закрыта"}", color = Muted)
        }

        CardBlock {
            Text("УПРАВЛЕНИЕ РЕЗУЛЬТАТАМИ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(
                "На вкладке «Сетка» у каждого матча есть кнопка «Ввести счёт» (только для админа).",
                color = Muted,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    url: String,
    onUrl: (String) -> Unit,
    save: () -> Unit,
    loading: Boolean,
    error: String,
    isAdmin: Boolean
) {
    Page(modifier) {
        Text("НАСТРОЙКИ", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("Подключение к опубликованному серверу", color = Muted)

        CardBlock {
            Text("АДРЕС API-СЕРВЕРА", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            OutlinedField(url, onUrl, "https://your-domain.com")
            PrimaryButton(
                if (loading) "Подключение…" else "Сохранить и подключиться",
                enabled = !loading && url.isNotBlank()
            ) { save() }
            Text(
                "Базовый URL без /api/data. Пример: https://major-css.example.com\n" +
                    "После публикации Node.js-сервера с HTTPS приложение сможет регистрировать команды, " +
                    "показывать сетку и управлять турниром.",
                color = Muted,
                fontSize = 12.sp
            )
            if (error.isNotBlank()) {
                Text(error, color = Muted, fontSize = 12.sp)
            }
        }

        CardBlock {
            Text("СТАТУС", fontWeight = FontWeight.Bold)
            Text(
                if (isAdmin) "Администратор авторизован" else "Гостевой режим",
                color = if (isAdmin) Orange else Muted
            )
            Text("Версия приложения: 1.1.0", color = Muted, fontSize = 12.sp)
            Text("Kotlin + Jetpack Compose · minSdk 26", color = Muted, fontSize = 12.sp)
        }

        CardBlock {
            Text("ОЖИДАЕМЫЕ ЭНДПОИНТЫ СЕРВЕРА", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(
                "GET  /api/data\n" +
                    "POST /api/register\n" +
                    "POST /api/admin/login\n" +
                    "POST /api/admin/reg\n" +
                    "POST /api/admin/bracket/generate\n" +
                    "POST /api/admin/match",
                color = Muted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
