# Развёртывание MAJOR CSS на FirstVDS (Ubuntu)

Эта сборка рассчитана на VPS с постоянным диском. Сайт будет запускаться автоматически после перезагрузки сервера. База `major.db` хранится в `/opt/major-css` — не удаляйте эту папку при обновлении.

## 1. Подготовка VPS

Подключитесь по SSH и выполните:

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y nginx curl ca-certificates
```

Установите Node.js 22 LTS или новее (обязательно версия не ниже 22.13). После установки проверьте:

```bash
node -v
which node
```

Шаблон службы предполагает путь `/usr/bin/node`. Если `which node` показывает другой путь, измените `ExecStart` в `deploy/major-css.service`.

## 2. Размещение файлов

Загрузите и распакуйте содержимое папки `major_css_v2` в `/opt/major-css`. Затем выполните:

```bash
sudo mkdir -p /opt/major-css /etc/major-css
sudo useradd --system --home /opt/major-css --shell /usr/sbin/nologin majorcss
sudo chown -R majorcss:majorcss /opt/major-css
```

Не копируйте старую `major.db` поверх новой установки вслепую. Если переносите уже существующий турнир, сначала остановите старый сервер и перенесите все файлы `major.db*` вместе.

## 3. Первый запуск и пароль администратора

Создайте файл окружения:

```bash
sudo nano /etc/major-css/major-css.env
```

Содержимое (замените пароль на свой длинный уникальный пароль):

```ini
HOST=127.0.0.1
PORT=3000
SECURE=1
TRUST_PROXY=1
ADMIN_PASSWORD=ЗАМЕНИТЕ_НА_ДЛИННЫЙ_УНИКАЛЬНЫЙ_ПАРОЛЬ
```

Защитите файл:

```bash
sudo chmod 600 /etc/major-css/major-css.env
sudo chown root:root /etc/major-css/major-css.env
```

`ADMIN_PASSWORD` используется только при самом первом создании администратора. После первого успешного старта удалите эту строку из env-файла, чтобы секрет не оставался в окружении службы. Пароль хранится в базе в виде хэша.

## 4. Автозапуск через systemd

```bash
sudo cp /opt/major-css/deploy/major-css.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now major-css
sudo systemctl status major-css
```

Посмотреть журнал: `sudo journalctl -u major-css -f`. Проверить локальный ответ: `curl -I http://127.0.0.1:3000/`.

## 5. Домен и HTTPS

В DNS домена создайте A-запись на IPv4 VPS. Затем скопируйте `deploy/nginx-major-css.conf` в `/etc/nginx/sites-available/major-css`, замените `major.example.com` на свой домен, включите конфигурацию через ссылку в `sites-enabled`, выполните `sudo nginx -t` и `sudo systemctl reload nginx`.

Установите Certbot и выпустите сертификат для домена. После включения HTTPS проверьте, что в env-файле службы остаются `SECURE=1` и `TRUST_PROXY=1`, затем перезапустите `major-css`. Не открывайте порт 3000 наружу: доступ к Node.js должен идти только через nginx. В firewall откройте SSH, HTTP и HTTPS.

## 6. Резервные копии

Создать копию базы можно без остановки сайта:

```bash
sudo -u majorcss /usr/bin/node /opt/major-css/server.js backup
```

Файлы появятся в `/opt/major-css/backups/`. Скачивайте копии на отдельное устройство/хранилище регулярно: копия на том же VPS не защищает от потери самого VPS.

## 7. Обновление сайта

Перед обновлением создайте резервную копию. Затем остановите службу, замените файлы приложения, не удаляя `major.db*` и `backups/`, восстановите владельца и запустите службу:

```bash
sudo systemctl stop major-css
# Замените файлы приложения, сохранив major.db* и backups/
sudo chown -R majorcss:majorcss /opt/major-css
sudo systemctl start major-css
sudo systemctl status major-css
```

## Важно о регистрации

В этой сборке очереди заявок нет. Автоматически принимается только заявка, для которой в сетке уже есть свободное место. Если мест нет, заявка удаляется и капитан получает сообщение о заполненной сетке. Освободившееся место не отдаётся автоматически ранее ожидающей команде.

Это инструкция-шаблон: точные команды установки Node.js и Certbot зависят от версии Ubuntu и текущей конфигурации VPS.
