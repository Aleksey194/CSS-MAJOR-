// MAJOR CSS — сервер сайта v5.0 (киберспортивная платформа + SQLite)
// Платформа турнира: капитаны, судьи, матчи (единый источник), жеребьёвка, статусы,
// дисквал/walkover, стендинги (без фейкового Elo), экспорт, журнал, статистика игроков, инвайты.
// Без внешних пакетов. Нужен Node.js 22.13 или новее (SQLite встроена в Node).
//
// Запуск:            node server.js
// Задать пароль:     node server.js set-password ЛОГИН ПАРОЛЬ [role]
//   role: owner | deputy_owner | chief_admin | admin | senior_judge | judge |
//         chief_coordinator | coordinator | senior_manager | team_manager |
//         chief_appeals | appeals | media_head | stream_host | commentator |
//         designer | video_editor | pr_manager | captain
//
// Переменные окружения:
//   PORT=3000
//   HOST=127.0.0.1
//   SECURE=1          — если сайт работает по HTTPS
//   TRUST_PROXY=1     — если стоите за nginx / Cloudflare
//   ADMIN_PASSWORD=.. — пароль при первом запуске (иначе генерируется)
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
function findPage() { // находит HTML сайта, даже если файл называется «major_css_site (2).html»
  const l = fs.readdirSync(__dirname).filter(n => /^major_css_site.*\.html$/i.test(n) || n === 'index.html');
  return path.join(__dirname, l.includes('major_css_site.html') ? 'major_css_site.html' : (l[0] || 'major_css_site.html'));
}
const DIR = __dirname, PAGE = findPage(), DB = path.join(DIR, 'data.json'), USERS = path.join(DIR, 'admins.json');
const PORT = +process.env.PORT || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const TZ = 'Europe/Moscow'; // единый часовой пояс сайта
const fmtDT = ms => new Date(ms).toLocaleString('ru-RU', { timeZone: TZ, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }).replace(',', '') + ' МСК';
const dayMSK = (ms = Date.now()) => new Date(ms).toLocaleDateString('sv-SE', { timeZone: TZ });

process.on('uncaughtException', e => console.error('Ошибка:', e && e.message));
process.on('unhandledRejection', e => console.error('Ошибка:', e && e.message));
const readJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
process.removeAllListeners('warning'); // SQLite в Node помечена «экспериментальной» — убираем лишнее предупреждение
process.on('warning', w => { if (w.name !== 'ExperimentalWarning') console.warn(w); });
let DatabaseSync;
try { ({ DatabaseSync } = require('node:sqlite')); } catch { console.error('Нужен Node.js 22.13 или новее (там встроена SQLite). Сейчас: ' + process.version); process.exit(1); }
const DBFILE = path.join(DIR, 'major.db'), fresh = !fs.existsSync(DBFILE);
const sql = new DatabaseSync(DBFILE);
if (fresh) { try { fs.chmodSync(DBFILE, 0o600); } catch {} }
sql.exec(`PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;
CREATE TABLE IF NOT EXISTS site (id INTEGER PRIMARY KEY CHECK (id = 1), json TEXT NOT NULL, updated INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS admins (login TEXT PRIMARY KEY, salt TEXT NOT NULL, hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  login TEXT NOT NULL UNIQUE,
  salt TEXT NOT NULL,
  hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'captain' CHECK (role IN ('admin','captain','judge')),
  name TEXT NOT NULL DEFAULT '',
  contact TEXT NOT NULL DEFAULT '',
  team_id INTEGER,
  created_at INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS users_login ON users(login);
CREATE INDEX IF NOT EXISTS users_role ON users(role);
CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, login TEXT NOT NULL, exp INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  name_norm TEXT NOT NULL UNIQUE,
  logo TEXT DEFAULT '',
  captain_user_id INTEGER,
  roster TEXT NOT NULL DEFAULT '[]',
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  rating INTEGER NOT NULL DEFAULT 1000,
  created_at INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','disqualified','archived'))
);
CREATE INDEX IF NOT EXISTS teams_norm ON teams(name_norm);
CREATE TABLE IF NOT EXISTS regs (
  id TEXT PRIMARY KEY, at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','accepted','rejected')),
  confirmed INTEGER NOT NULL DEFAULT 0, confirmed_at INTEGER, ctoken TEXT NOT NULL UNIQUE,
  team TEXT NOT NULL, team_norm TEXT NOT NULL, captain TEXT NOT NULL, contact TEXT NOT NULL, roster TEXT NOT NULL DEFAULT '',
  user_id INTEGER, team_id INTEGER);
CREATE INDEX IF NOT EXISTS regs_norm ON regs(team_norm);
CREATE INDEX IF NOT EXISTS regs_at ON regs(at DESC);
CREATE INDEX IF NOT EXISTS regs_contact ON regs(lower(contact));
CREATE TABLE IF NOT EXISTS bans (ip TEXT PRIMARY KEY, until INTEGER NOT NULL, reason TEXT, at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  link TEXT DEFAULT '',
  read INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS notif_user ON notifications(user_id, read, created_at DESC);
CREATE TABLE IF NOT EXISTS matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  round INTEGER NOT NULL,
  pos INTEGER NOT NULL,
  team1_id INTEGER,
  team2_id INTEGER,
  winner_id INTEGER,
  score TEXT DEFAULT '',
  judge_id INTEGER,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','live','done','walkover')),
  scheduled_at INTEGER,
  updated_at INTEGER NOT NULL,
  UNIQUE(round, pos)
);
CREATE TABLE IF NOT EXISTS action_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  action TEXT NOT NULL,
  details TEXT DEFAULT '',
  at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS match_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  match_id INTEGER NOT NULL,
  actor_user_id INTEGER,
  action TEXT NOT NULL,
  old_status TEXT DEFAULT '',
  new_status TEXT DEFAULT '',
  old_winner_id INTEGER,
  new_winner_id INTEGER,
  old_score TEXT DEFAULT '',
  new_score TEXT DEFAULT '',
  note TEXT DEFAULT '',
  at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS match_history_match ON match_history(match_id, at DESC);
CREATE TABLE IF NOT EXISTS tournaments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  game TEXT NOT NULL DEFAULT 'Counter Shot: Source',
  format TEXT NOT NULL CHECK (format IN ('single','roundrobin')),
  size INTEGER NOT NULL CHECK (size IN (8,16,32,64)),
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','registration','active','completed','archived')),
  bo INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS tournaments_status ON tournaments(status, created_at DESC);
CREATE TABLE IF NOT EXISTS tournament_teams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  name_norm TEXT NOT NULL,
  seed INTEGER,
  created_at INTEGER NOT NULL,
  UNIQUE(tournament_id, name_norm)
);
CREATE INDEX IF NOT EXISTS tournament_teams_tournament ON tournament_teams(tournament_id, seed, name);
CREATE TABLE IF NOT EXISTS tournament_matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  round INTEGER NOT NULL,
  pos INTEGER NOT NULL,
  team1_id INTEGER,
  team2_id INTEGER,
  winner_team_id INTEGER,
  score TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','done','walkover')),
  updated_at INTEGER NOT NULL,
  UNIQUE(tournament_id, round, pos)
);
CREATE INDEX IF NOT EXISTS tournament_matches_lookup ON tournament_matches(tournament_id, round, pos);
CREATE TABLE IF NOT EXISTS tournament_applications (id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE, team_id INTEGER NOT NULL, captain_user_id INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')), note TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, decided_at INTEGER, decided_by INTEGER, UNIQUE(tournament_id,team_id));
CREATE INDEX IF NOT EXISTS tournament_applications_status ON tournament_applications(tournament_id,status,created_at);
CREATE TABLE IF NOT EXISTS tournament_appeals (id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL, match_id INTEGER NOT NULL, team_id INTEGER NOT NULL, user_id INTEGER NOT NULL, reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','accepted','rejected')), response TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, resolved_at INTEGER, resolved_by INTEGER);
CREATE INDEX IF NOT EXISTS tournament_appeals_status ON tournament_appeals(tournament_id,status,created_at);
CREATE TABLE IF NOT EXISTS tournament_history (id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL, actor_user_id INTEGER, event TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS tournament_history_lookup ON tournament_history(tournament_id,created_at DESC,id DESC);`);
if (!sql.prepare('PRAGMA table_info(tournament_teams)').all().some(c => c.name === 'captain_user_id')) sql.exec('ALTER TABLE tournament_teams ADD COLUMN captain_user_id INTEGER');
if (!sql.prepare('PRAGMA table_info(tournament_matches)').all().some(c => c.name === 'judge_user_id')) sql.exec('ALTER TABLE tournament_matches ADD COLUMN judge_user_id INTEGER');
if (!sql.prepare('PRAGMA table_info(tournament_matches)').all().some(c => c.name === 'scheduled_at')) sql.exec('ALTER TABLE tournament_matches ADD COLUMN scheduled_at INTEGER');
sql.exec('CREATE INDEX IF NOT EXISTS tournament_matches_schedule ON tournament_matches(tournament_id, scheduled_at)');
sql.exec(`CREATE TABLE IF NOT EXISTS tournament_player_stats (id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE, match_id INTEGER NOT NULL REFERENCES tournament_matches(id) ON DELETE CASCADE, team_id INTEGER NOT NULL REFERENCES tournament_teams(id) ON DELETE CASCADE, player_name TEXT NOT NULL, kills INTEGER NOT NULL DEFAULT 0 CHECK(kills>=0), deaths INTEGER NOT NULL DEFAULT 0 CHECK(deaths>=0), assists INTEGER NOT NULL DEFAULT 0 CHECK(assists>=0), mvp INTEGER NOT NULL DEFAULT 0 CHECK(mvp IN (0,1)), created_by INTEGER, updated_at INTEGER NOT NULL, UNIQUE(match_id,team_id,player_name)); CREATE INDEX IF NOT EXISTS tournament_player_stats_tournament ON tournament_player_stats(tournament_id, kills DESC, mvp DESC);`);
const norm = t => String(t).toLowerCase().replace(/\s+/g, ' ').trim();
// Рейтинг игрока: K + 0.5*A + 5*MVP - 0.25*D. Это внутренняя формула платформы, не официальный рейтинг игры.
const playerRating = x => Math.round((Number(x.kills||0) + Number(x.assists||0)*0.5 + Number(x.mvp||0)*5 - Number(x.deaths||0)*0.25)*10)/10;

/* ===== Роли организации MAJOR ===== */
const ROLE_LIST = [
  'owner','deputy_owner','chief_admin','admin',
  'senior_judge','judge',
  'chief_coordinator','coordinator',
  'senior_manager','team_manager',
  'chief_appeals','appeals',
  'media_head','stream_host','commentator','designer','video_editor','pr_manager',
  'captain'
];
const ROLE_LABEL = {
  owner: 'Владелец MAJOR',
  deputy_owner: 'Заместитель владельца',
  chief_admin: 'Главный администратор',
  admin: 'Администратор',
  senior_judge: 'Старший судья',
  judge: 'Судья матчей',
  chief_coordinator: 'Главный координатор',
  coordinator: 'Координатор',
  senior_manager: 'Старший менеджер',
  team_manager: 'Менеджер команд',
  chief_appeals: 'Главный специалист (апелляции)',
  appeals: 'Специалист по апелляции',
  media_head: 'Руководитель медиа',
  stream_host: 'Ведущий трансляции',
  commentator: 'Комментатор',
  designer: 'Дизайнер',
  video_editor: 'Видеомонтажёр',
  pr_manager: 'PR-менеджер',
  captain: 'Капитан команды'
};
const can = (role, perm) => {
  const r = role || '';
  const full = ['owner','deputy_owner','chief_admin','admin'].includes(r);
  if (perm === 'full') return full;
  if (perm === 'manage') return full || ['senior_judge','chief_coordinator'].includes(r);
  if (perm === 'regs') return full || ['senior_judge','chief_coordinator','coordinator','senior_manager','team_manager','chief_appeals','appeals'].includes(r);
  if (perm === 'judge') return full || ['senior_judge','judge'].includes(r);
  if (perm === 'assign_judge') return full || r === 'senior_judge';
  if (perm === 'media') return full || ['media_head','stream_host','commentator','designer','video_editor','pr_manager'].includes(r);
  if (perm === 'users') return full; // создавать учётки только полный доступ
  if (perm === 'staff') return ROLE_LIST.includes(r) && r !== 'captain' || full;
  if (perm === 'captain') return r === 'captain' || full;
  return false;
};
const validRole = r => ROLE_LIST.includes(r) ? r : null;
// Иерархия полных ролей: нельзя создавать или менять роли выше своей, owner — только owner
const RANK = { owner: 4, deputy_owner: 3, chief_admin: 2, admin: 1 }, rankOf = r => RANK[r] || 0;
const mayAssign = (actor, r) => actor === 'owner' || (r !== 'owner' && rankOf(r) <= rankOf(actor));
const csvSafe = v => (typeof v === 'string' && /^[=+\-@\t\r]/.test(v)) ? "'" + v : v; // защита от формул в Excel

// Миграции
if (!sql.prepare('PRAGMA table_info(regs)').all().some(c => c.name === 'consent_at')) sql.exec('ALTER TABLE regs ADD COLUMN consent_at INTEGER');
if (!sql.prepare('PRAGMA table_info(regs)').all().some(c => c.name === 'terms_at')) sql.exec('ALTER TABLE regs ADD COLUMN terms_at INTEGER');
if (!sql.prepare('PRAGMA table_info(regs)').all().some(c => c.name === 'user_id')) sql.exec('ALTER TABLE regs ADD COLUMN user_id INTEGER');
if (!sql.prepare('PRAGMA table_info(regs)').all().some(c => c.name === 'team_id')) sql.exec('ALTER TABLE regs ADD COLUMN team_id INTEGER');

// Расширение ролей: SQLite CHECK нельзя изменить — пересоздаём users при необходимости
(function migrateRoles() {
  try {
    sql.prepare("INSERT INTO users (login, salt, hash, role, name, created_at, active) VALUES ('_role_probe_', 'x', 'x', 'owner', 'x', 0, 0)").run();
    sql.prepare("DELETE FROM users WHERE login = '_role_probe_'").run();
    return; // owner уже допустим
  } catch (e) { /* need rebuild */ }
  try {
    sql.exec(`CREATE TABLE users_v22 (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      login TEXT NOT NULL UNIQUE,
      salt TEXT NOT NULL,
      hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'captain',
      name TEXT NOT NULL DEFAULT '',
      contact TEXT NOT NULL DEFAULT '',
      team_id INTEGER,
      created_at INTEGER NOT NULL,
      active INTEGER NOT NULL DEFAULT 1
    );
    INSERT INTO users_v22 (id, login, salt, hash, role, name, contact, team_id, created_at, active)
      SELECT id, login, salt, hash, role, name, contact, team_id, created_at, active FROM users;
    DROP TABLE users;
    ALTER TABLE users_v22 RENAME TO users;
    CREATE INDEX IF NOT EXISTS users_login ON users(login);
    CREATE INDEX IF NOT EXISTS users_role ON users(role);`);
    console.log('Миграция ролей users: OK');
  } catch (e2) { console.error('Миграция ролей:', e2.message); }
})();
if (!sql.prepare('PRAGMA table_info(matches)').all().some(c => c.name === 'stream_url')) sql.exec('ALTER TABLE matches ADD COLUMN stream_url TEXT DEFAULT \'\'');
if (!sql.prepare('PRAGMA table_info(matches)').all().some(c => c.name === 'note')) sql.exec('ALTER TABLE matches ADD COLUMN note TEXT DEFAULT \'\'');
if (!sql.prepare('PRAGMA table_info(teams)').all().some(c => c.name === 'invite_token')) sql.exec('ALTER TABLE teams ADD COLUMN invite_token TEXT');
if (!sql.prepare('PRAGMA table_info(users)').all().some(c => c.name === 'must_set_password')) {
  sql.exec('ALTER TABLE users ADD COLUMN must_set_password INTEGER NOT NULL DEFAULT 0');
  console.log('Миграция users.must_set_password: OK');
}
sql.exec(`CREATE TABLE IF NOT EXISTS invites (
  token TEXT PRIMARY KEY,
  team_id INTEGER NOT NULL,
  created_by INTEGER,
  created_at INTEGER NOT NULL,
  used_at INTEGER,
  used_by INTEGER
);`);
// Перенос старых админов в users
try {
  const oldAdmins = sql.prepare('SELECT login, salt, hash FROM admins').all();
  for (const a of oldAdmins) {
    const exists = sql.prepare('SELECT id FROM users WHERE login = ?').get(a.login);
    if (!exists) sql.prepare('INSERT INTO users (login, salt, hash, role, name, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(a.login, a.salt, a.hash, 'admin', a.login, Date.now());
  }
} catch (e) {}
const tx = fn => { sql.exec('BEGIN'); try { const r = fn(); sql.exec('COMMIT'); return r; } catch (e) { sql.exec('ROLLBACK'); throw e; } };
const getSite = () => { const r = sql.prepare('SELECT json FROM site WHERE id = 1').get(); return r ? JSON.parse(r.json) : null; };
const putSite = o => sql.prepare('INSERT INTO site (id, json, updated) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET json = excluded.json, updated = excluded.updated').run(JSON.stringify(o), Date.now());
const regRow = r => ({ id: r.id, at: r.at, status: r.status, confirmed: !!r.confirmed, confirmedAt: r.confirmed_at || undefined, ctoken: r.ctoken, team: r.team, captain: r.captain, contact: r.contact, roster: r.roster, user_id: r.user_id, team_id: r.team_id });
const allRegs = () => sql.prepare('SELECT * FROM regs ORDER BY at DESC').all().map(regRow);
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');

// ===== Двухфакторная защита (TOTP, RFC 6238: Google Authenticator, Authy, 1Password и др.) =====
for (const [c, d] of [['totp_secret', 'TEXT'], ['totp_pending', 'TEXT'], ['totp_enabled', 'INTEGER NOT NULL DEFAULT 0'], ['totp_last', 'INTEGER NOT NULL DEFAULT 0'], ['totp_recovery', 'TEXT']])
  if (!sql.prepare('PRAGMA table_info(users)').all().some(x => x.name === c)) sql.exec('ALTER TABLE users ADD COLUMN ' + c + ' ' + d);
const FULL_ROLES = ['owner', 'deputy_owner', 'chief_admin', 'admin'];
const REQUIRE_2FA = /^(1|true|yes)$/i.test(String(process.env.REQUIRE_2FA_ADMINS || '')); // обязательная 2FA для ролей с полным доступом
// Секреты в базе хранятся зашифрованно (AES-256-GCM). Ключ: переменная TOTP_KEY или файл totp.key рядом с server.js.
const TOTP_KEY = (() => {
  if (process.env.TOTP_KEY) return crypto.createHash('sha256').update(String(process.env.TOTP_KEY)).digest();
  const f = path.join(DIR, 'totp.key');
  if (fs.existsSync(f)) { const k = Buffer.from(fs.readFileSync(f, 'utf8').trim(), 'hex'); if (k.length !== 32) throw new Error('totp.key повреждён (нужно 64 hex-символа)'); return k; }
  const k = crypto.randomBytes(32); fs.writeFileSync(f, k.toString('hex'), { mode: 0o600 }); return k;
})();
const encSecret = buf => { const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', TOTP_KEY, iv), ct = Buffer.concat([c.update(buf), c.final()]); return Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64'); };
const decSecret = txt => { try { const b = Buffer.from(String(txt || ''), 'base64'), d = crypto.createDecipheriv('aes-256-gcm', TOTP_KEY, b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); return Buffer.concat([d.update(b.subarray(28)), d.final()]); } catch { return null; } };
const b32enc = buf => { const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = 0, v = 0, o = ''; for (const x of buf) { v = (v << 8) | x; bits += 8; while (bits >= 5) { o += A[(v >>> (bits - 5)) & 31]; bits -= 5; } } if (bits > 0) o += A[(v << (5 - bits)) & 31]; return o; };
const totpAt = (key, step) => { const t = Buffer.alloc(8); t.writeBigUInt64BE(BigInt(step)); const h = crypto.createHmac('sha1', key).update(t).digest(), o = h[19] & 15; return String(h.readUInt32BE(o) % 0x80000000 % 1000000).padStart(6, '0'); };
const tEq = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
// Возвращает номер 30-секундного шага, если код верный и ещё не использовался (защита от повторного ввода), иначе 0
function totpMatch(key, code, lastStep) {
  if (!key || !/^\d{6}$/.test(code)) return 0;
  const now = Math.floor(Date.now() / 30000);
  for (const d of [0, -1, 1]) { const st = now + d; if (st > lastStep && tEq(totpAt(key, st), code)) return st; }
  return 0;
}
const newRecoveryCodes = () => Array.from({ length: 8 }, () => { const r = crypto.randomBytes(5).toString('hex'); return r.slice(0, 5) + '-' + r.slice(5); });
const recNorm = c => String(c || '').toLowerCase().replace(/[^a-f0-9]/g, '');
// Проверка кода входа: приложение-аутентификатор или одноразовый резервный код. Возвращает 'totp' | 'recovery' | null
function verify2fa(row, rawCode) {
  const code = String(rawCode || '').replace(/\s+/g, '');
  if (/^\d{6}$/.test(code)) {
    const st = totpMatch(decSecret(row.totp_secret), code, +row.totp_last || 0);
    if (st && sql.prepare('UPDATE users SET totp_last = ? WHERE id = ? AND totp_last < ?').run(st, row.id, st).changes) return 'totp';
    return null;
  }
  const n = recNorm(code);
  if (n.length === 10) {
    let list; try { list = JSON.parse(row.totp_recovery || '[]'); } catch { list = []; }
    const i = list.indexOf(crypto.createHash('sha256').update(n).digest('hex'));
    if (i >= 0) { list.splice(i, 1); sql.prepare('UPDATE users SET totp_recovery = ? WHERE id = ?').run(JSON.stringify(list), row.id); return 'recovery'; }
  }
  return null;
}
function setPassword(login, pw, role = 'admin', opts = {}) {
  const salt = crypto.randomBytes(16).toString('hex');
  const r = validRole(role) || 'admin';
  const must = opts.mustSetPassword ? 1 : 0;
  // Если пароль не задан — создаём «пустой» хэш и требуем установку при первом входе
  const hasPw = typeof pw === 'string' && pw.length >= 8;
  const code = hasPw ? '' : crypto.randomBytes(9).toString('base64url');
  const hash = hasPw ? hashPw(pw, salt) : hashPw(code, salt);
  const mustFlag = hasPw ? must : 1;
  sql.prepare('INSERT INTO users (login, salt, hash, role, name, created_at, must_set_password) VALUES (?, ?, ?, ?, ?, ?, ?) ON CONFLICT(login) DO UPDATE SET salt = excluded.salt, hash = excluded.hash, role = excluded.role, must_set_password = excluded.must_set_password, created_at = CASE WHEN excluded.must_set_password = 1 THEN excluded.created_at ELSE users.created_at END').run(login.toLowerCase(), salt, hash, r, login, Date.now(), mustFlag);
  // Совместимость со старой таблицей admins
  if (r === 'admin' || ['owner','deputy_owner','chief_admin'].includes(r)) {
    sql.prepare('INSERT INTO admins (login, salt, hash) VALUES (?, ?, ?) ON CONFLICT(login) DO UPDATE SET salt = excluded.salt, hash = excluded.hash').run(login.toLowerCase(), salt, hash);
  }
  return { must_set_password: !!mustFlag, setup_code: code };
}
function addNotification(userId, type, title, body = '', link = '') {
  if (!userId) return;
  sql.prepare('INSERT INTO notifications (user_id, type, title, body, link, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(userId, type, str(title, 120), str(body, 400), str(link, 200), Date.now());
}
function logTournamentHistory(tournamentId, actorId, event, details = '') {
  sql.prepare('INSERT INTO tournament_history (tournament_id, actor_user_id, event, details, created_at) VALUES (?, ?, ?, ?, ?)').run(+tournamentId, actorId || null, str(event, 80), str(details, 500), Date.now());
}

if (process.argv[2] === 'backup') { // node server.js backup — целая копия базы, можно при запущенном сервере
  const dir = path.join(DIR, 'backups'); fs.mkdirSync(dir, { recursive: true });
  const f = path.join(dir, 'major-' + new Date().toISOString().slice(0, 10) + '.db'); try { fs.unlinkSync(f); } catch {}
  sql.exec("VACUUM INTO '" + f.replace(/'/g, "''") + "'"); console.log('Копия сохранена: ' + f); process.exit(0);
}
if (process.argv[2] === 'bans') { sql.prepare('SELECT ip, until, reason FROM bans WHERE until > ?').all(Date.now()).forEach(b => console.log(b.ip, '— до', new Date(b.until).toLocaleString('ru-RU'), '—', b.reason)); process.exit(0); }
if (process.argv[2] === 'unban') { sql.prepare('DELETE FROM bans WHERE ip = ?').run(String(process.argv[3] || '')); console.log('Готово.'); process.exit(0); }
if (process.argv[2] === 'set-password') {
  if (!process.argv[3] || !process.argv[4] || process.argv[4].length < 8) { console.log('Использование: node server.js set-password ЛОГИН ПАРОЛЬ [role]\n  role: owner|deputy_owner|chief_admin|admin|senior_judge|judge|chief_coordinator|coordinator|senior_manager|team_manager|chief_appeals|appeals|media_head|stream_host|commentator|designer|video_editor|pr_manager|captain'); process.exit(1); }
  const role = process.argv[5] || 'admin';
  setPassword(process.argv[3], process.argv[4], role); console.log('Пароль для «' + process.argv[3] + '» (' + role + ') сохранён.'); process.exit(0);
}
if (process.argv[2] === 'reset-2fa') { // node server.js reset-2fa ЛОГИН — если потерян телефон и резервные коды
  if (!process.argv[3]) { console.log('Использование: node server.js reset-2fa ЛОГИН'); process.exit(1); }
  const lg = String(process.argv[3]).toLowerCase(), r = sql.prepare('UPDATE users SET totp_enabled = 0, totp_secret = NULL, totp_pending = NULL, totp_recovery = NULL, totp_last = 0 WHERE login = ?').run(lg);
  sql.prepare('DELETE FROM sessions WHERE login = ?').run(lg);
  console.log(r.changes ? 'Двухфакторная защита для «' + lg + '» сброшена, сессии завершены.' : 'Пользователь не найден.'); process.exit(0);
}
const adminCount = sql.prepare("SELECT COUNT(*) AS n FROM users WHERE role IN ('owner','deputy_owner','chief_admin','admin')").get().n;
if (!adminCount && !sql.prepare('SELECT COUNT(*) AS n FROM admins').get().n) {
  const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
  setPassword('admin', pw, 'admin'); console.log('\nСоздан администратор.  Логин: admin   Пароль: ' + (process.env.ADMIN_PASSWORD ? '(из ADMIN_PASSWORD)' : pw) + '\nСмените пароль: node server.js set-password admin НОВЫЙ_ПАРОЛЬ\n');
}

const hs = t => crypto.createHash('sha256').update(String(t)).digest('hex'); // в базе лежит только хэш токена
const fails = new Map(), regHits = new Map(), putHits = new Map();
const ip = req => { const tp = process.env.TRUST_PROXY; if (tp === 'cloudflare') return String(req.headers['cf-connecting-ip'] || req.socket.remoteAddress); if (tp) { const l = String(req.headers['x-forwarded-for'] || '').split(',').map(x => x.trim()).filter(Boolean); return l[l.length - 1] || req.socket.remoteAddress; } return req.socket.remoteAddress; };
const cookie = req => Object.fromEntries(String(req.headers.cookie || '').split(';').map(s => s.trim().split('=')).filter(a => a[0]));
const who = req => {
  const sid = cookie(req).sid;
  if (!sid) return null;
  const s = sql.prepare('SELECT login, exp FROM sessions WHERE id = ?').get(hs(sid));
  if (!s || s.exp <= Date.now()) return null;
  const u = sql.prepare('SELECT id, login, role, name, contact, team_id, active, must_set_password, totp_enabled FROM users WHERE login = ? AND active = 1').get(s.login);
  if (u) return { id: u.id, login: u.login, role: u.role, name: u.name, contact: u.contact, team_id: u.team_id, must_set_password: !!u.must_set_password, totp: !!u.totp_enabled, must_2fa: REQUIRE_2FA && FULL_ROLES.includes(u.role) && !u.totp_enabled };
  // fallback для старых сессий из admins
  const a = sql.prepare('SELECT login FROM admins WHERE login = ?').get(s.login);
  if (a) return { id: 0, login: a.login, role: 'admin', name: a.login, contact: '', team_id: null, must_set_password: false };
  return null;
};
const send = (res, code, obj, extra = {}) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra }); res.end(JSON.stringify(obj)); };
const body = (req, max = 200000) => new Promise((ok, no) => { let b = '', n = 0; req.on('data', c => { n += c.length; if (n > max) { no(new Error('big')); req.destroy(); } else b += c; }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch { no(new Error('json')); } }); });
const str = (v, max) => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, max);

const url = v => { try { const u = new URL(String(v || '').trim()); return /^https?:$/.test(u.protocol) ? u.href.slice(0, 300) : ''; } catch { return ''; } };
function cleanSite(s) {
  const c = s.cfg || {}, pick = (v, list, d) => list.includes(v) ? v : d;
  const out = {
    news: (Array.isArray(s.news) ? s.news : []).slice(0, 50).map(n => ({ title: str(n.title, 120), text: str(n.text, 600) })),
    prizes: (Array.isArray(s.prizes) ? s.prizes : []).slice(0, 20).map(n => ({ place: str(n.place, 60), sum: str(n.sum, 60) })),
    schedule: (Array.isArray(s.schedule) ? s.schedule : []).slice(0, 30).map(n => ({ stage: str(n.stage, 100), when: str(n.when, 100) })),
    teams: (Array.isArray(s.teams) ? s.teams : []).slice(0, 64).map(t => str(t, 60)).filter(Boolean),
    cfg: { size: pick(+c.size, [8, 16, 32, 64], 64), format: pick(c.format, ['single', 'roundrobin'], 'single'), bo: pick(+c.bo, [1, 3, 5], 1), boSemi: pick(+c.boSemi, [1, 3, 5], 1), boFinal: pick(+c.boFinal, [1, 3, 5], 1) },
    streams: (Array.isArray(s.streams) ? s.streams : []).slice(0, 20).map(n => ({ title: str(n.title, 100), url: url(n.url), when: str(n.when, 100) })),
    partners: (Array.isArray(s.partners) ? s.partners : []).slice(0, 30).map(n => ({ name: str(n.name, 60), url: url(n.url) })),
    packages: (Array.isArray(s.packages) ? s.packages : []).slice(0, 6).map(n => ({ name: str(n.name, 60), price: str(n.price, 40), perks: str(n.perks, 400) })),
    donateUrl: url(s.donateUrl),
    regOpen: s.regOpen !== false, regMax: Math.min(100000, Math.max(0, parseInt(s.regMax, 10) || 0)), regUntil: isFinite(Date.parse(s.regUntil)) ? new Date(s.regUntil).toISOString() : '',
    regAuto: true, checkinUntil: '', // только автоматический приём; ручной режим и check-in отключены
    maps: (Array.isArray(s.maps) ? s.maps : []).slice(0, 30).map(n => ({ name: str(n.name, 40), note: str(n.note, 80) })).filter(n => n.name), mapsNote: str(s.mapsNote, 200),
    privOrg: str(s.privOrg, 120), privContact: str(s.privContact, 120), privRetention: str(s.privRetention, 300),
    results: {},
    archive: (Array.isArray(s.archive) ? s.archive : []).slice(0, 30).map(n => ({ title: str(n.title, 120), text: str(n.text, 600), date: str(n.date, 20) })),
    champions: (Array.isArray(s.champions) ? s.champions : []).slice(0, 50).map(n => ({ team: str(n.team, 60), date: str(n.date, 20), note: str(n.note, 200) })),
    mvp: s.mvp && typeof s.mvp === 'object' ? { name: str(s.mvp.name, 60), team: str(s.mvp.team, 60), note: str(s.mvp.note, 200) } : null
  };
  Object.entries(s.results && typeof s.results === 'object' ? s.results : {}).slice(0, 700).forEach(([k, v]) => {
    if (!/^(rr:)?\d{1,2}-\d{1,3}$/.test(k)) return;
    const w = v && typeof v === 'object' ? v.w : v; if (w !== 0 && w !== 1) return;
    const sc = v && typeof v === 'object' ? str(v.sc, 12) : ''; out.results[k] = sc ? { w, sc } : { w };
  });
  return out;
}

function migrateJson() { // перенос старых JSON-файлов (v1.0) в базу, один раз
  const oldData = path.join(DIR, 'data.json'), oldUsers = path.join(DIR, 'admins.json');
  if (fs.existsSync(oldUsers)) {
    tx(() => Object.entries(readJson(oldUsers, {})).forEach(([l, v]) => v && v.salt && v.hash && sql.prepare('INSERT OR IGNORE INTO admins (login, salt, hash) VALUES (?, ?, ?)').run(l.toLowerCase(), v.salt, v.hash)));
    fs.renameSync(oldUsers, oldUsers + '.migrated'); console.log('Администраторы перенесены из admins.json в базу.');
  }
  if (fs.existsSync(oldData)) {
    const d = readJson(oldData, null); let n = 0;
    if (d) tx(() => {
      if (d.site && !getSite()) putSite(cleanSite(d.site));
      (d.regs || []).forEach(r => { const t = str(r.team, 40); if (!t) return;
        n += sql.prepare('INSERT OR IGNORE INTO regs (id, at, status, confirmed, confirmed_at, ctoken, team, team_norm, captain, contact, roster) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
          .run(String(r.id || crypto.randomUUID()), +r.at || Date.now(), ['new', 'accepted', 'rejected'].includes(r.status) ? r.status : 'new', r.confirmed ? 1 : 0, r.confirmedAt || null, String(r.ctoken || crypto.randomBytes(16).toString('hex')), t, norm(t), str(r.captain, 60), str(r.contact, 80), str(r.roster, 600)).changes; });
    });
    fs.renameSync(oldData, oldData + '.migrated'); console.log('Данные перенесены из data.json в базу (заявок: ' + n + '). Старый файл сохранён как data.json.migrated.');
  }
}
migrateJson();
// Первый запуск обрабатывается выше через users table

/* ===== Защита от спама и атак ===== */
const SECRET = crypto.randomBytes(32), usedNonce = new Map(), heat = [], strikes = new Map();
const rlAll = new Map(), rlApi = new Map(), rlChal = new Map(), regHour = new Map(), regDay = new Map(), regAll = new Map(), confHit = new Map(), ufail = new Map();
const captainRegHour = new Map(), captainRegDay = new Map(), tournamentAppUser = new Map(), tournamentAppIp = new Map();
const banned = new Map(sql.prepare('SELECT ip, until FROM bans WHERE until > ?').all(Date.now()).map(r => [r.ip, r.until]));
const exempt = a => !process.env.PROTECT_LOOPBACK && /^(::1|127\.|::ffff:127\.)/.test(String(a)); // сервер за прокси без TRUST_PROXY: не блокируем «всех сразу»
const hit = (map, key, windowMs, max) => { const now = Date.now(), a = (map.get(key) || []).filter(t => now - t < windowMs); if (a.length >= max) { map.set(key, a); return false; } a.push(now); map.set(key, a); return true; };
const hitIp = (map, a, w, max) => exempt(a) || hit(map, a, w, max);
const isBanned = a => { // «node server.js unban IP» действует сразу, без перезапуска
  if (exempt(a)) return false; const u = banned.get(a); if (!u || u <= Date.now()) return false;
  if (!sql.prepare('SELECT 1 FROM bans WHERE ip = ?').get(a)) { banned.delete(a); return false; } return true;
};
function ban(a, why) {
  const prev = sql.prepare('SELECT until FROM bans WHERE ip = ?').get(a), now = Date.now(), until = now + (prev && now - prev.until < 86400000 ? 86400000 : 3600000);
  banned.set(a, until); strikes.delete(a);
  sql.prepare('INSERT INTO bans (ip, until, reason, at) VALUES (?, ?, ?, ?) ON CONFLICT(ip) DO UPDATE SET until = excluded.until, reason = excluded.reason, at = excluded.at').run(a, until, String(why).slice(0, 40), now);
  console.log('Блокировка IP ' + a + ' до ' + new Date(until).toLocaleString('ru-RU') + ': ' + why);
}
function strike(a, w, why) { // штрафные очки за подозрительное поведение; 1 очко «сгорает» за минуту; 10 очков — бан
  if (exempt(a)) return; const now = Date.now(), e = strikes.get(a) || { s: 0, t: now };
  e.s = Math.max(0, e.s - (now - e.t) / 60000) + w; e.t = now; strikes.set(a, e); if (e.s >= 10) ban(a, why);
}
function regState(site) {
  const st = site || {}, n = sql.prepare("SELECT COUNT(*) AS n FROM regs WHERE status != 'rejected'").get().n, max = +st.regMax || 0, until = st.regUntil ? Date.parse(st.regUntil) : 0;
  const size = +((st.cfg && st.cfg.size) || 64), inBracket = Array.isArray(st.teams) ? st.teams.length : 0;
  const slotsLeft = Math.max(0, size - inBracket);
  let open = true, reason = '';
  if (st.regOpen === false) { open = false; reason = 'closed'; }
  else if (until && Date.now() > until) { open = false; reason = 'expired'; }
  else if (slotsLeft <= 0) { open = false; reason = 'full'; } // сетка заполнена — заявки больше не принимаются
  else if (max && n >= max) { open = false; reason = 'cap'; }
  // left = свободные места в сетке (и с учётом лимита заявок, если он задан)
  const leftByCap = max ? Math.max(0, max - n) : null;
  const left = leftByCap == null ? slotsLeft : Math.min(slotsLeft, leftByCap);
  return { open, reason, left, slots: slotsLeft, size, until: st.regUntil || '', checkin: st.checkinUntil || '' };
}
// Задача для браузера (proof-of-work): стоит боту CPU-времени, обычному человеку — доли секунды. Под атакой сложность растёт.
const currentBits = () => { const now = Date.now(); while (heat.length && now - heat[0] > 300000) heat.shift(); return 16 + Math.min(4, Math.floor(Math.log2(1 + heat.length / 40))); };
const sign = p => crypto.createHmac('sha256', SECRET).update(p).digest('hex').slice(0, 32);
function verifyPow(pow) {
  const bad = (err, w) => ({ err, w });
  if (!pow || typeof pow.token !== 'string' || !/^\d{1,10}$/.test(String(pow.counter))) return bad('Не пройдена проверка защиты. Обновите страницу.', 3);
  const [nonce, bits, ts, sg] = pow.token.split('.');
  if (!/^[a-f0-9]{16}$/.test(nonce || '') || !/^\d{2}$/.test(bits || '') || !/^\d{10,15}$/.test(ts || '') || !/^[a-f0-9]{32}$/.test(sg || '')) return bad('Не пройдена проверка защиты. Обновите страницу.', 3);
  if (!crypto.timingSafeEqual(Buffer.from(sign(nonce + '.' + bits + '.' + ts)), Buffer.from(sg))) return bad('Не пройдена проверка защиты. Обновите страницу.', 3);
  const age = Date.now() - +ts;
  if (age < 2800) return bad('Слишком быстро. Подождите пару секунд и отправьте ещё раз.', 1);
  if (age > 1800000 || usedNonce.has(nonce)) return bad('Проверка устарела. Нажмите «Отправить» ещё раз.', 1);
  const h = crypto.createHash('sha256').update(nonce + ':' + pow.counter).digest(); let z = 0;
  for (const byte of h) { if (byte === 0) { z += 8; continue; } z += Math.clz32(byte) - 24; break; }
  if (z < +bits) return bad('Проверка не пройдена. Нажмите «Отправить» ещё раз.', 3);
  usedNonce.set(nonce, Date.now() + 1800000); return null;
}
const sameOrigin = req => { // запрос на изменение должен идти с самого сайта
  if (req.headers['sec-fetch-site'] === 'cross-site') return false;
  const o = req.headers.origin; if (!o) return true;
  try { const h = new URL(o).host; return h === req.headers.host || (!!process.env.TRUST_PROXY && h === req.headers['x-forwarded-host']) || String(process.env.ALLOWED_ORIGIN || '').split(',').some(x => { try { return new URL(x.trim()).host === h; } catch { return false; } }); } catch { return false; }
};
const URLISH = /(https?:\/\/|www\.|t\.me\/|discord\.gg)/i;
setInterval(() => {
  const now = Date.now();
  for (const m of [rlAll, rlApi, rlChal, regHour, regDay, regAll, confHit, ufail, fails, putHits]) for (const [k, a] of m) { const last = Array.isArray(a) ? a[a.length - 1] : (a.until || 0); if (!last || now - last > 86400000) m.delete(k); }
  for (const [k, v] of usedNonce) if (v < now) usedNonce.delete(k);
  for (const [k, e] of strikes) if (now - e.t > 3600000) strikes.delete(k);
  for (const [k, u] of banned) if (u < now) banned.delete(k);
  sql.prepare('DELETE FROM sessions WHERE exp < ?').run(now); sql.prepare('DELETE FROM bans WHERE until < ?').run(now - 86400000);
}, 300000).unref();
let proxyWarned = false;

/* ===== Приём заявок: автопринятие только при наличии свободного места, без очереди ===== */
function defaultSite() { try { const m = fs.readFileSync(PAGE, 'utf8').match(/<script type="application\/json" id="siteData">([\s\S]*?)<\/script>/); return cleanSite(JSON.parse(m[1])); } catch { return cleanSite({}); } }
const siteNow = () => getSite() || defaultSite();
const teamIn = (site, name) => site.teams.some(t => norm(t) === norm(name));
const isLate = site => !!site.checkinUntil && Date.now() > Date.parse(site.checkinUntil);
function setAccepted(site, r) {
  // В автоматическом режиме и после срока check-in сразу подтверждаем — админам не нужно писать капитану
  const auto = (site.regAuto !== false || isLate(site)) ? 1 : 0;
  sql.prepare('UPDATE regs SET status = ?, confirmed = CASE WHEN ? = 1 THEN 1 ELSE confirmed END, confirmed_at = CASE WHEN ? = 1 THEN COALESCE(confirmed_at, ?) ELSE confirmed_at END WHERE id = ?').run('accepted', auto, auto, Date.now(), r.id);
  if (!teamIn(site, r.team)) site.teams.push(r.team);
}
function dropTeam(name) { const site = siteNow(), n = site.teams.length; site.teams = site.teams.filter(t => norm(t) !== norm(name)); if (site.teams.length !== n) putSite(site); }
function checkinSweep() { // срок подтверждения вышел: кто не подтвердил — освобождает место
  const site = getSite(); if (!site || !site.checkinUntil || Date.now() < Date.parse(site.checkinUntil)) return;
  const rows = sql.prepare("SELECT * FROM regs WHERE status = 'accepted' AND confirmed = 0").all(); if (!rows.length) return;
  tx(() => { rows.forEach(r => sql.prepare("UPDATE regs SET status = 'rejected' WHERE id = ?").run(r.id)); site.teams = site.teams.filter(t => !rows.some(r => r.team_norm === norm(t))); putSite(site); });
  console.log('Не подтвердили участие и удалены из сетки: ' + rows.map(r => r.team).join(', '));
}
setInterval(() => { try { checkinSweep(); } catch (e) { console.error(e.message); } }, +process.env.SWEEP_MS || 60000).unref();

const esc = x => String(x == null ? '' : x).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const LEGAL_DATE = '18 ноября 2026';
function legalLayout(title, body) {
  return `<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="dark">
<title>${title} — MAJOR CSS</title><meta name="robots" content="index,follow">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;600;800&display=swap">
<style>:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#08090b;color:#f4f4f5;font-family:Manrope,Arial,sans-serif;line-height:1.7}main{max-width:820px;margin:0 auto;padding:42px 20px 80px}a{color:#ff4655}h1{font-size:clamp(30px,6vw,44px);line-height:1.15;margin:.4em 0}h2{font-size:20px;margin:2em 0 .4em}p,li{color:#d2d3d7;font-size:16px}ul{padding-left:1.2em}li{margin:.4em 0}.top{font-size:14px;color:#a3a5ad}.box{border-left:3px solid #e32636;background:#111317;padding:14px 18px;margin:18px 0}.nav{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:22px;font-size:14px}</style></head><body><main><nav class="nav"><a href="/">← На главную</a><a href="/terms">Пользовательское соглашение</a><a href="/privacy">Политика конфиденциальности</a></nav>${body}<p class="top" style="margin-top:3em">© 2026 MAJOR CSS · Counter Shot: Source (DEVI)</p></main></body></html>`;
}
function privacyPage() {
  const s = siteNow(), org = esc(s.privOrg || 'Организатор турнира MAJOR CSS'), contact = esc(s.privContact || 'Telegram: @Aleksus_06'),
    keep = esc(s.privRetention || 'Данные хранятся до завершения турнира. После завершения организаторы удаляют заявки; удалить данные раньше можно по запросу.');
  return legalLayout('Политика конфиденциальности', `<h1>Политика конфиденциальности</h1><p class="top">Редакция от ${LEGAL_DATE}</p>
<p>Настоящая Политика описывает, какие персональные и технические данные обрабатываются при использовании сайта и платформы MAJOR CSS (Counter Shot: Source), для каких целей они используются, кому могут быть доступны и как пользователь может обратиться по вопросам их обработки.</p>
<div class="box"><strong>Коротко.</strong> Данные используются для регистрации участников, проведения турниров, работы аккаунтов и защиты сайта. Публично отображаются игровые сведения, предназначенные для результатов и турнирной статистики. Контактные данные и учётные данные не предназначены для публичного показа. Запрос на доступ, исправление или удаление данных можно направить организатору.</div>
<h2>1. Оператор персональных данных</h2><p>Оператор: ${org}. Контакт для обращений по вопросам персональных данных: ${contact}. До публичного запуска оператору необходимо указать свои полные сведения и актуальный адрес для юридически значимых обращений.</p>
<h2>2. Какие данные могут обрабатываться</h2><ul>
<li><b>Данные регистрации и заявок:</b> логин, имя или игровой ник капитана, название команды, контактные данные, состав команды и сведения, которые пользователь добровольно указывает в форме; дата и время согласия на обработку данных и принятия Пользовательского соглашения.</li>
<li><b>Данные аккаунта:</b> логин, хэш пароля, роль и статус учётной записи, дата создания, привязка к команде и технические сведения о сессии.</li>
<li><b>Турнирные данные:</b> названия команд, игровые ники, результаты матчей, расписание, статистика и история участия. Часть этих сведений может быть общедоступной в рамках работы турнира.</li>
<li><b>Технические данные:</b> IP-адрес и сведения о запросах могут обрабатываться сервером для ограничения злоупотреблений, защиты от спама и обеспечения безопасности. При блокировке адрес и причина могут сохраняться в технической базе на срок блокировки и дополнительный период, предусмотренный настройками сервера.</li>
<li><b>Cookie и локальное хранилище:</b> при входе администратора сервер устанавливает служебный cookie сессии; браузер также может хранить временные настройки интерфейса в sessionStorage. В автономном режиме редактирования черновик может сохраняться в localStorage. Рекламные и аналитические cookie в штатной конфигурации сайта не используются.</li></ul>
<h2>3. Цели обработки</h2><p>Данные обрабатываются для создания и обслуживания аккаунтов, приёма и рассмотрения заявок, связи с капитанами, формирования команд и турнирных сеток, проведения матчей, публикации результатов и статистики, работы судей и администраторов, предотвращения мошенничества и спама, обеспечения безопасности и исполнения требований законодательства Российской Федерации.</p>
<h2>4. Правовые основания и согласие</h2><p>Обработка осуществляется при наличии применимого правового основания, в том числе согласия пользователя, необходимости исполнения пользовательского соглашения и выполнения обязанностей, установленных законодательством Российской Федерации. Если для конкретной операции требуется согласие, оно запрашивается отдельно и может быть отозвано обращением к оператору. Отзыв согласия не влияет на законность обработки, выполненной до его получения, и не исключает обработку, для которой сохраняется иное законное основание.</p><p>Отправляя сведения о других участниках команды, капитан должен убедиться, что участники проинформированы о передаче их игровых данных для организации турнира. Не следует указывать чужие личные или контактные данные без необходимости и надлежащего основания.</p>
<h2>5. Публичность и доступ к данным</h2><p>В открытых разделах могут отображаться название команды, игровые ники, результаты матчей, турнирное расписание и статистика, если это необходимо для проведения и освещения соревнований. Пароли, их хэши, данные авторизации и личные контакты не публикуются. Доступ к заявкам и служебным данным предоставляется уполномоченным администраторам в пределах их обязанностей.</p>
<h2>6. Хранение в базе данных</h2><p>Данные аккаунтов, команд, заявок и турнирных записей сохраняются в базе SQLite на сервере, где развёрнута платформа MAJOR CSS. Служебные данные сессий и блокировок также могут сохраняться в базе. Доступ к файлу базы и резервным копиям должен быть ограничен на уровне сервера. Резервные копии создаются только при включении соответствующей процедуры администратором.</p>
<h2>7. Передача третьим лицам и инфраструктура</h2><p>Оператор не продаёт персональные данные. Доступ к ним может предоставляться хостинг-провайдеру и техническим поставщикам в объёме, необходимом для размещения и работы сайта, а также государственным органам в случаях, предусмотренных законом. При переходе по внешним ссылкам (например, в Telegram или на сайты партнёров) пользователь взаимодействует с соответствующими ресурсами по их собственным правилам.</p><p>Для загрузки веб-шрифта сайт может обращаться к Google Fonts. При таком запросе соответствующему поставщику могут передаваться технические сведения, включая IP-адрес и данные браузера. Если эта зависимость будет удалена или заменена локальным шрифтом, данный пункт подлежит обновлению.</p>
<h2>8. Сроки хранения и локализация</h2><p>${keep}</p><p>Оператор определяет сроки хранения с учётом целей обработки, требований законодательства и необходимости защиты прав участников. Обработка осуществляется с учётом Федерального закона от 27.07.2006 № 152-ФЗ «О персональных данных» и иных применимых норм. Платформа предназначена для использования в Российской Федерации. При обработке персональных данных граждан РФ оператор должен обеспечить соблюдение требований законодательства РФ о локализации баз данных и иных применимых требований. Конкретное местонахождение сервера и резервных копий должно соответствовать фактической инфраструктуре проекта.</p>
<h2>9. Права пользователя и обращения</h2><p>Пользователь вправе обратиться за информацией об обработке своих данных, потребовать уточнения неточных сведений, блокирования или удаления данных при наличии предусмотренных законом оснований, а также отозвать согласие. Для обращения напишите по контакту, указанному в разделе 1, и по возможности укажите аккаунт или команду, к которым относится запрос. Оператор может запросить сведения, необходимые для подтверждения личности заявителя и предотвращения раскрытия данных постороннему лицу.</p>
<h2>10. Защита информации</h2><p>Оператор принимает разумные организационные и технические меры для защиты данных от неправомерного доступа, изменения, раскрытия, уничтожения и иных неправомерных действий. К таким мерам относятся разграничение доступа по ролям, хранение паролей в виде криптографических хэшей, использование защищённых сессий и ограничение частоты запросов. Ни один способ передачи или хранения информации не может гарантировать абсолютную безопасность.</p>
<h2>11. Данные несовершеннолетних</h2><p>Если пользователь не достиг возраста, при котором он может самостоятельно давать соответствующее согласие по закону, использование платформы и передача персональных данных должны осуществляться с участием или согласием законного представителя в случаях, когда это требуется законодательством.</p>
<h2>12. Изменение и удаление данных</h2><p>Пользователь может направить запрос на исправление или удаление данных по контакту оператора. Удаление может быть ограничено, если дальнейшее хранение требуется законом, необходимо для разрешения спора, обеспечения безопасности или защиты законных прав. Данные в резервных копиях могут сохраняться до планового обновления или удаления таких копий.</p>
<h2>13. Изменения Политики</h2><p>Оператор вправе обновлять Политику при изменении функциональности сайта, способов обработки или требований законодательства. Актуальная редакция публикуется на этой странице с указанием даты обновления. Продолжение использования платформы после публикации изменений означает ознакомление с новой редакцией, но не заменяет отдельное согласие, когда оно требуется законом.</p>`);
}
function termsPage() {
  const s = siteNow(), org = esc(s.privOrg || 'Организатор турнира MAJOR CSS'), contact = esc(s.privContact || 'Telegram: @Aleksus_06');
  return legalLayout('Пользовательское соглашение', `<h1>Пользовательское соглашение</h1><p class="top">Редакция от ${LEGAL_DATE}</p>
<p>Настоящее Пользовательское соглашение (далее — «Соглашение») регулирует использование сайта и платформы MAJOR CSS (Counter Shot: Source), включая регистрацию аккаунтов, подачу заявок, участие в турнирах и взаимодействие с организаторами.</p>
<div class="box"><strong>Важно.</strong> Используя сайт, создавая аккаунт или отправляя заявку, пользователь подтверждает, что ознакомился с Соглашением. Если пользователь не согласен с его условиями, он должен прекратить использование соответствующих функций платформы.</div>
<h2>1. Общие положения</h2><p>Платформа MAJOR CSS предназначена для информационного сопровождения и организации киберспортивных турниров по Counter Shot: Source (DEVI): регистрации команд, публикации сеток, расписаний, результатов и статистики. Организатор: ${org}. Контакт: ${contact}. Соглашение применяется к посетителям, капитанам, игрокам, судьям, администраторам и иным пользователям платформы.</p>
<h2>2. Регистрация и аккаунт</h2><ul><li>Пользователь обязан указывать достоверные сведения в пределах запрашиваемых формой данных.</li><li>Пользователь самостоятельно обеспечивает сохранность логина и пароля и не передаёт доступ посторонним.</li><li>Запрещено создавать аккаунты от имени другого лица без его разрешения, выдавать себя за представителя организатора или обходить ограничения доступа.</li><li>При подозрении на компрометацию аккаунта пользователь должен сообщить организатору.</li></ul>
<h2>3. Регистрация команд и участие</h2><p>Заявку подаёт капитан или уполномоченный представитель команды. Отправка заявки не гарантирует участие, если набор закрыт, достигнут лимит участников либо заявка содержит недостоверные сведения или нарушает правила турнира. Условия подтверждения участия, состав команды, сроки и формат конкретного турнира публикуются на сайте или в официальных объявлениях организатора.</p><p>Капитан отвечает за корректность передаваемых сведений о составе и за информирование игроков о передаче их игровых данных для организации турнира. Организатор может запросить уточнения, исправление заявки или подтверждение полномочий капитана.</p>
<h2>4. Правила поведения</h2><p>Пользователям запрещается использовать платформу для спама, угроз, оскорблений, мошенничества, распространения вредоносного кода, вмешательства в работу сайта, попыток получить чужой доступ, подделки результатов и иных действий, нарушающих закон или права других лиц. Пользователь не должен предпринимать попытки обхода технических ограничений и средств защиты платформы.</p>
<h2>5. Проведение матчей и судейство</h2><p>Матчи проводятся по формату и регламенту, опубликованным для соответствующего турнира. Судьи и уполномоченные администраторы фиксируют результаты на основании доступных подтверждений и правил турнира. Пользователь обязан предоставлять достоверную информацию и по запросу предоставлять подтверждения результата в установленном организатором порядке.</p>
<h2>6. Результаты, технические поражения и дисквалификация</h2><p>Организатор и уполномоченные судьи вправе исправить ошибочно внесённый результат, назначить переигровку, засчитать техническое поражение или дисквалифицировать команду в случаях, предусмотренных регламентом турнира, включая неявку, нарушение правил, использование запрещённых средств, подлог или неспортивное поведение. Существенные изменения результатов должны фиксироваться в служебной истории платформы, если такая функция доступна.</p>
<h2>7. Апелляции и спорные ситуации</h2><p>Порядок и сроки подачи апелляций определяются регламентом конкретного турнира или официальным объявлением организатора. В обращении следует указать турнир, матч, суть несогласия и приложить имеющиеся подтверждения. Решение принимается уполномоченными представителями организатора с учётом регламента и доступных материалов.</p>
<h2>8. Роли и полномочия</h2><p>Доступ к административным и судейским функциям предоставляется только назначенным лицам. Пользователь не вправе самостоятельно присваивать себе роль, использовать чужую учётную запись или передавать свои полномочия другому лицу. Организатор может изменять роли и ограничивать доступ при нарушении правил или прекращении полномочий.</p>
<h2>9. Призы и выплаты</h2><p>Размер призового фонда, распределение призовых мест, условия получения и сроки выплат объявляются отдельно для каждого турнира. Если распределение или порядок выплат не опубликованы, пользователь не должен считать их согласованными автоматически. Организатор вправе запросить сведения, необходимые для проверки результатов и законного осуществления выплаты. Налогообложение призов осуществляется в соответствии с применимым законодательством.</p>
<h2>10. Интеллектуальная собственность и материалы</h2><p>Права на дизайн, программный код, логотипы и материалы платформы принадлежат их правообладателям. Названия команд, игровые ники, логотипы и материалы, загружаемые пользователями, остаются за соответствующими правообладателями. Пользователь предоставляет организатору ограниченное право использовать такие материалы для отображения заявки, сетки, результатов, статистики и информационного освещения турнира.</p>
<h2>11. Доступность и технические ограничения</h2><p>Организатор стремится поддерживать работоспособность платформы, но не гарантирует непрерывную и безошибочную работу. Возможны технические перерывы, обновления, потеря связи и временная недоступность отдельных функций. Пользователь должен сохранять важные подтверждения и своевременно сообщать о замеченных ошибках. Организатор не несёт ответственности за сбои сторонних сервисов и сетей, находящихся вне его контроля.</p>
<h2>12. Ограничение или прекращение доступа</h2><p>Организатор вправе временно ограничить или прекратить доступ к аккаунту или отдельным функциям при нарушении Соглашения, регламента турнира, требований безопасности или законодательства. По возможности пользователь уведомляется о причине ограничения и способе обращения для рассмотрения ситуации.</p>
<h2>13. Персональные данные</h2><p>Обработка персональных данных осуществляется в соответствии с отдельной <a href="/privacy">Политикой конфиденциальности</a> и применимым законодательством Российской Федерации. Политика является неотъемлемым информационным документом платформы, но согласие на обработку персональных данных запрашивается отдельно в случаях, когда это необходимо.</p>
<h2>14. Изменение Соглашения</h2><p>Организатор может обновлять Соглашение при изменении платформы, правил турниров или законодательства. Актуальная редакция публикуется на этой странице с указанием даты. Для уже начавшегося турнира специальные условия регламента применяются с учётом объявленных правил и недопустимости произвольного изменения результатов задним числом.</p>
<h2>15. Применимое право и обращения</h2><p>К отношениям, связанным с использованием платформы, применяется законодательство Российской Федерации в той мере, в какой оно применимо. Обработка персональных данных осуществляется с учётом Федерального закона от 27.07.2006 № 152-ФЗ «О персональных данных» и иных применимых норм. Платформа ориентирована на использование в Российской Федерации. Вопросы и претензии можно направлять по контакту организатора: ${contact}. Если отдельное положение Соглашения будет признано недействительным, остальные положения сохраняют силу в допустимой законом части.</p>`);
}
const origin = req => (process.env.SECURE || (process.env.TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https') ? 'https' : 'http') + '://' + (/^[a-z0-9.\-]+(:\d+)?$/i.test(req.headers.host || '') ? req.headers.host : 'localhost');
const sendText = (req, res, code, type, text, extra = {}) => {
  const buf = Buffer.from(text), gz = /\bgzip\b/.test(req.headers['accept-encoding'] || '') && buf.length > 1024;
  res.writeHead(code, { 'Content-Type': type, Vary: 'Accept-Encoding', ...(gz ? { 'Content-Encoding': 'gzip' } : {}), ...extra }); res.end(gz ? require('zlib').gzipSync(buf) : buf);
};
const FAVICON = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path d="M0 0h32v24l-8 8H0z" fill="#e32636"/><text x="16" y="23" font-size="20" font-weight="900" text-anchor="middle" fill="#fff" font-family="Arial">M</text></svg>`;

const srv = http.createServer(async (req, res) => {
  let u; try { u = new URL(req.url, 'http://x'); } catch { res.writeHead(400); return res.end(); }
  const p = u.pathname, m = req.method, addr = ip(req);
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'same-origin'); res.setHeader('X-Frame-Options', 'DENY');
  const cspN = crypto.randomBytes(16).toString('base64'); res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'nonce-" + cspN + "'; script-src-attr 'unsafe-inline'; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()'); res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  if (process.env.SECURE) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
  if (!process.env.TRUST_PROXY && !proxyWarned && exempt(addr) && (req.headers['x-forwarded-for'] || req.headers['cf-connecting-ip'])) { proxyWarned = true; console.warn('ВНИМАНИЕ: запросы идут через прокси, но TRUST_PROXY не задан — защита по IP не работает. Запустите с TRUST_PROXY=1 (nginx) или TRUST_PROXY=cloudflare.'); }
  if (isBanned(addr)) { res.writeHead(403, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Доступ закрыт.'); }
  if (!hitIp(rlAll, addr, 60000, 300)) { strike(addr, 1, 'flood'); res.writeHead(429, { 'Retry-After': '30' }); return res.end(); }
  try {
    if (m === 'GET' && (p === '/' || p === '/index.html')) return sendText(req, res, 200, 'text/html; charset=utf-8', fs.readFileSync(PAGE, 'utf8').split('__ORIGIN__').join(origin(req)).split('<script').join('<script nonce="' + cspN + '"'), { 'Cache-Control': 'no-cache' });
    if (m === 'GET' && p === '/privacy') return sendText(req, res, 200, 'text/html; charset=utf-8', privacyPage(), { 'Cache-Control': 'no-cache' });
    if (m === 'GET' && p === '/terms') return sendText(req, res, 200, 'text/html; charset=utf-8', termsPage(), { 'Cache-Control': 'no-cache' });
    if (m === 'GET' && p === '/og-image.png') { let img; try { img = fs.readFileSync(path.join(DIR, 'og-image.png')); } catch { res.writeHead(404); return res.end(); } res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=86400' }); return res.end(img); }
    if (m === 'GET' && p === '/robots.txt') return sendText(req, res, 200, 'text/plain; charset=utf-8', 'User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: ' + origin(req) + '/sitemap.xml\n');
    if (m === 'GET' && p === '/sitemap.xml') return sendText(req, res, 200, 'application/xml; charset=utf-8', '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>' + origin(req) + '/</loc></url><url><loc>' + origin(req) + '/privacy</loc></url><url><loc>' + origin(req) + '/terms</loc></url></urlset>\n');
    if (m === 'GET' && (p === '/favicon.svg' || p === '/favicon.ico')) return sendText(req, res, 200, 'image/svg+xml', FAVICON, { 'Cache-Control': 'public, max-age=86400' });
    // Static assets (banners, logos, media) — only safe files under /assets/
    if (m === 'GET' && p.startsWith('/assets/')) {
      const rel = p.slice(1).replace(/\\/g, '/');
      if (rel.includes('..') || rel.includes('\0')) { res.writeHead(400); return res.end(); }
      const fp = path.join(DIR, rel);
      if (!fp.startsWith(path.join(DIR, 'assets')) || !fs.existsSync(fp) || !fs.statSync(fp).isFile()) { res.writeHead(404); return res.end(); }
      const ext = path.extname(fp).toLowerCase();
      const types = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.gif': 'image/gif' };
      const ctype = types[ext] || 'application/octet-stream';
      try {
        const buf = fs.readFileSync(fp);
        res.writeHead(200, { 'Content-Type': ctype, 'Cache-Control': 'public, max-age=604800', 'Content-Length': buf.length });
        return res.end(buf);
      } catch { res.writeHead(404); return res.end(); }
    }
    if (!p.startsWith('/api/')) { res.writeHead(404); return res.end('Not found'); }
    if (m !== 'GET' && !String(req.headers['content-type'] || '').includes('application/json')) return send(res, 415, { error: 'Нужен JSON' });
    const user = who(req), key = p.slice(5);
    if (!hitIp(rlApi, addr, 60000, 120)) { strike(addr, 1, 'api-flood'); return send(res, 429, { error: 'Слишком много запросов. Подождите минуту.' }, { 'Retry-After': '60' }); }
    if (m !== 'GET' && !sameOrigin(req)) { strike(addr, 2, 'origin'); return send(res, 403, { error: 'Запрос отклонён.' }); }

    if (key === 'ping') return send(res, 200, { ok: true });
    if (key === 'me') return send(res, 200, { user });
    if (user && user.must_set_password && !['password','logout','login','challenge','register','confirm','data','ping','tournaments','matches','ratings','roles','archive','team-history','head-to-head'].includes(key) && !key.startsWith('public/')) return send(res, 403, { error: 'Сначала задайте свой пароль.' });
    if (user && user.must_2fa && !['2fa/setup', '2fa/enable', 'password', 'logout', 'login', 'challenge', 'register', 'confirm', 'data', 'ping', 'tournaments', 'matches', 'ratings', 'roles', 'archive', 'team-history', 'head-to-head'].includes(key) && !key.startsWith('public/')) return send(res, 403, { error: 'Для администраторов обязательна двухфакторная защита. Включите её в меню «Двухфакторная защита».', need_2fa_setup: true });
    if (key === 'data' && m === 'GET') return send(res, 200, { site: getSite(), reg: regState(getSite()) });

    // ===== v5.0: публичная сводка платформы =====
    if (key === 'public/platform/stats' && m === 'GET') {
      const tournaments=sql.prepare("SELECT COUNT(*) total,SUM(CASE WHEN t.status IN ('registration','active') THEN 1 ELSE 0 END) active,SUM(CASE WHEN t.status='completed' THEN 1 ELSE 0 END) completed FROM tournaments t WHERE t.status!='archived'").get();
      const teams=sql.prepare("SELECT COUNT(DISTINCT tt.id) total FROM tournament_teams tt JOIN tournaments tr ON tr.id=tt.tournament_id WHERE tr.status!='archived'").get();
      const matches=sql.prepare("SELECT COUNT(*) total,SUM(CASE WHEN tm.status IN ('done','walkover') THEN 1 ELSE 0 END) completed FROM tournament_matches tm JOIN tournaments tr ON tr.id=tm.tournament_id WHERE tr.status!='archived'").get();
      const players=sql.prepare("SELECT COUNT(DISTINCT lower(player_name)) total,COALESCE(SUM(mvp),0) mvp FROM tournament_player_stats ps JOIN tournaments tr ON tr.id=ps.tournament_id WHERE tr.status!='archived'").get();
      return send(res,200,{ok:true,stats:{tournaments:tournaments.total||0,active_tournaments:tournaments.active||0,completed_tournaments:tournaments.completed||0,teams:teams.total||0,matches:matches.total||0,completed_matches:matches.completed||0,players:players.total||0,mvp_awards:players.mvp||0}});
    }
    // ===== v3.5: публичный рейтинг и профили игроков =====
    if (key === 'public/players' && m === 'GET') {
      const limit = Math.max(1, Math.min(100, Number(u.searchParams.get('limit')) || 50));
      const rows = sql.prepare(`SELECT ps.player_name, SUM(ps.kills) AS kills, SUM(ps.deaths) AS deaths,
        SUM(ps.assists) AS assists, SUM(ps.mvp) AS mvp, COUNT(DISTINCT ps.match_id) AS matches_played,
        COUNT(DISTINCT ps.tournament_id) AS tournaments_played
        FROM tournament_player_stats ps GROUP BY ps.player_name COLLATE NOCASE`).all()
        .map(x => ({...x, rating:playerRating(x)}))
        .sort((a,b)=>b.rating-a.rating||b.mvp-a.mvp||b.kills-a.kills||a.deaths-b.deaths||a.player_name.localeCompare(b.player_name,'ru'))
        .slice(0,limit);
      return send(res,200,{ok:true,items:rows,formula:'K + 0.5×A + 5×MVP − 0.25×D'});
    }
    const publicPlayerRoute = key.match(/^public\/players\/(.+)$/);
    if (publicPlayerRoute && m === 'GET') {
      let playerName; try { playerName=decodeURIComponent(publicPlayerRoute[1]).trim(); } catch { return send(res,400,{error:'Некорректное имя игрока.'}); }
      if(!playerName || playerName.length>40) return send(res,400,{error:'Укажите ник игрока (до 40 символов).'});
      const rows = sql.prepare(`SELECT ps.player_name,ps.kills,ps.deaths,ps.assists,ps.mvp,ps.match_id,ps.tournament_id,
        t.name AS tournament_name,t.status AS tournament_status,tt.name AS team_name,m.round,m.pos,m.score,m.status AS match_status
        FROM tournament_player_stats ps JOIN tournaments t ON t.id=ps.tournament_id
        JOIN tournament_teams tt ON tt.id=ps.team_id JOIN tournament_matches m ON m.id=ps.match_id
        WHERE ps.player_name=? COLLATE NOCASE AND t.status!='archived'
        ORDER BY ps.updated_at DESC,ps.id DESC`).all(playerName);
      if(!rows.length) return send(res,404,{error:'Профиль игрока не найден.'});
      const summary=rows.reduce((a,x)=>{a.kills+=x.kills;a.deaths+=x.deaths;a.assists+=x.assists;a.mvp+=x.mvp;a.matches_played++;a.tournaments.add(x.tournament_id);return a},{kills:0,deaths:0,assists:0,mvp:0,matches_played:0,tournaments:new Set()});
      const profile={player_name:rows[0].player_name,kills:summary.kills,deaths:summary.deaths,assists:summary.assists,mvp:summary.mvp,matches_played:summary.matches_played,tournaments_played:summary.tournaments.size};
      profile.rating=playerRating(profile);
      return send(res,200,{ok:true,profile,history:rows.map(({player_name,kills,deaths,assists,mvp,match_id,tournament_id,tournament_name,team_name,round,pos,score,match_status})=>({player_name,kills,deaths,assists,mvp,match_id,tournament_id,tournament_name,team_name,round,pos,score,match_status}))});
    }

    // ===== v3.0: публичный каталог турниров =====
    if (key === 'tournaments' && m === 'GET') {
      const items = sql.prepare(`SELECT t.*, (SELECT COUNT(*) FROM tournament_teams tt WHERE tt.tournament_id=t.id) AS team_count,
        (SELECT COUNT(*) FROM tournament_matches tm WHERE tm.tournament_id=t.id) AS match_count
        FROM tournaments t WHERE t.status != 'archived' ORDER BY t.created_at DESC`).all();
      return send(res, 200, { ok:true, items });
    }
    if (key.match(/^tournaments\/\d+$/) && m === 'GET') {
      const tid = +key.split('/')[1];
      const tournament = sql.prepare("SELECT * FROM tournaments WHERE id=? AND status != 'archived'").get(tid);
      if (!tournament) return send(res, 404, { error:'Турнир не найден.' });
      const teams = sql.prepare('SELECT id,name,seed,captain_user_id FROM tournament_teams WHERE tournament_id=? ORDER BY COALESCE(seed,9999),name COLLATE NOCASE').all(tid);
      const matches = sql.prepare(`SELECT m.*,a.name AS team1_name,b.name AS team2_name,w.name AS winner_name,ju.name AS judge_name
        FROM tournament_matches m LEFT JOIN tournament_teams a ON a.id=m.team1_id
        LEFT JOIN tournament_teams b ON b.id=m.team2_id LEFT JOIN tournament_teams w ON w.id=m.winner_team_id LEFT JOIN users ju ON ju.id=m.judge_user_id
        WHERE m.tournament_id=? ORDER BY m.round,m.pos`).all(tid);
      const standings = teams.map(t=>({id:t.id,name:t.name,played:0,wins:0,losses:0,points:0}));
      const byId = new Map(standings.map(x=>[x.id,x]));
      for (const mt of matches.filter(x=>['done','walkover'].includes(x.status) && x.winner_team_id)) {
        const a=byId.get(mt.team1_id), b=byId.get(mt.team2_id), w=byId.get(mt.winner_team_id);
        if(a&&b){a.played++;b.played++; if(w){w.wins++;w.points+=3;} const l=w&&w.id===a.id?b:a; l.losses++;}
      }
      standings.sort((a,b)=>b.points-a.points||b.wins-a.wins||a.losses-b.losses||a.name.localeCompare(b.name));
      const playerStats = sql.prepare(`SELECT ps.player_name,ps.team_id,tt.name AS team_name,SUM(ps.kills) AS kills,SUM(ps.deaths) AS deaths,SUM(ps.assists) AS assists,SUM(ps.mvp) AS mvp,COUNT(DISTINCT ps.match_id) AS matches_played FROM tournament_player_stats ps JOIN tournament_teams tt ON tt.id=ps.team_id WHERE ps.tournament_id=? GROUP BY ps.team_id,ps.player_name COLLATE NOCASE`).all(tid).map(x=>({...x,rating:playerRating(x)})).sort((a,b)=>b.rating-a.rating||b.mvp-a.mvp||b.kills-a.kills||a.deaths-b.deaths);
      const tournamentMvp = playerStats.filter(x=>x.mvp>0).sort((a,b)=>b.mvp-a.mvp||b.rating-a.rating||b.kills-a.kills)[0] || null;
      return send(res,200,{ok:true,tournament,teams,matches,standings,playerStats,tournamentMvp,playerRatingFormula:'K + 0.5×A + 5×MVP − 0.25×D'});
    }

    // Публичные профили команд и игроков (сохранено из v2.5)
    if (key === 'public/teams' && m === 'GET') {
      const site = getSite() || {};
      const visible = new Set((Array.isArray(site.teams) ? site.teams : []).map(x => norm(typeof x === 'string' ? x : x.name || '')).filter(Boolean));
      const rows = sql.prepare(`SELECT t.id, t.name, t.logo, t.roster, t.wins, t.losses, t.rating, t.status,
        u.name AS captain_name
        FROM teams t LEFT JOIN users u ON u.id = t.captain_user_id
        WHERE t.status = 'active' ORDER BY t.rating DESC, t.name COLLATE NOCASE`).all();
      const items = rows.filter(t => visible.has(norm(t.name))).map(t => {
        let roster = []; try { roster = JSON.parse(t.roster || '[]'); } catch {}
        const matchCount = sql.prepare("SELECT COUNT(*) AS n FROM matches WHERE (team1_id = ? OR team2_id = ?) AND status IN ('done','walkover')").get(t.id, t.id).n;
        return { id:t.id, name:t.name, logo:t.logo || '', wins:t.wins || 0, losses:t.losses || 0,
          rating:t.rating || 1000, captain:t.captain_name || '', roster:roster.slice(0,12).map((p,i)=>({
            id:String(t.id)+':'+i, name:str(p.name,40), nick:str(p.nick,40), role:str(p.role,40), bio:str(p.bio,160)
          })), matchCount };
      });
      return send(res, 200, { ok:true, items });
    }
    // ===== v5.0: сравнение команд и публичные профили капитанов =====
    if (key === 'public/teams/compare' && m === 'GET') {
      const ids = [...new Set(String(u.searchParams.get('ids') || '').split(',').map(x => Number(x)).filter(x => Number.isSafeInteger(x) && x > 0))];
      if (ids.length !== 2) return send(res,400,{error:'Для сравнения выберите ровно две команды.'});
      const site = getSite() || {};
      const visible = new Set((Array.isArray(site.teams) ? site.teams : []).map(x => norm(typeof x === 'string' ? x : x.name || '')).filter(Boolean));
      const rows = ids.map(id => sql.prepare(`SELECT t.id,t.name,t.logo,t.roster,t.wins,t.losses,t.rating,t.status,u.name AS captain_name
        FROM teams t LEFT JOIN users u ON u.id=t.captain_user_id WHERE t.id=?`).get(id));
      if (rows.some(t => !t || t.status !== 'active' || !visible.has(norm(t.name)))) return send(res,404,{error:'Одна из команд недоступна для сравнения.'});
      const items = rows.map(t => {
        let roster=[]; try { roster=JSON.parse(t.roster || '[]'); } catch {}
        const legacy = sql.prepare("SELECT COUNT(*) AS matches_played, SUM(CASE WHEN winner_id=? THEN 1 ELSE 0 END) AS wins, SUM(CASE WHEN winner_id IS NOT NULL AND winner_id!=? THEN 1 ELSE 0 END) AS losses FROM matches WHERE (team1_id=? OR team2_id=?) AND status IN ('done','walkover')").get(t.id,t.id,t.id,t.id);
        const tour = sql.prepare(`SELECT COUNT(DISTINCT tt.tournament_id) AS tournaments,
          COUNT(DISTINCT CASE WHEN m.status IN ('done','walkover') THEN m.id END) AS matches_played,
          SUM(CASE WHEN m.status IN ('done','walkover') AND m.winner_team_id=tt.id THEN 1 ELSE 0 END) AS wins,
          SUM(CASE WHEN m.status IN ('done','walkover') AND m.winner_team_id IS NOT NULL AND m.winner_team_id!=tt.id THEN 1 ELSE 0 END) AS losses,
          SUM(CASE WHEN t.status='completed' AND m.round=(SELECT MAX(mx.round) FROM tournament_matches mx WHERE mx.tournament_id=t.id) AND m.winner_team_id=tt.id THEN 1 ELSE 0 END) AS titles
          FROM tournament_teams tt JOIN tournaments t ON t.id=tt.tournament_id LEFT JOIN tournament_matches m ON m.tournament_id=t.id AND (m.team1_id=tt.id OR m.team2_id=tt.id)
          WHERE tt.name_norm=? AND t.status!='archived'`).get(norm(t.name));
        const stat = sql.prepare(`SELECT COALESCE(SUM(ps.kills),0) kills,COALESCE(SUM(ps.deaths),0) deaths,COALESCE(SUM(ps.assists),0) assists,COALESCE(SUM(ps.mvp),0) mvp
          FROM tournament_player_stats ps JOIN tournament_teams tt ON tt.id=ps.team_id JOIN tournaments tr ON tr.id=ps.tournament_id
          WHERE tt.name_norm=? AND tr.status!='archived'`).get(norm(t.name));
        const matches=(legacy.matches_played||0)+(tour.matches_played||0), wins=(legacy.wins||0)+(tour.wins||0), losses=(legacy.losses||0)+(tour.losses||0);
        return {id:t.id,name:t.name,logo:t.logo||'',captain:t.captain_name||'',roster_count:roster.length,rating:t.rating||1000,
          wins,losses,matches_played:matches,win_rate:matches?Math.round(wins/matches*1000)/10:0,
          tournaments:tour.tournaments||0,tournament_titles:tour.titles||0,
          kills:stat.kills,deaths:stat.deaths,assists:stat.assists,mvp:stat.mvp};
      });
      return send(res,200,{ok:true,items,compared_at:Date.now()});
    }
    const publicCaptainRoute = key.match(/^public\/captains\/(\d+)$/);
    if (publicCaptainRoute && m === 'GET') {
      const teamId=+publicCaptainRoute[1], site=getSite()||{};
      const visible=new Set((Array.isArray(site.teams)?site.teams:[]).map(x=>norm(typeof x==='string'?x:x.name||'')).filter(Boolean));
      const t=sql.prepare(`SELECT t.id,t.name,t.captain_user_id,u.name AS captain_name FROM teams t LEFT JOIN users u ON u.id=t.captain_user_id WHERE t.id=? AND t.status='active'`).get(teamId);
      if(!t||!visible.has(norm(t.name))||!t.captain_user_id) return send(res,404,{error:'Публичный профиль капитана недоступен.'});
      const tournaments=sql.prepare(`SELECT DISTINCT tr.id,tr.name,tr.status,tr.created_at FROM tournament_teams tt JOIN tournaments tr ON tr.id=tt.tournament_id WHERE tt.captain_user_id=? AND tr.status!='archived' ORDER BY tr.created_at DESC LIMIT 30`).all(t.captain_user_id);
      const total=sql.prepare(`SELECT COUNT(DISTINCT tournament_id) n FROM tournament_teams WHERE captain_user_id=?`).get(t.captain_user_id).n;
      return send(res,200,{ok:true,captain:{name:t.captain_name||'Капитан команды',team_id:t.id,team_name:t.name,tournaments_led:total},tournaments});
    }
    if (key.match(/^public\/teams\/\d+$/) && m === 'GET') {
      const tid = +key.split('/')[2];
      const site = getSite() || {};
      const visible = new Set((Array.isArray(site.teams) ? site.teams : []).map(x => norm(typeof x === 'string' ? x : x.name || '')).filter(Boolean));
      const t = sql.prepare(`SELECT t.id, t.name, t.logo, t.roster, t.wins, t.losses, t.rating, t.status, t.captain_user_id,
        u.name AS captain_name FROM teams t LEFT JOIN users u ON u.id=t.captain_user_id WHERE t.id=?`).get(tid);
      if (!t || t.status !== 'active' || !visible.has(norm(t.name))) return send(res, 404, { error:'Профиль команды не найден.' });
      let roster=[]; try { roster=JSON.parse(t.roster || '[]'); } catch {}
      const matches = sql.prepare(`SELECT m.id,m.round,m.pos,m.score,m.status,m.updated_at,
        t1.name AS team1_name,t2.name AS team2_name,tw.name AS winner_name
        FROM matches m LEFT JOIN teams t1 ON t1.id=m.team1_id LEFT JOIN teams t2 ON t2.id=m.team2_id
        LEFT JOIN teams tw ON tw.id=m.winner_id
        WHERE (m.team1_id=? OR m.team2_id=?) AND m.status IN ('done','walkover')
        ORDER BY m.updated_at DESC LIMIT 10`).all(tid,tid);
      const tournamentHistory=sql.prepare(`SELECT tr.id AS tournament_id,tr.name AS tournament_name,tr.status,tr.format,
        COUNT(DISTINCT CASE WHEN tm.status IN ('done','walkover') THEN tm.id END) AS matches_played,
        SUM(CASE WHEN tm.status IN ('done','walkover') AND tm.winner_team_id=tt.id THEN 1 ELSE 0 END) AS wins,
        SUM(CASE WHEN tm.status IN ('done','walkover') AND tm.winner_team_id IS NOT NULL AND tm.winner_team_id!=tt.id THEN 1 ELSE 0 END) AS losses,
        MAX(CASE WHEN tr.status='completed' AND tm.round=(SELECT MAX(mx.round) FROM tournament_matches mx WHERE mx.tournament_id=tr.id) AND tm.winner_team_id=tt.id THEN 1 ELSE 0 END) AS champion
        FROM tournament_teams tt JOIN tournaments tr ON tr.id=tt.tournament_id LEFT JOIN tournament_matches tm ON tm.tournament_id=tr.id AND (tm.team1_id=tt.id OR tm.team2_id=tt.id)
        WHERE tt.name_norm=? AND tr.status!='archived' GROUP BY tr.id ORDER BY tr.created_at DESC LIMIT 30`).all(norm(t.name));
      const playerStats=sql.prepare(`SELECT ps.player_name,SUM(ps.kills) kills,SUM(ps.deaths) deaths,SUM(ps.assists) assists,SUM(ps.mvp) mvp,COUNT(DISTINCT ps.match_id) matches_played
        FROM tournament_player_stats ps JOIN tournament_teams tt ON tt.id=ps.team_id JOIN tournaments tr ON tr.id=ps.tournament_id
        WHERE tt.name_norm=? AND tr.status!='archived' GROUP BY ps.player_name COLLATE NOCASE ORDER BY mvp DESC,kills DESC LIMIT 12`).all(norm(t.name));
      const legacySummary=sql.prepare("SELECT COUNT(*) AS matches_played FROM matches WHERE (team1_id=? OR team2_id=?) AND status IN ('done','walkover')").get(t.id,t.id);
      const tournamentMatches=tournamentHistory.reduce((n,x)=>n+(x.matches_played||0),0);
      const titles=tournamentHistory.filter(x=>x.champion).length;
      const tournamentWins=tournamentHistory.reduce((n,x)=>n+(x.wins||0),0), tournamentLosses=tournamentHistory.reduce((n,x)=>n+(x.losses||0),0);
      const totalWins=(t.wins||0)+tournamentWins, totalLosses=(t.losses||0)+tournamentLosses;
      const achievements=[];
      if(titles) achievements.push({code:'champion',label:'Чемпион турнира',count:titles});
      if(totalWins>=10) achievements.push({code:'veteran',label:'10+ побед',count:totalWins});
      if(tournamentHistory.length>=3) achievements.push({code:'regular',label:'Постоянный участник',count:tournamentHistory.length});
      if(playerStats.some(x=>x.mvp>0)) achievements.push({code:'mvp',label:'В составе есть MVP',count:playerStats.reduce((n,x)=>n+x.mvp,0)});
      return send(res,200,{ok:true,team:{id:t.id,name:t.name,logo:t.logo||'',wins:totalWins,losses:totalLosses,matchesPlayed:(legacySummary.matches_played||0)+tournamentMatches,
        rating:t.rating||1000,captain:t.captain_name||'',captain_user_id:t.captain_user_id||null,roster:roster.slice(0,12).map((p,i)=>({
          id:String(t.id)+':'+i,name:str(p.name,40),nick:str(p.nick,40),role:str(p.role,40),bio:str(p.bio,160)
        })),matches,tournamentHistory,playerStats,achievements}});
    }

    if (key === 'login' && m === 'POST') {
      const a = ip(req), f = fails.get(a) || { n: 0, until: 0 };
      if (f.until > Date.now()) return send(res, 429, { error: 'Слишком много попыток. Подождите несколько минут.' });
      const b = await body(req), login = str(b.user, 40).toLowerCase();
      let acc = sql.prepare('SELECT id, salt, hash, role, name, active, must_set_password, created_at, totp_enabled, totp_secret, totp_last, totp_recovery FROM users WHERE login = ?').get(login);
      if (!acc) { // fallback to old admins table
        const old = sql.prepare('SELECT salt, hash FROM admins WHERE login = ?').get(login);
        if (old) acc = { id: 0, salt: old.salt, hash: old.hash, role: 'admin', name: login, active: 1, must_set_password: 0 };
      }
      if ((ufail.get(login) || []).filter(t => Date.now() - t < 900000).length >= 20) return send(res, 429, { error: 'Слишком много неверных попыток для этой учётной записи. Подождите 15 минут.' });
      // Аккаунт с must_set_password и без заданного пароля (временный хэш) — вход только после установки невозможен без специального флоу;
      // если must_set_password=1 и передан любой пароль при создании без пароля — ниже обработаем через отдельный endpoint set-first.
      // Обычный вход: если must_set_password и пароль ещё не задан пользователем — отклоняем с подсказкой, либо принимаем если хэш совпал (админ задал временный).
      const ok = acc && acc.active !== 0 ? crypto.timingSafeEqual(Buffer.from(hashPw(String(b.pass || ''), acc.salt), 'hex'), Buffer.from(acc.hash, 'hex')) : (hashPw(String(b.pass || ''), '00000000000000000000000000000000'), false);
      if (!ok) {
        // Специальный случай: учётка создана без пароля (must_set_password=1). Разрешаем «вход» без пароля, чтобы сразу задать свой.
        {
          const ul = ufail.get(login) || []; ul.push(Date.now()); ufail.set(login, ul.filter(t => Date.now() - t < 900000)); strike(addr, 1, 'login'); f.n++; if (f.n >= 5) { f.until = Date.now() + 300000; f.n = 0; } fails.set(a, f); return send(res, 401, { error: 'Неверный логин или пароль.' });
        }
      }
      if (acc && acc.active === 0) return send(res, 403, { error: 'Учётная запись заблокирована.' });
      if (acc && acc.must_set_password && Date.now() - (acc.created_at || 0) > 86400000) return send(res, 403, { error: 'Срок одноразового кода истёк. Попросите администратора создать учётку заново.' });
      // Второй фактор: пароль уже верный, теперь нужен код из приложения или резервный код
      let via2fa = null;
      if (acc && acc.totp_enabled) {
        const code = str(b.code, 20);
        if (!code) return send(res, 200, { ok: false, need_2fa: true });
        via2fa = verify2fa(acc, code);
        if (!via2fa) {
          const ul = ufail.get(login) || []; ul.push(Date.now(), Date.now(), Date.now()); ufail.set(login, ul.filter(t => Date.now() - t < 900000)); // неверный код весит втрое больше пароля
          strike(addr, 2, 'login-2fa'); f.n++; if (f.n >= 5) { f.until = Date.now() + 300000; f.n = 0; } fails.set(a, f);
          try { sql.prepare('INSERT INTO action_log (user_id, action, details, at) VALUES (?, ?, ?, ?)').run(acc.id || null, 'login_2fa_fail', 'IP ' + String(a).slice(0, 45), Date.now()); } catch (e) {}
          return send(res, 401, { error: 'Неверный код подтверждения.', need_2fa: true });
        }
      }
      fails.delete(a); const sid = crypto.randomBytes(32).toString('hex'); sql.prepare('DELETE FROM sessions WHERE exp < ?').run(Date.now()); sql.prepare('INSERT INTO sessions (id, login, exp) VALUES (?, ?, ?)').run(hs(sid), login, Date.now() + 43200000);
      try { sql.prepare('INSERT INTO action_log (user_id, action, details, at) VALUES (?, ?, ?, ?)').run(acc.id || null, 'login', 'IP ' + String(a).slice(0, 45) + (via2fa ? ' 2FA:' + via2fa : ''), Date.now()); } catch (e) {}
      let recoveryLeft; if (via2fa === 'recovery') { try { recoveryLeft = JSON.parse(sql.prepare('SELECT totp_recovery FROM users WHERE id = ?').get(acc.id).totp_recovery || '[]').length; } catch { recoveryLeft = 0; } }
      return send(res, 200, { ok: true, role: acc.role || 'admin', name: acc.name || login, must_set_password: !!acc.must_set_password, totp: !!(acc && acc.totp_enabled), must_2fa: REQUIRE_2FA && FULL_ROLES.includes(acc.role) && !(acc && acc.totp_enabled), recovery_left: recoveryLeft }, { 'Set-Cookie': `sid=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${process.env.SECURE ? '; Secure' : ''}` });
    }
    if (key === 'logout' && m === 'POST') {
      const sid = cookie(req).sid;
      let logoutLogin = null;
      if (sid) {
        const s = sql.prepare('SELECT login FROM sessions WHERE id = ?').get(hs(sid));
        if (s) logoutLogin = s.login;
        sql.prepare('DELETE FROM sessions WHERE id = ?').run(hs(sid));
      }
      if (logoutLogin) {
        const u = sql.prepare('SELECT id FROM users WHERE login = ?').get(logoutLogin);
        try { sql.prepare('INSERT INTO action_log (user_id, action, details, at) VALUES (?, ?, ?, ?)').run(u && u.id || null, 'logout', '', Date.now()); } catch (e) {}
      }
      return send(res, 200, { ok: true }, { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
    }

    if (key === 'challenge' && m === 'GET') {
      if (!hitIp(rlChal, addr, 60000, 12)) { strike(addr, 1, 'challenge'); return send(res, 429, { error: 'Слишком часто. Подождите минуту.' }); }
      heat.push(Date.now()); const nonce = crypto.randomBytes(8).toString('hex'), bits = currentBits(), base = nonce + '.' + bits + '.' + Date.now();
      return send(res, 200, { ok: true, token: base + '.' + sign(base), nonce, bits });
    }

    if (key === 'register' && m === 'POST') {
      const st = regState(getSite());
      if (!st.open) return send(res, 403, { error: { closed: 'Приём заявок закрыт.', full: 'Приём заявок закрыт: сетка заполнена, свободных мест нет.', cap: 'Приём заявок закрыт: набрано максимальное число заявок.', expired: 'Приём заявок завершён.' }[st.reason] || 'Приём заявок закрыт.' });
      const b = await body(req, 12000);
      if (b.web) { strike(addr, 10, 'honeypot'); return send(res, 200, { ok: true }); } // бота «принимаем» молча и блокируем
      const pw = verifyPow(b.pow); if (pw) { strike(addr, pw.w, 'pow'); return send(res, 400, { error: pw.err }); }
      const r = { id: crypto.randomUUID(), at: Date.now(), status: 'new', confirmed: false, ctoken: crypto.randomBytes(16).toString('hex'), team: str(b.team, 40), captain: str(b.captain, 40), contact: str(b.contact, 60), roster: str(b.roster, 600) };
      const rosterLines = r.roster.split('\n').map(x => x.trim()).filter(Boolean);
      const fail = msg => { strike(addr, 1, 'invalid'); return send(res, 400, { error: msg }); };
      if (!/^[\p{L}\p{N} ._\-\[\]()!&'+#|]{2,40}$/u.test(r.team)) return fail('Название команды: 2–40 символов, буквы, цифры и простые знаки.');
      if (!/^[\p{L}\p{N} ._\-']{2,40}$/u.test(r.captain)) return fail('Имя капитана: 2–40 символов, только буквы, цифры и простые знаки.');
      if (r.contact && !/^[@\p{L}\p{N}._\-#:+ ]{3,60}$/u.test(r.contact)) return fail('Контакт (если указываете): 3–60 символов, без ссылок.');
      if (rosterLines.length > 12 || rosterLines.some(x => x.length > 40)) return fail('Состав: не больше 12 игроков, по одному в строке, до 40 символов.');
      if (URLISH.test([r.team, r.captain, r.contact, r.roster].join(' '))) return fail('Ссылки в заявке не допускаются.');
      if (b.consent !== true) return send(res, 400, { error: 'Нужно согласие на обработку данных.' });
      if (b.terms !== true) return send(res, 400, { error: 'Нужно принять Пользовательское соглашение.' });
      const site = getSite();
      if (sql.prepare("SELECT 1 FROM regs WHERE team_norm = ? AND status != 'rejected'").get(norm(r.team)) || ((site && site.teams) || []).some(t => norm(t) === norm(r.team))) return send(res, 409, { error: 'Команда с таким названием уже подала заявку.' });
      if (r.contact && sql.prepare("SELECT COUNT(*) AS n FROM regs WHERE lower(contact) = ? AND status != 'rejected'").get(r.contact.toLowerCase()).n >= 2) return send(res, 409, { error: 'С этим контактом уже подано максимальное число заявок.' });
      if (!hitIp(regHour, addr, 3600000, 3) || !hitIp(regDay, addr, 86400000, 8)) { strike(addr, 2, 'reg-rate'); return send(res, 429, { error: 'Слишком много заявок с вашего адреса. Попробуйте позже.' }); }
      if (!hit(regAll, 'all', 3600000, 300)) return send(res, 429, { error: 'Сейчас слишком много заявок. Попробуйте через час.' });
      if (sql.prepare('SELECT COUNT(*) AS n FROM regs').get().n >= 100000) return send(res, 503, { error: 'Приём заявок временно закрыт.' });
      // Автоматический режим: заявка сразу подтверждена — админам не нужно писать капитану
      const autoConfirm = 1;
      sql.prepare('INSERT INTO regs (id, at, status, confirmed, confirmed_at, ctoken, team, team_norm, captain, contact, roster, consent_at, terms_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(r.id, r.at, r.status, autoConfirm, r.at, r.ctoken, r.team, norm(r.team), r.captain, r.contact, r.roster, r.at, r.at);
      const row = sql.prepare('SELECT status, confirmed FROM regs WHERE id = ?').get(r.id);
      // Очереди нет: если места не оказалось — удаляем заявку и отвечаем, что сетка заполнена
      if (row.status !== 'accepted') {
        sql.prepare('DELETE FROM regs WHERE id = ?').run(r.id);
        return send(res, 403, { error: 'Приём заявок закрыт: сетка заполнена, свободных мест нет.' });
      }
      return send(res, 200, { ok: true, status: row.status, confirmed: !!row.confirmed, ctoken: r.ctoken });
    }

    if (key === 'confirm') {
      const now = Date.now();
      if (!hitIp(confHit, addr, 3600000, 30)) { strike(addr, 1, 'confirm'); return send(res, 429, { error: 'Слишком много попыток. Попробуйте позже.' }); }

      const token = m === 'GET' ? u.searchParams.get('token') : (await body(req)).token;
      const row = /^[a-f0-9]{32}$/.test(String(token || '')) && sql.prepare('SELECT * FROM regs WHERE ctoken = ?').get(token), r = row && regRow(row);
      if (!r) { strike(addr, 1, 'confirm-bad'); return send(res, 404, { error: 'Ссылка недействительна или устарела.' }); }
      if (m === 'GET') return send(res, 200, { ok: true, team: r.team, confirmed: !!r.confirmed });
      if (m === 'POST') { if (!r.confirmed) { sql.prepare('UPDATE regs SET confirmed = 1, confirmed_at = ? WHERE id = ?').run(now, r.id); } return send(res, 200, { ok: true, team: r.team }); }
      return send(res, 405, { error: 'Метод не поддерживается.' });
    }
    // ===== Новые эндпоинты v2.0 (доступны авторизованным) =====
    if (user) {
      // Уведомления
      if (key === 'notifications' && m === 'GET') {
        const items = sql.prepare('SELECT id, type, title, body, link, read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(user.id);
        return send(res, 200, { ok: true, items });
      }
      if (key === 'notifications/read' && m === 'POST') {
        const b = await body(req);
        if (b.all) sql.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').run(user.id);
        else if (b.id) sql.prepare('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?').run(b.id, user.id);
        return send(res, 200, { ok: true });
      }
      // Профиль команды капитана
      if (key === 'my-team' && m === 'GET') {
        if (user.role !== 'captain' && user.role !== 'admin') return send(res, 403, { error: 'Только для капитанов.' });
        let team = null;
        if (user.team_id) team = sql.prepare('SELECT * FROM teams WHERE id = ?').get(user.team_id);
        if (!team) {
          // Попробуем найти по заявке
          const reg = sql.prepare('SELECT * FROM regs WHERE user_id = ? OR (captain = ? AND contact = ?) ORDER BY at DESC LIMIT 1').get(user.id, user.name, user.contact);
          if (reg) team = { id: reg.team_id, name: reg.team, roster: reg.roster, status: reg.status };
        }
        return send(res, 200, { ok: true, team: team ? { id: team.id, name: team.name, logo: team.logo || '', roster: typeof team.roster === 'string' ? JSON.parse(team.roster || '[]') : team.roster, wins: team.wins || 0, losses: team.losses || 0, rating: team.rating || 1000, status: team.status } : null });
      }
      if (key === 'my-team' && m === 'PUT') {
        if (user.role !== 'captain') return send(res, 403, { error: 'Только капитан может редактировать команду.' });
        const b = await body(req, 500000);
        if (!user.team_id) return send(res, 400, { error: 'Команда ещё не создана. Сначала подайте заявку.' });
        // Логотип: data-URL, до ~300 КБ исходного файла (~420 КБ в base64)
        let logo = str(b.logo, 450000);
        if (logo && !/^data:image\/(png|jpeg|jpg|webp|gif);base64,/i.test(logo)) return send(res, 400, { error: 'Логотип: только PNG/JPEG/WebP (data-URL).' });
        if (logo && logo.length > 420000) return send(res, 400, { error: 'Логотип слишком большой (макс. ~300 КБ). Сожмите изображение.' });
        const roster = Array.isArray(b.roster) ? b.roster.slice(0, 12).map(p => ({ name: str(p.name, 40), nick: str(p.nick, 40), role: str(p.role, 40), bio: str(p.bio, 160) })).filter(p => p.name || p.nick) : [];
        sql.prepare('UPDATE teams SET logo = ?, roster = ? WHERE id = ? AND captain_user_id = ?').run(logo, JSON.stringify(roster), user.team_id, user.id);
        // Синхронизируем roster в заявку
        sql.prepare('UPDATE regs SET roster = ? WHERE team_id = ?').run(roster.map(p => p.nick || p.name).join(', '), user.team_id);
        addNotification(user.id, 'team', 'Состав обновлён', 'Изменения в составе команды сохранены.');
        return send(res, 200, { ok: true });
      }
    }

    // Регистрация капитана (публичная)
    if (key === 'register-captain' && m === 'POST') {
      const b = await body(req, 16000);
      if (b.web) { strike(addr, 10, 'captain-register-honeypot'); return send(res, 200, { ok: true }); }
      const pw = verifyPow(b.pow); if (pw) { strike(addr, pw.w, 'captain-register-pow'); return send(res, 400, { error: pw.err }); }
      const login = str(b.login, 40).toLowerCase();
      const pass = String(b.pass || '');
      const name = str(b.name, 60);
      const contact = str(b.contact, 80);
      const teamName = str(b.team, 40);
      if (b.consent !== true) return send(res, 400, { error: 'Нужно согласие на обработку данных.' });
      if (b.terms !== true) return send(res, 400, { error: 'Нужно принять Пользовательское соглашение.' });
      if (!/^[a-z0-9_.-]{3,40}$/i.test(login)) return send(res, 400, { error: 'Логин: 3–40 символов, латинские буквы, цифры, точка, дефис или подчёркивание.' });
      if (pass.length < 8 || pass.length > 80) return send(res, 400, { error: 'Пароль должен содержать от 8 до 80 символов.' });
      if (!teamName || !/^[\p{L}\p{N} ._\-\[\]()!&'+#|]{2,40}$/u.test(teamName)) return send(res, 400, { error: 'Укажите корректное название команды (2–40 символов).' });
      if (!contact || contact.length < 3 || URLISH.test(contact)) return send(res, 400, { error: 'Укажите корректный контакт без ссылок.' });
      if (sql.prepare('SELECT id FROM users WHERE login = ?').get(login)) return send(res, 409, { error: 'Такой логин уже занят.' });
      if (sql.prepare('SELECT id FROM teams WHERE name_norm = ?').get(norm(teamName))) return send(res, 409, { error: 'Команда с таким названием уже есть.' });
      if (sql.prepare("SELECT id FROM users WHERE lower(contact)=? AND active=1").get(contact.toLowerCase())) return send(res, 409, { error: 'Аккаунт с таким контактом уже зарегистрирован. Если это ваша команда, обратитесь к организаторам.' });
      // Антиспам: не более 5 аккаунтов с IP за час и 12 за сутки; лимит учитывает общие сети.
      if (!hitIp(captainRegHour, addr, 3600000, 5) || !hitIp(captainRegDay, addr, 86400000, 12)) { strike(addr, 2, 'captain-register-rate'); return send(res, 429, { error: 'Слишком много регистраций с вашего адреса. Попробуйте позже.' }); }
      const salt = crypto.randomBytes(16).toString('hex');
      const uid = sql.prepare('INSERT INTO users (login, salt, hash, role, name, contact, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(login, salt, hashPw(pass, salt), 'captain', name || login, contact, Date.now()).lastInsertRowid;
      const tid = sql.prepare('INSERT INTO teams (name, name_norm, captain_user_id, roster, created_at) VALUES (?, ?, ?, ?, ?)').run(teamName, norm(teamName), uid, '[]', Date.now()).lastInsertRowid;
      sql.prepare('UPDATE users SET team_id = ? WHERE id = ?').run(tid, uid);
      // Создаём заявку
      const ctoken = crypto.randomBytes(16).toString('hex');
      const rid = crypto.randomUUID();
      sql.prepare('INSERT INTO regs (id, at, status, confirmed, ctoken, team, team_norm, captain, contact, roster, user_id, team_id, consent_at, terms_at) VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(rid, Date.now(), 'new', ctoken, teamName, norm(teamName), name || login, contact, '', uid, tid, Date.now(), Date.now());
      addNotification(uid, 'reg', 'Заявка создана', 'Ваша команда «' + teamName + '» подала заявку на участие. Ожидайте решения организаторов.', '/#register');
      // Уведомим админов
      const admins = sql.prepare('SELECT id FROM users WHERE role = ? AND active = 1').all('admin');
      for (const a of admins) addNotification(a.id, 'new_reg', 'Новая заявка', 'Команда «' + teamName + '» от ' + (name || login), '/#admin');
      return send(res, 200, { ok: true, message: 'Аккаунт капитана и заявка созданы. Войдите под своим логином.' });
    }

    // Публичные эндпоинты (без входа)
    if (key === 'ratings' && m === 'GET') {
      // Стендинги: сортировка по победам, без фейкового Elo
      const teams = sql.prepare("SELECT id, name, logo, wins, losses, rating, status FROM teams WHERE status != 'archived' ORDER BY wins DESC, losses ASC, name LIMIT 100").all();
      return send(res, 200, { ok: true, items: teams });
    }
    if (key === 'roles' && m === 'GET') {
      return send(res, 200, { ok: true, roles: ROLE_LIST.map(id => ({ id, label: ROLE_LABEL[id] || id })) });
    }
    if (key === 'archive' && m === 'GET') {
      const site = siteNow();
      return send(res, 200, { ok: true, archive: Array.isArray(site.archive) ? site.archive : [], champions: Array.isArray(site.champions) ? site.champions : [], mvp: site.mvp || null });
    }
    if (key === 'matches' && m === 'GET') {
      const rows = sql.prepare(`SELECT m.*, t1.name AS team1_name, t2.name AS team2_name, tw.name AS winner_name, u.name AS judge_name
        FROM matches m
        LEFT JOIN teams t1 ON t1.id = m.team1_id
        LEFT JOIN teams t2 ON t2.id = m.team2_id
        LEFT JOIN teams tw ON tw.id = m.winner_id
        LEFT JOIN users u ON u.id = m.judge_id
        ORDER BY m.round, m.pos`).all();
      return send(res, 200, { ok: true, items: rows });
    }

    if (!user) return send(res, 401, { error: 'Нужен вход.' });
    // Далее — только авторизованные. Админские действия требуют role === 'admin'
    const isAdmin = can(user.role, 'full');
    const canManage = can(user.role, 'manage');
    const canRegs = can(user.role, 'regs');
    const canJudge = can(user.role, 'judge');
    const canAssignJudge = can(user.role, 'assign_judge');
    const canUsers = can(user.role, 'users');

    // ===== v3.3: полный CSV-отчёт независимого турнира =====
    const tournamentExportRoute = key.match(/^tournaments\/(\d+)\/export\.csv$/);
    if (tournamentExportRoute && m === 'GET') {
      if (!isAdmin && !canRegs && !canJudge) return send(res,403,{error:'Недостаточно прав для экспорта турнира.'});
      const tid = +tournamentExportRoute[1];
      const tournament = sql.prepare('SELECT id,name,game,format,size,status,bo,created_at,updated_at FROM tournaments WHERE id=?').get(tid);
      if (!tournament) return send(res,404,{error:'Турнир не найден.'});
      const teams = sql.prepare(`SELECT id,name,seed FROM tournament_teams WHERE tournament_id=? ORDER BY COALESCE(seed,9999),name COLLATE NOCASE`).all(tid);
      const matches = sql.prepare(`SELECT m.round,m.pos,m.status,m.score,m.scheduled_at,a.name AS team1,b.name AS team2,w.name AS winner,u.name AS judge_name,u.login AS judge_login
        FROM tournament_matches m LEFT JOIN tournament_teams a ON a.id=m.team1_id LEFT JOIN tournament_teams b ON b.id=m.team2_id
        LEFT JOIN tournament_teams w ON w.id=m.winner_team_id LEFT JOIN users u ON u.id=m.judge_user_id
        WHERE m.tournament_id=? ORDER BY m.round,m.pos`).all(tid);
      const history = sql.prepare(`SELECT h.event,h.details,h.created_at,u.name AS actor_name,u.login AS actor_login
        FROM tournament_history h LEFT JOIN users u ON u.id=h.actor_user_id WHERE h.tournament_id=? ORDER BY h.created_at,h.id`).all(tid);
      const csvCell = value => { value = csvSafe(value);
        let v = String(value == null ? '' : value).replace(/[\r\n]+/g,' ').trim();
        if (/^[\s]*[=+\-@\t]/.test(v)) v = "'" + v; // защита от CSV/formula injection
        return '"' + v.replace(/"/g,'""') + '"';
      };
      const rows = [['Раздел','Раунд','Матч','Команда','Соперник','Победитель','Счёт','Статус','Судья','Запланировано','Событие','Детали','Автор','Дата']];
      rows.push(['Турнир','','',tournament.name,tournament.game,'',`BO${tournament.bo}`,tournament.status,'','','','','']);
      for (const team of teams) rows.push(['Команда','','',team.name,'','','',team.seed ? `Посев ${team.seed}` : 'Без посева','','','','','']);
      for (const mt of matches) rows.push(['Матч',mt.round,mt.pos,mt.team1,mt.team2,mt.winner,mt.score,mt.status,mt.judge_name || mt.judge_login,'','','','']);
      for (const ev of history) rows.push(['История','','','','','','','','',ev.event,ev.details,ev.actor_name || ev.actor_login || 'Система',new Date(ev.created_at).toISOString()]);
      const csv = '\uFEFF' + rows.map(row=>row.map(csvCell).join(';')).join('\r\n') + '\r\n';
      const slug = String(tournament.name).toLowerCase().replace(/[^a-zа-яё0-9]+/gi,'-').replace(/^-|-$/g,'').slice(0,48) || 'tournament';
      return sendText(req,res,200,'text/csv; charset=utf-8',csv,{'Content-Disposition':`attachment; filename="major-css-${tid}-${slug}.csv"`,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'});
    }

    // ===== v3.2: журнал событий независимого турнира =====
    const tournamentHistoryRoute = key.match(/^tournaments\/(\d+)\/history$/);
    if (tournamentHistoryRoute && m === 'GET') {
      if (!can(user.role, 'regs') && !can(user.role, 'judge')) return send(res,403,{error:'Недостаточно прав для просмотра журнала.'});
      const tid = +tournamentHistoryRoute[1];
      if (!sql.prepare('SELECT id FROM tournaments WHERE id=?').get(tid)) return send(res,404,{error:'Турнир не найден.'});
      const items = sql.prepare(`SELECT h.id,h.event,h.details,h.created_at,u.name AS actor_name,u.login AS actor_login
        FROM tournament_history h LEFT JOIN users u ON u.id=h.actor_user_id
        WHERE h.tournament_id=? ORDER BY h.created_at DESC,h.id DESC LIMIT 200`).all(tid);
      return send(res,200,{ok:true,items});
    }

    // ===== v3.1+: заявки капитанов, судьи и апелляции =====
    const appRoute = key.match(/^tournaments\/(\d+)\/(applications|appeals)$/);
    const appDecision = key.match(/^tournaments\/(\d+)\/applications\/(\d+)$/);
    const appealDecision = key.match(/^tournaments\/(\d+)\/appeals\/(\d+)$/);
    const judgeAssign = key.match(/^tournaments\/(\d+)\/matches\/(\d+)\/judge$/);
    if (appRoute) {
      const tid=+appRoute[1], kind=appRoute[2], t=sql.prepare('SELECT * FROM tournaments WHERE id=?').get(tid);
      if(!t) return send(res,404,{error:'Турнир не найден.'});
      if(kind==='applications' && m==='POST') {
        if(!can(user.role,'captain')) return send(res,403,{error:'Подать заявку может капитан команды.'});
        if(!hit(tournamentAppUser,user.id,3600000,5) || !hitIp(tournamentAppIp,addr,3600000,15)) return send(res,429,{error:'Слишком много заявок. Попробуйте позже.'},{'Retry-After':'3600'});
        if(t.status!=='registration') return send(res,409,{error:'Регистрация на этот турнир сейчас закрыта.'});
        if(!user.team_id) return send(res,400,{error:'У аккаунта не привязана команда.'});
        const team=sql.prepare('SELECT id,name,captain_user_id FROM teams WHERE id=?').get(user.team_id);
        if(!team || team.captain_user_id!==user.id) return send(res,403,{error:'Подать заявку может только капитан своей команды.'});
        const prior=sql.prepare('SELECT id,status FROM tournament_applications WHERE tournament_id=? AND team_id=?').get(tid,team.id);
        if(prior && prior.status!=='rejected') return send(res,409,{error:'Ваша команда уже подавала заявку на этот турнир.'});
        const current=sql.prepare('SELECT COUNT(*) n FROM tournament_teams WHERE tournament_id=?').get(tid).n;
        const pending=sql.prepare("SELECT COUNT(*) n FROM tournament_applications WHERE tournament_id=? AND status='pending'").get(tid).n;
        if(current+pending>=t.size) return send(res,409,{error:'Свободных мест больше нет.'});
        const b=await body(req), note=str(b.note,300);
        const id=prior ? prior.id : sql.prepare('INSERT INTO tournament_applications (tournament_id,team_id,captain_user_id,note,created_at) VALUES (?,?,?,?,?)').run(tid,team.id,user.id,note,Date.now()).lastInsertRowid;
        if(prior) sql.prepare("UPDATE tournament_applications SET status='pending',note=?,created_at=?,decided_at=NULL,decided_by=NULL WHERE id=?").run(note,Date.now(),prior.id);
        for(const a of sql.prepare("SELECT id FROM users WHERE active=1 AND role IN ('owner','deputy_owner','chief_admin','admin','senior_judge')").all()) addNotification(a.id,'tournament_application','Новая заявка на турнир',team.name+' — '+t.name,'/#tournaments');
        addNotification(user.id,'tournament_application','Заявка отправлена','Команда «'+team.name+'» ожидает подтверждения.','/#tournaments');
        logTournamentHistory(tid,user.id,'application_submitted','Команда: '+team.name);
        return send(res,201,{ok:true,id});
      }
      if(kind==='applications' && m==='GET') {
        if(!can(user.role,'regs')) return send(res,403,{error:'Недостаточно прав.'});
        const items=sql.prepare('SELECT a.*,tt.name AS team_name,u.login AS captain_login,u.name AS captain_name FROM tournament_applications a JOIN teams tt ON tt.id=a.team_id JOIN users u ON u.id=a.captain_user_id WHERE a.tournament_id=? ORDER BY CASE a.status WHEN \'pending\' THEN 0 ELSE 1 END,a.created_at DESC').all(tid);
        return send(res,200,{ok:true,items});
      }
      if(kind==='appeals' && m==='POST') {
        if(!can(user.role,'captain')) return send(res,403,{error:'Апелляцию может подать капитан команды.'});
        const b=await body(req), mid=+b.match_id, reason=str(b.reason,1000);
        const mt=sql.prepare('SELECT * FROM tournament_matches WHERE id=? AND tournament_id=?').get(mid,tid);
        const team=mt&&sql.prepare('SELECT id FROM tournament_teams WHERE tournament_id=? AND captain_user_id=? AND id IN (?,?)').get(tid,user.id,mt.team1_id,mt.team2_id);
        if(!team) return send(res,403,{error:'Апелляция доступна капитану команды — участника этого матча.'});
        if(reason.length<10) return send(res,400,{error:'Опишите причину подробнее (минимум 10 символов).'});
        const id=sql.prepare('INSERT INTO tournament_appeals (tournament_id,match_id,team_id,user_id,reason,created_at) VALUES (?,?,?,?,?,?)').run(tid,mid,team.id,user.id,reason,Date.now()).lastInsertRowid;
        for(const a of sql.prepare("SELECT id FROM users WHERE active=1 AND role IN ('owner','deputy_owner','chief_admin','admin','chief_appeals','appeals')").all()) addNotification(a.id,'tournament_appeal','Новая апелляция',t.name+' · матч '+mid,'/#tournaments');
        logTournamentHistory(tid,user.id,'appeal_submitted','Апелляция #'+id+'; матч '+mid+'; команда '+team.id);
        return send(res,201,{ok:true,id});
      }
      if(kind==='appeals' && m==='GET') {
        if(!can(user.role,'regs')) return send(res,403,{error:'Недостаточно прав.'});
        const items=sql.prepare('SELECT a.*,tt.name AS team_name,u.login AS captain_login FROM tournament_appeals a JOIN tournament_teams tt ON tt.id=a.team_id JOIN users u ON u.id=a.user_id WHERE a.tournament_id=? ORDER BY a.created_at DESC').all(tid);
        return send(res,200,{ok:true,items});
      }
    }
    if(appDecision && m==='PATCH') {
      if(!can(user.role,'regs')) return send(res,403,{error:'Недостаточно прав.'});
      const tid=+appDecision[1], aid=+appDecision[2], b=await body(req), status=b.status;
      if(!['approved','rejected'].includes(status)) return send(res,400,{error:'Недопустимое решение.'});
      const a=sql.prepare('SELECT * FROM tournament_applications WHERE id=? AND tournament_id=?').get(aid,tid), t=sql.prepare('SELECT * FROM tournaments WHERE id=?').get(tid);
      if(!a||!t) return send(res,404,{error:'Заявка не найдена.'});
      if(a.status!=='pending') return send(res,409,{error:'Заявка уже обработана.'});
      if(status==='approved') {
        const count=sql.prepare('SELECT COUNT(*) n FROM tournament_teams WHERE tournament_id=?').get(tid).n;
        if(count>=t.size) return send(res,409,{error:'Лимит команд уже заполнен.'});
        const team=sql.prepare('SELECT name,name_norm FROM teams WHERE id=?').get(a.team_id);
        try { sql.prepare('INSERT INTO tournament_teams (tournament_id,name,name_norm,seed,created_at,captain_user_id) VALUES (?,?,?,?,?,?)').run(tid,team.name,team.name_norm,count+1,Date.now(),a.captain_user_id); }
        catch(e){ if(!String(e.message).includes('UNIQUE')) throw e; return send(res,409,{error:'Команда с таким названием уже участвует.'}); }
      }
      sql.prepare('UPDATE tournament_applications SET status=?,decided_at=?,decided_by=? WHERE id=?').run(status,Date.now(),user.id,aid);
      addNotification(a.captain_user_id,'tournament_application_decision',status==='approved'?'Заявка одобрена':'Заявка отклонена',t.name+(status==='approved'?' — команда добавлена в участники.':' — организаторы отклонили заявку.'),'/#tournaments');
      logTournamentHistory(tid,user.id,'application_'+status,'Заявка #'+aid+'; команда ID '+a.team_id);
      return send(res,200,{ok:true});
    }
    if(judgeAssign && m==='POST') {
      if(!canAssignJudge) return send(res,403,{error:'Назначать судей может старший судья или администратор.'});
      const tid=+judgeAssign[1], mid=+judgeAssign[2], b=await body(req), judgeId=+b.judge_user_id;
      const mt=sql.prepare('SELECT id FROM tournament_matches WHERE id=? AND tournament_id=?').get(mid,tid);
      const judge=sql.prepare("SELECT id,name FROM users WHERE id=? AND active=1 AND role IN ('judge','senior_judge','owner','deputy_owner','chief_admin','admin')").get(judgeId);
      if(!mt||!judge) return send(res,400,{error:'Укажите существующий матч и активного судью.'});
      sql.prepare('UPDATE tournament_matches SET judge_user_id=?,updated_at=? WHERE id=?').run(judgeId,Date.now(),mid);
      addNotification(judgeId,'tournament_judge_assignment','Назначен матч','Вас назначили судьёй матча №'+mid+' турнира #'+tid,'/#tournaments');
      logTournamentHistory(tid,user.id,'judge_assigned','Матч #'+mid+'; судья '+(judge.name||judge.id)+' (ID '+judgeId+')');
      return send(res,200,{ok:true});
    }
    // ===== v3.4: индивидуальная статистика игроков по матчам =====
    const playerStatsRoute = key.match(/^tournaments\/(\d+)\/matches\/(\d+)\/stats$/);
    if (playerStatsRoute && (m === 'PUT' || m === 'POST')) {
      const tid=+playerStatsRoute[1], mid=+playerStatsRoute[2];
      const mt=sql.prepare('SELECT * FROM tournament_matches WHERE id=? AND tournament_id=?').get(mid,tid);
      if(!mt) return send(res,404,{error:'Матч не найден.'});
      if(!can(user.role,'judge') && mt.judge_user_id!==user.id) return send(res,403,{error:'Вносить статистику может назначенный судья или сотрудник с правами судьи.'});
      if(!['done','walkover'].includes(mt.status)) return send(res,409,{error:'Сначала завершите матч и внесите результат.'});
      const b=await body(req,100000), rows=Array.isArray(b.players)?b.players:[];
      if(rows.length>20) return send(res,400,{error:'В одном матче можно указать не более 20 игроков.'});
      const allowedTeams=new Set([mt.team1_id,mt.team2_id].filter(Boolean));
      const clean=[]; const seen=new Set();
      for(const r of rows){
        const teamId=Number(r.team_id), playerName=str(r.player_name,40).trim();
        const kills=Number(r.kills), deaths=Number(r.deaths), assists=Number(r.assists), mvp=r.mvp?1:0;
        if(!allowedTeams.has(teamId)||!playerName||![kills,deaths,assists].every(n=>Number.isInteger(n)&&n>=0&&n<=200)) return send(res,400,{error:'Проверьте команду, ник и значения K/D/A (целые числа от 0 до 200).'});
        const keyName=teamId+':'+norm(playerName); if(seen.has(keyName)) return send(res,400,{error:'В списке повторяется игрок одной команды.'}); seen.add(keyName);
        clean.push({teamId,playerName,kills,deaths,assists,mvp});
      }
      tx(()=>{
        sql.prepare('DELETE FROM tournament_player_stats WHERE match_id=?').run(mid);
        const ins=sql.prepare('INSERT INTO tournament_player_stats (tournament_id,match_id,team_id,player_name,kills,deaths,assists,mvp,created_by,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)');
        for(const r of clean) ins.run(tid,mid,r.teamId,r.playerName,r.kills,r.deaths,r.assists,r.mvp,user.id,Date.now());
      });
      logTournamentHistory(tid,user.id,'player_stats_saved','Матч '+mt.round+'.'+mt.pos+'; записей: '+clean.length);
      const captains=sql.prepare('SELECT DISTINCT captain_user_id FROM tournament_teams WHERE id IN (?,?) AND captain_user_id IS NOT NULL').all(mt.team1_id,mt.team2_id);
      for(const c of captains) addNotification(c.captain_user_id,'tournament_player_stats','Статистика матча опубликована','Опубликована индивидуальная статистика игроков матча '+mt.round+'.'+mt.pos,'/#tournaments');
      return send(res,200,{ok:true,saved:clean.length});
    }

    // ===== v3.3: расписание матчей отдельного турнира =====
    const matchScheduleRoute = key.match(/^tournaments\/(\d+)\/matches\/(\d+)\/schedule$/);
    if (matchScheduleRoute && m === 'PATCH') {
      if (!can(user.role,'regs') && !canAssignJudge) return send(res,403,{error:'Изменять расписание может организатор или старший судья.'});
      const tid=+matchScheduleRoute[1], mid=+matchScheduleRoute[2], b=await body(req);
      const mt=sql.prepare('SELECT * FROM tournament_matches WHERE id=? AND tournament_id=?').get(mid,tid);
      const tournament=sql.prepare('SELECT name FROM tournaments WHERE id=?').get(tid);
      if(!mt||!tournament) return send(res,404,{error:'Матч или турнир не найден.'});
      if(!mt.team1_id||!mt.team2_id) return send(res,409,{error:'Нельзя назначить время, пока не определены обе команды.'});
      if(['done','walkover'].includes(mt.status)) return send(res,409,{error:'Нельзя менять расписание завершённого матча.'});
      let scheduledAt=null;
      if(b.scheduled_at!==null && b.scheduled_at!=='' && b.scheduled_at!==undefined){
        scheduledAt=Number(b.scheduled_at);
        if(!Number.isSafeInteger(scheduledAt) || scheduledAt < Date.now()-300000 || scheduledAt > Date.now()+366*86400000) return send(res,400,{error:'Укажите корректную дату и время не более чем на год вперёд.'});
      }
      sql.prepare('UPDATE tournament_matches SET scheduled_at=?,updated_at=? WHERE id=?').run(scheduledAt,Date.now(),mid);
      const captains=sql.prepare('SELECT DISTINCT captain_user_id FROM tournament_teams WHERE id IN (?,?) AND captain_user_id IS NOT NULL').all(mt.team1_id,mt.team2_id);
      const when=scheduledAt?fmtDT(scheduledAt):'время матча пока не назначено';
      for(const c of captains) addNotification(c.captain_user_id,'tournament_match_schedule',scheduledAt?'Назначено время матча':'Изменено расписание матча',tournament.name+' · матч '+mt.round+'.'+mt.pos+' — '+when,'/#tournaments');
      if(mt.judge_user_id) addNotification(mt.judge_user_id,'tournament_match_schedule',scheduledAt?'Назначено время матча':'Изменено расписание матча',tournament.name+' · матч '+mt.round+'.'+mt.pos+' — '+when,'/#tournaments');
      logTournamentHistory(tid,user.id,'match_schedule_changed','Матч '+mt.round+'.'+mt.pos+'; '+(scheduledAt?new Date(scheduledAt).toISOString():'время снято'));
      return send(res,200,{ok:true,scheduled_at:scheduledAt});
    }
    if(appealDecision && m==='PATCH') {
      if(!can(user.role,'regs')) return send(res,403,{error:'Недостаточно прав.'});
      const tid=+appealDecision[1], aid=+appealDecision[2], b=await body(req);
      if(!['accepted','rejected'].includes(b.status)) return send(res,400,{error:'Недопустимое решение.'});
      const appeal=sql.prepare('SELECT * FROM tournament_appeals WHERE id=? AND tournament_id=?').get(aid,tid);
      if(!appeal) return send(res,404,{error:'Апелляция не найдена.'});
      if(appeal.status!=='open') return send(res,409,{error:'Апелляция уже рассмотрена.'});
      sql.prepare('UPDATE tournament_appeals SET status=?,response=?,resolved_at=?,resolved_by=? WHERE id=?').run(b.status,str(b.response,1000),Date.now(),user.id,aid);
      addNotification(appeal.user_id,'tournament_appeal_decision','Апелляция рассмотрена',b.status==='accepted'?'Апелляция удовлетворена.':'Апелляция отклонена. '+str(b.response,300),'/#tournaments');
      logTournamentHistory(tid,user.id,'appeal_'+b.status,'Апелляция #'+aid+'; комментарий: '+str(b.response,300));
      return send(res,200,{ok:true});
    }

    // ===== v3.0: управление независимыми турнирами =====
    const tmRoute = key.match(/^tournaments\/(\d+)(?:\/(teams|generate|matches\/(\d+)\/result))?$/);
    if (key === 'tournaments' && m === 'POST') {
      if (!isAdmin) return send(res,403,{error:'Создавать турниры может только администратор.'});
      const b=await body(req), name=str(b.name,80), format=b.format==='roundrobin'?'roundrobin':'single', size=+b.size, bo=[1,3,5].includes(+b.bo)?+b.bo:1;
      if(name.length<3) return send(res,400,{error:'Название турнира — от 3 до 80 символов.'});
      if(![8,16,32,64].includes(size)) return send(res,400,{error:'Размер турнира: 8, 16, 32 или 64 команды.'});
      const now=Date.now();
      const id=sql.prepare("INSERT INTO tournaments (name,format,size,status,bo,created_by,created_at,updated_at) VALUES (?,?,?,'registration',?,?,?,?)").run(name,format,size,bo,user.id,now,now).lastInsertRowid;
      logAction(user.id,'tournament_create','id='+id+'; '+name+'; '+format+'; '+size);
      logTournamentHistory(id,user.id,'tournament_created','Создан турнир «'+name+'»; формат '+format+'; лимит '+size+' команд; BO'+bo);
      return send(res,201,{ok:true,id});
    }
    if (tmRoute) {
      const tid=+tmRoute[1], sub=tmRoute[2]||'', tournament=sql.prepare('SELECT * FROM tournaments WHERE id=?').get(tid);
      if(!tournament) return send(res,404,{error:'Турнир не найден.'});
      if(sub==='teams' && m==='POST') {
        if(!isAdmin) return send(res,403,{error:'Недостаточно прав.'});
        if(tournament.status!=='draft' && tournament.status!=='registration') return send(res,409,{error:'Добавлять команды можно только до генерации сетки.'});
        const b=await body(req), names=Array.isArray(b.teams)?b.teams: [b.name];
        const clean=[...new Set(names.map(x=>str(x,40).trim()).filter(x=>x.length>=2))];
        if(!clean.length) return send(res,400,{error:'Укажите хотя бы одну команду.'});
        const count=sql.prepare('SELECT COUNT(*) n FROM tournament_teams WHERE tournament_id=?').get(tid).n;
        if(count+clean.length>tournament.size) return send(res,409,{error:'Превышен лимит команд: '+tournament.size+'.'});
        const add=sql.prepare('INSERT INTO tournament_teams (tournament_id,name,name_norm,seed,created_at) VALUES (?,?,?,?,?)');
        let added=0;
        for(const name of clean){try{add.run(tid,name,norm(name),count+ ++added,Date.now());}catch(e){if(!String(e.message).includes('UNIQUE'))throw e;added--;}}
        sql.prepare("UPDATE tournaments SET status='registration',updated_at=? WHERE id=?").run(Date.now(),tid);
        logTournamentHistory(tid,user.id,'teams_added','Добавлено команд: '+Math.max(0,added));
        return send(res,200,{ok:true,added:Math.max(0,added)});
      }
      if(sub==='generate' && m==='POST') {
        if(!isAdmin) return send(res,403,{error:'Недостаточно прав.'});
        if(tournament.status==='active'||tournament.status==='completed') return send(res,409,{error:'Турнир уже запущен.'});
        const teams=sql.prepare('SELECT id,name FROM tournament_teams WHERE tournament_id=? ORDER BY COALESCE(seed,9999),id').all(tid);
        if(teams.length<2) return send(res,400,{error:'Добавьте минимум две команды.'});
        if(tournament.format==='single' && teams.length!==tournament.size) return send(res,400,{error:'Для Single Elimination нужно ровно '+tournament.size+' команд. Сейчас: '+teams.length+'.'});
        sql.prepare('DELETE FROM tournament_matches WHERE tournament_id=?').run(tid);
        const ins=sql.prepare("INSERT INTO tournament_matches (tournament_id,round,pos,team1_id,team2_id,status,updated_at) VALUES (?,?,?,?,?,'pending',?)");
        if(tournament.format==='single') {
          const rounds=Math.log2(tournament.size);
          for(let r=1;r<=rounds;r++) for(let pos=1;pos<=tournament.size/Math.pow(2,r);pos++) ins.run(tid,r,pos,r===1?teams[(pos-1)*2].id:null,r===1?teams[(pos-1)*2+1].id:null,Date.now());
        } else {
          // Round robin circle method; one match per round, BYE for odd team counts.
          const arr=teams.map(t=>t.id); if(arr.length%2)arr.push(null);
          const n=arr.length, rounds=n-1, per=n/2;
          for(let r=1;r<=rounds;r++){
            for(let j=0;j<per;j++){
              const a=arr[j],b=arr[n-1-j]; if(a&&b)ins.run(tid,r,j+1,a,b,Date.now());
            }
            const fixed=arr[0],rest=arr.slice(1);rest.unshift(rest.pop());arr.splice(0,arr.length,fixed,...rest);
          }
        }
        sql.prepare("UPDATE tournaments SET status='active',updated_at=? WHERE id=?").run(Date.now(),tid);
        logTournamentHistory(tid,user.id,'matches_generated','Сформировано матчей: '+sql.prepare('SELECT COUNT(*) n FROM tournament_matches WHERE tournament_id=?').get(tid).n);
        logAction(user.id,'tournament_generate','id='+tid+'; teams='+teams.length);
        return send(res,200,{ok:true,matches:sql.prepare('SELECT COUNT(*) n FROM tournament_matches WHERE tournament_id=?').get(tid).n});
      }
      const resultMatch=sub.match(/^matches\/(\d+)\/result$/);
      if(resultMatch && m==='POST') {
        if(!canJudge) return send(res,403,{error:'Только судья или администратор.'});
        const mid=+resultMatch[1], mt=sql.prepare('SELECT * FROM tournament_matches WHERE id=? AND tournament_id=?').get(mid,tid);
        if(!mt) return send(res,404,{error:'Матч не найден.'});
        if(!isAdmin && mt.judge_user_id!==user.id) return send(res,403,{error:'Сначала старший судья должен назначить вас на этот матч.'});
        const b=await body(req), winner=+b.winner_team_id, score=str(b.score,30);
        if(tournament.format==='single' && mt.round<Math.log2(tournament.size)){const nx=sql.prepare('SELECT status FROM tournament_matches WHERE tournament_id=? AND round=? AND pos=?').get(tid,mt.round+1,Math.ceil(mt.pos/2));if(nx&&nx.status!=='pending')return send(res,409,{error:'Следующий раунд уже сыгран. Сначала исправьте его результат.'});}
        if(![mt.team1_id,mt.team2_id].includes(winner)||!score) return send(res,400,{error:'Выберите победителя и укажите счёт.'});
        sql.prepare('UPDATE tournament_matches SET winner_team_id=?,score=?,status=?,updated_at=? WHERE id=?').run(winner,score,b.walkover?'walkover':'done',Date.now(),mid);
        if(tournament.format==='single' && mt.round<Math.log2(tournament.size)){
          const nextRound=mt.round+1,nextPos=Math.ceil(mt.pos/2),isTop=mt.pos%2===1;
          if(isTop)sql.prepare('UPDATE tournament_matches SET team1_id=?,updated_at=? WHERE tournament_id=? AND round=? AND pos=?').run(winner,Date.now(),tid,nextRound,nextPos);
          else sql.prepare('UPDATE tournament_matches SET team2_id=?,updated_at=? WHERE tournament_id=? AND round=? AND pos=?').run(winner,Date.now(),tid,nextRound,nextPos);
        }
        const remaining=sql.prepare("SELECT COUNT(*) n FROM tournament_matches WHERE tournament_id=? AND status='pending'").get(tid).n;
        if(!remaining)sql.prepare("UPDATE tournaments SET status='completed',updated_at=? WHERE id=?").run(Date.now(),tid);
        else sql.prepare('UPDATE tournaments SET updated_at=? WHERE id=?').run(Date.now(),tid);
        for(const captain of sql.prepare('SELECT captain_user_id FROM tournament_teams WHERE id IN (?,?) AND captain_user_id IS NOT NULL').all(mt.team1_id,mt.team2_id)) addNotification(captain.captain_user_id,'tournament_result','Опубликован результат матча',tournament.name+' · матч '+mid+' · '+score,'/#tournaments');
        logAction(user.id,'tournament_match_result','tournament='+tid+'; match='+mid+'; winner='+winner);
        logTournamentHistory(tid,user.id,'match_result','Матч #'+mid+'; победитель команды ID '+winner+'; счёт '+score+(b.walkover?' (техническая победа)':''));
        return send(res,200,{ok:true});
      }
      if(sub==='' && m==='PATCH') {
        if(!isAdmin)return send(res,403,{error:'Недостаточно прав.'});
        const b=await body(req); if(!['draft','registration','active','completed','archived'].includes(b.status))return send(res,400,{error:'Недопустимый статус.'});
        sql.prepare('UPDATE tournaments SET status=?,updated_at=? WHERE id=?').run(b.status,Date.now(),tid);
        logTournamentHistory(tid,user.id,'tournament_status','Новый статус: '+b.status);
        return send(res,200,{ok:true});
      }
    }
    if (key === 'data' && m === 'PUT') {
      if (!isAdmin) return send(res, 403, { error: 'Недостаточно прав (нужен администратор).' });
      const now = Date.now(), hh = (putHits.get(user.login) || []).filter(t => now - t < 60000); if (hh.length >= 30) return send(res, 429, { error: 'Слишком часто. Подождите минуту.' }); hh.push(now); putHits.set(user.login, hh);
      putSite(cleanSite(await body(req)));
      logAction(user.id, 'settings_change', 'Обновление настроек / данных сайта');
      return send(res, 200, { ok: true });
    }
    if (key === 'backup' && m === 'GET') {
      if (!isAdmin) return send(res, 403, { error: 'Только администратор.' });
      return send(res, 200, { site: getSite(), regs: allRegs() }, { 'Content-Disposition': 'attachment; filename="major-css-backup.json"' });
    }
    if (key === 'registrations' && m === 'GET') {
      if (!canRegs) return send(res, 403, { error: 'Недостаточно прав.' });
      return send(res, 200, { ok: true, items: allRegs() });
    }
    if (key === 'registrations' && m === 'DELETE') {
      if (!isAdmin) return send(res, 403, { error: 'Только администратор.' });
      sql.prepare('DELETE FROM regs').run(); return send(res, 200, { ok: true });
    }
    const mm = key.match(/^registrations\/([\w-]+)$/);
    if (mm) {
      if (!isAdmin) return send(res, 403, { error: 'Только администратор.' });
      const id = mm[1], row = sql.prepare('SELECT * FROM regs WHERE id = ?').get(id); if (!row) return send(res, 404, { error: 'Заявка не найдена.' });
      const site = siteNow();
      if (m === 'DELETE') { sql.prepare('DELETE FROM regs WHERE id = ?').run(id); if (row.status === 'accepted') dropTeam(row.team); }
      else if (m === 'PATCH') {
        const st = (await body(req)).status; if (!['new', 'accepted', 'rejected'].includes(st)) return send(res, 400, { error: 'Неверный статус.' });
        if (st === 'accepted') {
          if (!teamIn(site, row.team) && site.teams.length >= site.cfg.size) return send(res, 409, { error: 'В сетке нет свободных мест (' + site.cfg.size + ').' });
          setAccepted(site, row); putSite(site);
          if (row.user_id) addNotification(row.user_id, 'accepted', 'Заявка принята', 'Ваша команда «' + row.team + '» принята в турнир!', '/#bracket');
        } else {
          sql.prepare('UPDATE regs SET status = ? WHERE id = ?').run(st, id);
          if (row.status === 'accepted') dropTeam(row.team);
          if (row.user_id && st === 'rejected') addNotification(row.user_id, 'rejected', 'Заявка отклонена', 'К сожалению, заявка команды «' + row.team + '» отклонена.', '/#register');
        }
      } else return send(res, 405, { error: 'Метод не поддерживается.' });
      return send(res, 200, { ok: true });
    }
    // Управление пользователями (админ)
    if (key === 'users' && m === 'GET' && isAdmin) {
      const items = sql.prepare('SELECT id, login, role, name, contact, team_id, created_at, active, must_set_password, totp_enabled FROM users ORDER BY created_at DESC LIMIT 200').all();
      return send(res, 200, { ok: true, items });
    }
    if (key === 'users' && m === 'POST' && isAdmin) {
      if (!can(user.role, 'users')) return send(res, 403, { error: 'Недостаточно прав для создания учёток.' });
      const b = await body(req);
      const login = str(b.login, 40).toLowerCase(), pass = String(b.pass || ''), role = validRole(b.role) || 'judge';
      const selfSet = !!b.self_set || !!b.selfSet || pass.length === 0;
      if (!login) return send(res, 400, { error: 'Логин обязателен.' });
      if (!mayAssign(user.role, role)) return send(res, 403, { error: 'Нельзя создать учётку с ролью выше вашей.' });
      if (!selfSet && pass.length < 8) return send(res, 400, { error: 'Пароль от 8 символов или включите «задать при первом входе».' });
      if (sql.prepare('SELECT id FROM users WHERE login = ?').get(login)) return send(res, 409, { error: 'Логин занят.' });
      const result = setPassword(login, selfSet ? '' : pass, role, { mustSetPassword: selfSet });
      const created = sql.prepare('SELECT id FROM users WHERE login = ?').get(login);
      logAction(user.id, 'user_create', 'login=' + login + ' role=' + role + (selfSet ? ' self_set=1' : ''));
      return send(res, 200, { ok: true, must_set_password: result.must_set_password, setup_code: result.setup_code || undefined, id: created && created.id });
    }
    // Блокировка / разблокировка аккаунта
    const userPatch = key.match(/^users\/(\d+)$/);
    if (userPatch && m === 'PATCH' && isAdmin) {
      if (!can(user.role, 'users')) return send(res, 403, { error: 'Недостаточно прав.' });
      const uid = +userPatch[1];
      const target = sql.prepare('SELECT id, login, role, active FROM users WHERE id = ?').get(uid);
      if (!target) return send(res, 404, { error: 'Пользователь не найден.' });
      if (target.id === user.id) return send(res, 400, { error: 'Нельзя заблокировать собственный аккаунт.' });
      // Владелец может блокировать всех; остальные full — не могут трогать owner
      if (target.role === 'owner' && user.role !== 'owner') return send(res, 403, { error: 'Нельзя изменить учётку владельца.' });
  if (!mayAssign(user.role, target.role)) return send(res, 403, { error: 'Нельзя менять учётку с ролью выше вашей.' });
      const b = await body(req);
      if (b.reset_2fa) { // потерян телефон и резервные коды
        sql.prepare('UPDATE users SET totp_enabled = 0, totp_secret = NULL, totp_pending = NULL, totp_recovery = NULL, totp_last = 0 WHERE id = ?').run(uid);
        sql.prepare('DELETE FROM sessions WHERE login = ?').run(target.login);
        logAction(user.id, 'user_2fa_reset', 'login=' + target.login + ' role=' + target.role);
        return send(res, 200, { ok: true });
      }
      if (typeof b.active === 'boolean' || b.active === 0 || b.active === 1) {
        const active = b.active ? 1 : 0;
        sql.prepare('UPDATE users SET active = ? WHERE id = ?').run(active, uid);
        if (!active) {
          // Сбросить сессии заблокированного
          sql.prepare('DELETE FROM sessions WHERE login = ?').run(target.login);
        }
        logAction(user.id, active ? 'user_unblock' : 'user_block', 'login=' + target.login + ' role=' + target.role);
        return send(res, 200, { ok: true, active: !!active });
      }
      if (b.role && validRole(b.role)) {
  if (!mayAssign(user.role, validRole(b.role))) return send(res, 403, { error: 'Нельзя назначить роль выше вашей.' });
        if (target.role === 'owner' && user.role !== 'owner') return send(res, 403, { error: 'Нельзя изменить роль владельца.' });
        sql.prepare('UPDATE users SET role = ? WHERE id = ?').run(validRole(b.role), uid);
        logAction(user.id, 'user_role', 'login=' + target.login + ' → ' + b.role);
        return send(res, 200, { ok: true });
      }
      return send(res, 400, { error: 'Укажите active или role.' });
    }
    // Смена / первичная установка пароля
    if (key === 'password' && m === 'POST') {
      if (!user) return send(res, 401, { error: 'Нужен вход.' });
      const b = await body(req);
      const newPass = String(b.pass || b.new || b.new_password || '');
      if (newPass.length < 8) return send(res, 400, { error: 'Новый пароль должен быть не короче 8 символов.' });
      const acc = sql.prepare('SELECT id, salt, hash, must_set_password, role FROM users WHERE id = ?').get(user.id);
      if (!acc) return send(res, 404, { error: 'Учётная запись не найдена.' });
      if (acc.must_set_password) {
        // Первичная установка — текущий пароль не требуется
      } else {
        const cur = String(b.current || b.old || b.current_password || '');
        const ok = crypto.timingSafeEqual(Buffer.from(hashPw(cur, acc.salt), 'hex'), Buffer.from(acc.hash, 'hex'));
        if (!ok) return send(res, 401, { error: 'Неверный текущий пароль.' });
      }
      const salt = crypto.randomBytes(16).toString('hex');
      const hash = hashPw(newPass, salt);
      sql.prepare('UPDATE users SET salt = ?, hash = ?, must_set_password = 0 WHERE id = ?').run(salt, hash, user.id);
      sql.prepare('DELETE FROM sessions WHERE login = ? AND id <> ?').run(user.login, hs(cookie(req).sid)); // выход на других устройствах
      if (['admin','owner','deputy_owner','chief_admin'].includes(acc.role)) {
        sql.prepare('INSERT INTO admins (login, salt, hash) VALUES (?, ?, ?) ON CONFLICT(login) DO UPDATE SET salt = excluded.salt, hash = excluded.hash').run(user.login, salt, hash);
      }
      logAction(user.id, acc.must_set_password ? 'password_set_first' : 'password_change', '');
      return send(res, 200, { ok: true });
    }

    // ===== Двухфакторная защита (TOTP) =====
    if (key.startsWith('2fa/') && m === 'POST') {
      if (!user || !user.id) return send(res, 401, { error: 'Нужен вход.' });
      if (user.must_set_password) return send(res, 403, { error: 'Сначала задайте свой пароль.' });
      const fk = '2fa:' + user.login;
      if ((ufail.get(fk) || []).filter(t => Date.now() - t < 900000).length >= 10) return send(res, 429, { error: 'Слишком много неверных попыток. Подождите 15 минут.' });
      const bad = (msg) => { const l = ufail.get(fk) || []; l.push(Date.now()); ufail.set(fk, l.filter(t => Date.now() - t < 900000)); strike(addr, 1, '2fa'); return send(res, 401, { error: msg }); };
      const b = await body(req), row = sql.prepare('SELECT id, salt, hash, totp_enabled, totp_secret, totp_pending, totp_last, totp_recovery FROM users WHERE id = ?').get(user.id);
      if (!row) return send(res, 404, { error: 'Учётная запись не найдена.' });
      const pwOk = () => crypto.timingSafeEqual(Buffer.from(hashPw(String(b.pass || ''), row.salt), 'hex'), Buffer.from(row.hash, 'hex'));
      if (key === '2fa/setup') { // шаг 1: пароль → новый секрет (пока не активен)
        if (row.totp_enabled) return send(res, 409, { error: 'Двухфакторная защита уже включена.' });
        if (!pwOk()) return bad('Неверный пароль.');
        const raw = crypto.randomBytes(20); sql.prepare('UPDATE users SET totp_pending = ? WHERE id = ?').run(encSecret(raw), row.id);
        const secret = b32enc(raw), uri = 'otpauth://totp/' + encodeURIComponent('MAJOR CSS:' + user.login) + '?secret=' + secret + '&issuer=' + encodeURIComponent('MAJOR CSS') + '&algorithm=SHA1&digits=6&period=30';
        return send(res, 200, { ok: true, secret: secret.match(/.{1,4}/g).join(' '), uri });
      }
      if (key === '2fa/enable') { // шаг 2: код из приложения → включаем, выдаём резервные коды
        if (row.totp_enabled) return send(res, 409, { error: 'Двухфакторная защита уже включена.' });
        if (!row.totp_pending) return send(res, 400, { error: 'Сначала начните настройку заново.' });
        const st = totpMatch(decSecret(row.totp_pending), String(b.code || '').replace(/\s+/g, ''), 0);
        if (!st) return bad('Неверный код. Проверьте время на телефоне и попробуйте ещё раз.');
        const codes = newRecoveryCodes();
        sql.prepare('UPDATE users SET totp_secret = totp_pending, totp_pending = NULL, totp_enabled = 1, totp_last = ?, totp_recovery = ? WHERE id = ?').run(st, JSON.stringify(codes.map(c => crypto.createHash('sha256').update(recNorm(c)).digest('hex'))), row.id);
        sql.prepare('DELETE FROM sessions WHERE login = ? AND id <> ?').run(user.login, hs(cookie(req).sid)); // остальные устройства входят заново, уже с кодом
        logAction(user.id, '2fa_enable', '');
        return send(res, 200, { ok: true, recovery: codes });
      }
      if (key === '2fa/disable') { // нужен пароль и код (или резервный код)
        if (!row.totp_enabled) return send(res, 409, { error: 'Двухфакторная защита не включена.' });
        if (REQUIRE_2FA && FULL_ROLES.includes(user.role)) return send(res, 403, { error: 'Для администраторов двухфакторная защита обязательна и не может быть отключена.' });
        if (!pwOk()) return bad('Неверный пароль.');
        if (!verify2fa(row, b.code)) return bad('Неверный код подтверждения.');
        sql.prepare('UPDATE users SET totp_enabled = 0, totp_secret = NULL, totp_pending = NULL, totp_recovery = NULL, totp_last = 0 WHERE id = ?').run(row.id);
        logAction(user.id, '2fa_disable', '');
        return send(res, 200, { ok: true });
      }
      if (key === '2fa/recovery') { // новые резервные коды (старые перестают работать)
        if (!row.totp_enabled) return send(res, 409, { error: 'Двухфакторная защита не включена.' });
        if (!pwOk()) return bad('Неверный пароль.');
        if (verify2fa(row, b.code) !== 'totp') return bad('Введите актуальный 6-значный код из приложения.');
        const codes = newRecoveryCodes();
        sql.prepare('UPDATE users SET totp_recovery = ? WHERE id = ?').run(JSON.stringify(codes.map(c => crypto.createHash('sha256').update(recNorm(c)).digest('hex'))), row.id);
        logAction(user.id, '2fa_recovery_new', '');
        return send(res, 200, { ok: true, recovery: codes });
      }
    }

    // ===== Матчи и судейская система =====
    function getOrCreateTeamId(teamName) {
      if (!teamName) return null;
      let t = sql.prepare('SELECT id FROM teams WHERE name_norm = ?').get(norm(teamName));
      if (t) return t.id;
      const r = sql.prepare('INSERT INTO teams (name, name_norm, roster, created_at) VALUES (?, ?, ?, ?)').run(teamName, norm(teamName), '[]', Date.now());
      return r.lastInsertRowid;
    }
    function syncMatchesFromSite() {
      const site = siteNow();
      if (!site || site.cfg.format !== 'single') return;
      const size = site.cfg.size || 64;
      const teams = site.teams || [];
      const results = site.results || {};
      tx(() => {
        for (let pos = 1; pos <= size / 2; pos++) {
          const t1 = teams[pos * 2 - 2] || null;
          const t2 = teams[pos * 2 - 1] || null;
          const key = '1-' + pos;
          const res = results[key];
          const status = res ? 'done' : 'pending';
          const winner = res ? (res.w === 0 ? t1 : t2) : null;
          const tid1 = getOrCreateTeamId(t1);
          const tid2 = getOrCreateTeamId(t2);
          const wid = winner ? getOrCreateTeamId(winner) : null;
          sql.prepare(`INSERT INTO matches (round, pos, team1_id, team2_id, winner_id, score, status, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(round, pos) DO UPDATE SET team1_id=excluded.team1_id, team2_id=excluded.team2_id,
            winner_id=excluded.winner_id, score=excluded.score, status=excluded.status, updated_at=excluded.updated_at`)
            .run(1, pos, tid1, tid2, wid, res && res.sc ? res.sc : '', status, Date.now());
        }
        for (let round = 2; round <= Math.log2(size); round++) {
          const matchesInRound = size / Math.pow(2, round);
          for (let pos = 1; pos <= matchesInRound; pos++) {
            const key = round + '-' + pos;
            const res = results[key];
            const prev1 = sql.prepare('SELECT winner_id FROM matches WHERE round = ? AND pos = ?').get(round - 1, pos * 2 - 1);
            const prev2 = sql.prepare('SELECT winner_id FROM matches WHERE round = ? AND pos = ?').get(round - 1, pos * 2);
            const tid1 = prev1 ? prev1.winner_id : null;
            const tid2 = prev2 ? prev2.winner_id : null;
            if (res) {
              const winnerTeam = res.w === 0 ? tid1 : tid2;
              sql.prepare(`INSERT INTO matches (round, pos, team1_id, team2_id, winner_id, score, status, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, 'done', ?)
                ON CONFLICT(round, pos) DO UPDATE SET team1_id=excluded.team1_id, team2_id=excluded.team2_id,
                winner_id=excluded.winner_id, score=excluded.score, status='done', updated_at=excluded.updated_at`)
                .run(round, pos, tid1, tid2, winnerTeam, res.sc || '', Date.now());
            } else {
              sql.prepare(`INSERT INTO matches (round, pos, team1_id, team2_id, status, updated_at)
                VALUES (?, ?, ?, ?, 'pending', ?)
                ON CONFLICT(round, pos) DO UPDATE SET team1_id=excluded.team1_id, team2_id=excluded.team2_id, updated_at=excluded.updated_at`)
                .run(round, pos, tid1, tid2, Date.now());
            }
          }
        }
      });
    }
    // Стендинги MAJOR: только W/L и «рейтинг» = wins*10 - losses (без фейкового Elo ±25/15).
    // Сортировка: больше побед → выше; при равенстве — меньше поражений.
    function updateStandings() {
      const done = sql.prepare("SELECT * FROM matches WHERE status IN ('done','walkover') AND winner_id IS NOT NULL").all();
      sql.prepare('UPDATE teams SET wins = 0, losses = 0, rating = 0').run();
      for (const m of done) {
        if (m.winner_id === m.team1_id) {
          sql.prepare('UPDATE teams SET wins = wins + 1 WHERE id = ?').run(m.team1_id);
          if (m.team2_id) sql.prepare('UPDATE teams SET losses = losses + 1 WHERE id = ?').run(m.team2_id);
        } else if (m.winner_id === m.team2_id) {
          sql.prepare('UPDATE teams SET wins = wins + 1 WHERE id = ?').run(m.team2_id);
          if (m.team1_id) sql.prepare('UPDATE teams SET losses = losses + 1 WHERE id = ?').run(m.team1_id);
        }
      }
      sql.prepare('UPDATE teams SET rating = wins * 10 - losses').run();
    }
    function updateRatings() { updateStandings(); } // совместимость со старыми вызовами
    function logAction(uid, action, details) {
      try { sql.prepare('INSERT INTO action_log (user_id, action, details, at) VALUES (?, ?, ?, ?)').run(uid || null, action, String(details || '').slice(0, 500), Date.now()); } catch (e) {}
    }
    function advanceBracket(mid) {
      // После результата продвигаем победителя в следующий раунд (source of truth = matches)
      const mt = sql.prepare('SELECT * FROM matches WHERE id = ?').get(mid);
      if (!mt || !mt.winner_id) return;
      const site = siteNow();
      if (!site || site.cfg.format !== 'single') return;
      const size = site.cfg.size || 64;
      const maxRound = Math.log2(size);
      if (mt.round >= maxRound) return;
      const nextRound = mt.round + 1;
      const nextPos = Math.ceil(mt.pos / 2);
      const isTop = mt.pos % 2 === 1; // нечётная позиция → team1 следующего матча
      const next = sql.prepare('SELECT * FROM matches WHERE round = ? AND pos = ?').get(nextRound, nextPos);
      if (!next) {
        sql.prepare(`INSERT INTO matches (round, pos, team1_id, team2_id, status, updated_at) VALUES (?, ?, ?, ?, 'pending', ?)`)
          .run(nextRound, nextPos, isTop ? mt.winner_id : null, isTop ? null : mt.winner_id, Date.now());
      } else {
        if (isTop) sql.prepare('UPDATE matches SET team1_id = ?, updated_at = ? WHERE id = ?').run(mt.winner_id, Date.now(), next.id);
        else sql.prepare('UPDATE matches SET team2_id = ?, updated_at = ? WHERE id = ?').run(mt.winner_id, Date.now(), next.id);
      }
    }

    if (key === 'matches' && m === 'GET') {
      syncMatchesFromSite();
      const rows = sql.prepare(`SELECT m.*, t1.name AS team1_name, t2.name AS team2_name, tw.name AS winner_name, u.name AS judge_name
        FROM matches m
        LEFT JOIN teams t1 ON t1.id = m.team1_id
        LEFT JOIN teams t2 ON t2.id = m.team2_id
        LEFT JOIN teams tw ON tw.id = m.winner_id
        LEFT JOIN users u ON u.id = m.judge_id
        ORDER BY m.round, m.pos`).all();
      return send(res, 200, { ok: true, items: rows });
    }
    if (key === 'matches/sync' && m === 'POST') {
      if (!canManage) return send(res, 403, { error: 'Недостаточно прав.' });
      syncMatchesFromSite(); updateStandings(); logAction(user.id, 'matches_sync', ''); return send(res, 200, { ok: true });
    }
    if (key.match(/^matches\/(\d+)\/assign$/) && m === 'POST') {
      if (!canAssignJudge) return send(res, 403, { error: 'Недостаточно прав.' });
      const mid = +key.match(/^matches\/(\d+)\/assign$/)[1];
      const b = await body(req);
      const judgeId = b.judge_id ? +b.judge_id : null;
      sql.prepare('UPDATE matches SET judge_id = ?, updated_at = ? WHERE id = ?').run(judgeId, Date.now(), mid);
      if (judgeId) {
        const mt = sql.prepare('SELECT * FROM matches WHERE id = ?').get(mid);
        addNotification(judgeId, 'match_assign', 'Назначен матч', 'Вам назначен матч (раунд ' + (mt && mt.round) + ')', '/#judge');
      }
      return send(res, 200, { ok: true });
    }
    if (key.match(/^matches\/(\d+)\/result$/) && m === 'POST') {
      if (!canJudge) return send(res, 403, { error: 'Только судья или администратор.' });
      const mid = +key.match(/^matches\/(\d+)\/result$/)[1];
      const mt = sql.prepare('SELECT * FROM matches WHERE id = ?').get(mid);
      if (!mt) return send(res, 404, { error: 'Матч не найден.' });
      if (user.role === 'judge' && mt.judge_id && mt.judge_id !== user.id) return send(res, 403, { error: 'Матч назначен другому судье.' });
      const b = await body(req);
      const winnerSide = b.winner;
      if (winnerSide !== 0 && winnerSide !== 1) return send(res, 400, { error: 'Укажите winner: 0 или 1' });
      const score = str(b.score, 20);
      const confirm = str(b.confirm, 500);
      const isWalkover = !!b.walkover;
      const status = isWalkover ? 'walkover' : 'done';
      const wid = winnerSide === 0 ? mt.team1_id : mt.team2_id;
      if (!wid) return send(res, 400, { error: 'У победителя нет team_id — сначала синхронизируйте сетку.' });
      const nextScore = score || (isWalkover ? 'W.O.' : '');
      sql.prepare(`INSERT INTO match_history
        (match_id, actor_user_id, action, old_status, new_status, old_winner_id, new_winner_id, old_score, new_score, note, at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(mid, user.id, isWalkover ? 'walkover' : (mt.winner_id ? 'result_edit' : 'result_set'), mt.status, status,
          mt.winner_id || null, wid, mt.score || '', nextScore, confirm, Date.now());
      sql.prepare(`UPDATE matches SET winner_id = ?, score = ?, status = ?, judge_id = COALESCE(judge_id, ?), updated_at = ? WHERE id = ?`)
        .run(wid, nextScore, status, user.id, Date.now(), mid);
      // Зеркало в site.results для старого рендера сетки (временно, источник правды — matches)
      const site = siteNow();
      const rkey = mt.round + '-' + mt.pos;
      site.results = site.results || {};
      site.results[rkey] = { w: winnerSide, sc: score || (isWalkover ? 'W.O.' : '') };
      putSite(site);
      advanceBracket(mid);
      updateStandings();
      logAction(user.id, isWalkover ? 'match_walkover' : 'match_result', 'match ' + mid + ' winner=' + winnerSide + ' score=' + score + ' ' + confirm);
      const msg = isWalkover ? 'Техническое поражение. Победитель проходит дальше.' : ('Матч завершён. Счёт: ' + (score || '—'));
      if (mt.team1_id) { const c1 = sql.prepare('SELECT captain_user_id FROM teams WHERE id = ?').get(mt.team1_id); if (c1 && c1.captain_user_id) addNotification(c1.captain_user_id, 'match_result', 'Результат матча', msg, '/#bracket'); }
      if (mt.team2_id) { const c2 = sql.prepare('SELECT captain_user_id FROM teams WHERE id = ?').get(mt.team2_id); if (c2 && c2.captain_user_id) addNotification(c2.captain_user_id, 'match_result', 'Результат матча', msg, '/#bracket'); }
      return send(res, 200, { ok: true });
    }
    // Статус матча: pending | live | done | walkover + время + стрим
    if (key.match(/^matches\/(\d+)\/status$/) && m === 'POST') {
      if (!canJudge) return send(res, 403, { error: 'Только судья или администратор.' });
      const mid = +key.match(/^matches\/(\d+)\/status$/)[1];
      const mt = sql.prepare('SELECT * FROM matches WHERE id = ?').get(mid);
      if (!mt) return send(res, 404, { error: 'Матч не найден.' });
      const b = await body(req);
      const st = str(b.status, 20);
      if (!['pending', 'live', 'done', 'walkover'].includes(st)) return send(res, 400, { error: 'status: pending|live|done|walkover' });
      const scheduled = b.scheduled_at ? +b.scheduled_at : mt.scheduled_at;
      const stream = b.stream_url != null ? str(b.stream_url, 300) : (mt.stream_url || '');
      const note = b.note != null ? str(b.note, 200) : (mt.note || '');
      sql.prepare(`INSERT INTO match_history
        (match_id, actor_user_id, action, old_status, new_status, old_winner_id, new_winner_id, old_score, new_score, note, at)
        VALUES (?, ?, 'status_change', ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(mid, user.id, mt.status, st, mt.winner_id || null, mt.winner_id || null, mt.score || '', mt.score || '', note, Date.now());
      sql.prepare('UPDATE matches SET status = ?, scheduled_at = ?, stream_url = ?, note = ?, updated_at = ? WHERE id = ?')
        .run(st, scheduled || null, stream, note, Date.now(), mid);
      logAction(user.id, 'match_status', 'match ' + mid + ' → ' + st);
      return send(res, 200, { ok: true });
    }
    if (key === 'my-matches' && m === 'GET') {
      if (!canJudge) return send(res, 403, { error: 'Только для судей.' });
      const rows = (can(user.role, 'full') || user.role === 'senior_judge')
        ? sql.prepare(`SELECT m.*, t1.name AS team1_name, t2.name AS team2_name FROM matches m LEFT JOIN teams t1 ON t1.id = m.team1_id LEFT JOIN teams t2 ON t2.id = m.team2_id ORDER BY m.status = 'pending' DESC, m.round, m.pos`).all()
        : sql.prepare(`SELECT m.*, t1.name AS team1_name, t2.name AS team2_name FROM matches m LEFT JOIN teams t1 ON t1.id = m.team1_id LEFT JOIN teams t2 ON t2.id = m.team2_id WHERE m.judge_id = ? OR m.judge_id IS NULL ORDER BY m.status = 'pending' DESC, m.round, m.pos`).all(user.id);
      return send(res, 200, { ok: true, items: rows });
    }

    // ===== Жеребьёвка: перемешать порядок команд в сетке =====
    if (key === 'bracket/shuffle' && m === 'POST') {
      if (!isAdmin) return send(res, 403, { error: 'Только администратор.' });
      const site = siteNow();
      const teams = Array.isArray(site.teams) ? site.teams.slice() : [];
      for (let i = teams.length - 1; i > 0; i--) {
        const j = crypto.randomInt(0, i + 1);
        const t = teams[i]; teams[i] = teams[j]; teams[j] = t;
      }
      site.teams = teams;
      site.results = {}; // новая жеребьёвка сбрасывает результаты
      putSite(site);
      sql.prepare('DELETE FROM matches').run();
      syncMatchesFromSite();
      updateStandings();
      logAction(user.id, 'bracket_shuffle', 'teams=' + teams.length);
      return send(res, 200, { ok: true, teams });
    }
    // Переставить две позиции в списке команд (ручная сетка)
    if (key === 'bracket/swap' && m === 'POST' && isAdmin) {
      const b = await body(req);
      const i = +b.i, j = +b.j;
      const site = siteNow();
      const teams = Array.isArray(site.teams) ? site.teams.slice() : [];
      if (i < 0 || j < 0 || i >= teams.length || j >= teams.length) return send(res, 400, { error: 'Неверные индексы' });
      const t = teams[i]; teams[i] = teams[j]; teams[j] = t;
      site.teams = teams;
      putSite(site);
      syncMatchesFromSite();
      logAction(user.id, 'bracket_swap', i + '↔' + j);
      return send(res, 200, { ok: true, teams });
    }
    // Дисквалификация команды → walkover во всех pending/live матчах
    if (key === 'teams/disqualify' && m === 'POST' && isAdmin) {
      const b = await body(req);
      const teamName = str(b.team, 60);
      const tid = b.team_id ? +b.team_id : null;
      let team = tid ? sql.prepare('SELECT * FROM teams WHERE id = ?').get(tid)
        : sql.prepare('SELECT * FROM teams WHERE name_norm = ?').get(norm(teamName));
      if (!team && teamName) {
        // создать запись если команда только в site.teams
        const id = getOrCreateTeamId(teamName);
        team = sql.prepare('SELECT * FROM teams WHERE id = ?').get(id);
      }
      if (!team) return send(res, 404, { error: 'Команда не найдена' });
      sql.prepare("UPDATE teams SET status = 'disqualified' WHERE id = ?").run(team.id);
      const open = sql.prepare("SELECT * FROM matches WHERE status IN ('pending','live') AND (team1_id = ? OR team2_id = ?)").all(team.id, team.id);
      for (const mt of open) {
        const winnerSide = mt.team1_id === team.id ? 1 : 0;
        const wid = winnerSide === 0 ? mt.team1_id : mt.team2_id;
        if (!wid) continue;
        sql.prepare(`UPDATE matches SET winner_id = ?, score = 'W.O. (DQ)', status = 'walkover', updated_at = ? WHERE id = ?`)
          .run(wid, Date.now(), mt.id);
        const site = siteNow();
        site.results = site.results || {};
        site.results[mt.round + '-' + mt.pos] = { w: winnerSide, sc: 'W.O. (DQ)' };
        putSite(site);
        advanceBracket(mt.id);
      }
      // убрать из публичного списка участников (опционально оставляем с пометкой)
      updateStandings();
      logAction(user.id, 'disqualify', team.name + ' id=' + team.id);
      if (team.captain_user_id) addNotification(team.captain_user_id, 'dq', 'Дисквалификация', 'Команда «' + team.name + '» дисквалифицирована.', '/#bracket');
      return send(res, 200, { ok: true, walkovers: open.length });
    }
    // Журнал действий
    if (key === 'logs' && m === 'GET' && isAdmin) {
      const limit = Math.min(500, Math.max(50, parseInt((typeof u !== 'undefined' && u.searchParams && u.searchParams.get('limit')) || '200', 10) || 200));
      const rows = sql.prepare(`SELECT l.*, u.login, u.name, u.role FROM action_log l LEFT JOIN users u ON u.id = l.user_id ORDER BY l.at DESC LIMIT ?`).all(limit);
      return send(res, 200, { ok: true, items: rows });
    }
    // Экспорт CSV: матчи или стендинги
    if (key === 'export/matches.csv' && m === 'GET' && isAdmin) {
      syncMatchesFromSite();
      const rows = sql.prepare(`SELECT m.round, m.pos, m.status, m.score, t1.name AS team1, t2.name AS team2, tw.name AS winner, m.scheduled_at, m.stream_url
        FROM matches m LEFT JOIN teams t1 ON t1.id = m.team1_id LEFT JOIN teams t2 ON t2.id = m.team2_id LEFT JOIN teams tw ON tw.id = m.winner_id
        ORDER BY m.round, m.pos`).all();
      const esc = v => '"' + String(csvSafe(v) == null ? '' : csvSafe(v)).replace(/"/g, '""') + '"';
      const csv = ['round,pos,status,team1,team2,winner,score,scheduled_at,stream_url']
        .concat(rows.map(r => [r.round, r.pos, r.status, r.team1, r.team2, r.winner, r.score, r.scheduled_at || '', r.stream_url || ''].map(esc).join(','))).join('\n');
      res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="major-matches.csv"' });
      return res.end('\uFEFF' + csv);
    }
    if (key === 'export/standings.csv' && m === 'GET' && isAdmin) {
      updateStandings();
      const rows = sql.prepare("SELECT name, wins, losses, rating, status FROM teams WHERE status != 'archived' ORDER BY wins DESC, losses ASC, name").all();
      const esc = v => '"' + String(csvSafe(v) == null ? '' : csvSafe(v)).replace(/"/g, '""') + '"';
      const csv = ['name,wins,losses,points,status'].concat(rows.map(r => [r.name, r.wins, r.losses, r.rating, r.status].map(esc).join(','))).join('\n');
      res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="major-standings.csv"' });
      return res.end('\uFEFF' + csv);
    }
    // Инвайт в команду (капитан)
    if (key === 'my-team/invite' && m === 'POST') {
      if (user.role !== 'captain' && user.role !== 'admin') return send(res, 403, { error: 'Только капитан' });
      if (!user.team_id) return send(res, 400, { error: 'Сначала создайте команду' });
      const token = crypto.randomBytes(16).toString('hex');
      sql.prepare('INSERT INTO invites (token, team_id, created_by, created_at) VALUES (?, ?, ?, ?)').run(token, user.team_id, user.id, Date.now());
      sql.prepare('UPDATE teams SET invite_token = ? WHERE id = ?').run(token, user.team_id);
      logAction(user.id, 'invite_create', 'team=' + user.team_id);
      return send(res, 200, { ok: true, token, path: '/#invite=' + token });
    }
    if (key === 'invite/accept' && m === 'POST') {
      if (!user) return send(res, 401, { error: 'Нужен вход' });
      const b = await body(req);
      const token = str(b.token, 64);
      const inv = sql.prepare('SELECT * FROM invites WHERE token = ?').get(token);
      if (!inv || inv.used_at) return send(res, 404, { error: 'Инвайт недействителен' });
      const team = sql.prepare('SELECT * FROM teams WHERE id = ?').get(inv.team_id);
      if (!team) return send(res, 404, { error: 'Команда не найдена' });
      // Привязываем пользователя как участника состава (не меняем капитана)
      let roster = [];
      try { roster = JSON.parse(team.roster || '[]'); } catch { roster = []; }
      if (!Array.isArray(roster)) roster = [];
      if (roster.length >= 12) return send(res, 400, { error: 'Состав уже полный (12)' });
      if (!roster.some(p => (p.nick || p.name) === (user.name || user.login))) {
        roster.push({ name: user.name || user.login, nick: user.login });
        sql.prepare('UPDATE teams SET roster = ? WHERE id = ?').run(JSON.stringify(roster), team.id);
      }
      sql.prepare('UPDATE invites SET used_at = ?, used_by = ? WHERE token = ?').run(Date.now(), user.id, token);
      addNotification(team.captain_user_id, 'invite_used', 'По инвайту', (user.name || user.login) + ' присоединился к составу', '/#cap');
      return send(res, 200, { ok: true, team: team.name });
    }

    // ===== MVP, архив, чемпионы (ratings — публичный, выше) =====
    if (key === 'archive' && m === 'POST' && isAdmin) {
      const b = await body(req);
      const site = siteNow();
      site.archive = Array.isArray(site.archive) ? site.archive : [];
      site.champions = Array.isArray(site.champions) ? site.champions : [];
      if (b.champion) { site.champions.unshift({ team: str(b.champion, 60), date: dayMSK(), note: str(b.note, 200) }); site.champions = site.champions.slice(0, 50); }
      if (b.mvp) site.mvp = { name: str(b.mvp, 60), team: str(b.mvpTeam, 60), note: str(b.mvpNote, 200) };
      if (b.archiveEntry) { site.archive.unshift({ title: str(b.archiveEntry.title, 120), text: str(b.archiveEntry.text, 600), date: dayMSK() }); site.archive = site.archive.slice(0, 30); }
      putSite(site);
      return send(res, 200, { ok: true });
    }
    if (key === 'team-history' && m === 'GET') {
      let tid = user.team_id;
      if (!tid) return send(res, 400, { error: 'Нет привязанной команды' });
      const rows = sql.prepare(`SELECT m.*, t1.name AS team1_name, t2.name AS team2_name, tw.name AS winner_name, ju.name AS judge_name
        FROM matches m LEFT JOIN teams t1 ON t1.id = m.team1_id LEFT JOIN teams t2 ON t2.id = m.team2_id
        LEFT JOIN teams tw ON tw.id = m.winner_id LEFT JOIN users ju ON ju.id = m.judge_id
        WHERE (m.team1_id = ? OR m.team2_id = ?) AND m.status IN ('done','walkover')
        ORDER BY m.updated_at DESC LIMIT 100`).all(tid, tid);
      return send(res, 200, { ok: true, items: rows });
    }
    if (key === 'head-to-head' && m === 'GET') {
      const tid = user.team_id;
      const opponentId = +(u.searchParams.get('opponent_id') || 0);
      if (!tid || !opponentId || opponentId === tid) return send(res, 400, { error: 'Не удалось определить команды.' });
      const opponent = sql.prepare('SELECT id, name FROM teams WHERE id = ?').get(opponentId);
      if (!opponent) return send(res, 404, { error: 'Команда-соперник не найдена.' });
      const rows = sql.prepare(`SELECT m.*, t1.name AS team1_name, t2.name AS team2_name, tw.name AS winner_name
        FROM matches m LEFT JOIN teams t1 ON t1.id = m.team1_id LEFT JOIN teams t2 ON t2.id = m.team2_id
        LEFT JOIN teams tw ON tw.id = m.winner_id
        WHERE ((m.team1_id = ? AND m.team2_id = ?) OR (m.team1_id = ? AND m.team2_id = ?))
          AND m.status IN ('done','walkover') ORDER BY m.updated_at DESC LIMIT 100`).all(tid, opponentId, opponentId, tid);
      const myWins = rows.filter(x => x.winner_id === tid).length;
      return send(res, 200, { ok: true, team: sql.prepare('SELECT name FROM teams WHERE id = ?').get(tid)?.name || '', opponent: opponent.name, total: rows.length, myWins, opponentWins: rows.length - myWins, items: rows });
    }
    if (key.match(/^matches\/(\d+)\/history$/) && m === 'GET') {
      const mid = +key.match(/^matches\/(\d+)\/history$/)[1];
      const mt = sql.prepare('SELECT * FROM matches WHERE id = ?').get(mid);
      if (!mt) return send(res, 404, { error: 'Матч не найден.' });
      const isParticipant = user.team_id && (user.team_id === mt.team1_id || user.team_id === mt.team2_id);
      const isAssignedJudge = user.role === 'judge' && mt.judge_id === user.id;
      if (!isAdmin && !isParticipant && !isAssignedJudge && user.role !== 'senior_judge') return send(res, 403, { error: 'Недостаточно прав.' });
      const rows = sql.prepare(`SELECT h.*, u.name AS actor_name, u.login AS actor_login
        FROM match_history h LEFT JOIN users u ON u.id = h.actor_user_id
        WHERE h.match_id = ? ORDER BY h.at DESC LIMIT 100`).all(mid);
      return send(res, 200, { ok: true, items: rows });
    }

    send(res, 404, { error: 'Не найдено.' });
  } catch (e) { console.error(e); if (!res.headersSent) send(res, 400, { error: 'Некорректный запрос.' }); else res.end(); }
});
srv.headersTimeout = 10000; srv.requestTimeout = 15000; srv.keepAliveTimeout = 5000; srv.maxHeadersCount = 50; srv.maxConnections = 2000;
srv.on('error', e => { console.error('Ошибка сервера:', e.message); process.exit(1); }).listen(PORT, HOST, () => console.log('MAJOR CSS v5.0 → http://' + HOST + ':' + PORT));
