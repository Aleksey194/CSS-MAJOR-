using System.Security.Claims;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using MajorCss.Data;
using MajorCss.Models;
using MajorCss.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MajorCss.Controllers;

[ApiController]
[Route("api")]
public class ApiController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly SiteService _site;
    private readonly UserManager<AppUser> _users;
    private readonly SignInManager<AppUser> _signIn;

    public ApiController(AppDbContext db, SiteService site, UserManager<AppUser> users, SignInManager<AppUser> signIn)
    {
        _db = db; _site = site; _users = users; _signIn = signIn;
    }

    AppUser? CurrentUser()
    {
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (id == null) return null;
        return _db.Users.AsNoTracking().FirstOrDefault(u => u.Id == id && !u.Disabled);
    }

    bool IsOwner(AppUser? u) => u?.RoleName == "owner";
    bool IsStaff(AppUser? u) => u != null && (u.RoleName is "owner" or "staff");
    bool CanManageUsers(AppUser? u) => IsStaff(u);

    object PublicUser(AppUser u) => new
    {
        id = u.Id,
        login = u.UserName,
        name = u.DisplayName,
        role = u.RoleName,
        disabled = u.Disabled,
        must_change = u.MustChangePassword
    };

    // ─── ping / me / data ───────────────────────────────────
    [HttpGet("ping")]
    public IActionResult Ping() => Ok(new { ok = true });

    [HttpGet("me")]
    public IActionResult Me()
    {
        var u = CurrentUser();
        if (u == null) return Ok(new { user = (string?)null, account = (object?)null });
        if (u.RoleName == "owner")
            return Ok(new { user = u.UserName, account = (object?)null });
        return Ok(new { user = (string?)null, account = PublicUser(u) });
    }

    [HttpGet("data")]
    public async Task<IActionResult> GetData()
    {
        var site = await _site.GetSiteAsync();
        return Ok(new { ok = true, site, reg = _site.RegState(site) });
    }

    [HttpPut("data")]
    [Authorize]
    public async Task<IActionResult> PutData([FromBody] JsonObject body)
    {
        var u = CurrentUser();
        if (!IsStaff(u) && u?.RoleName != "owner") return StatusCode(403, new { error = "Недостаточно прав." });
        await _site.PutSiteAsync(body);
        await _site.AuditAsync(u!.UserName ?? "?", u.RoleName, "site.update");
        return Ok(new { ok = true });
    }

    // ─── auth ───────────────────────────────────────────────
    [HttpPost("login")]
    public async Task<IActionResult> AdminLogin([FromBody] JsonElement body)
    {
        var login = body.TryGetProperty("user", out var uEl) ? uEl.GetString()?.Trim().ToLowerInvariant() : null;
        var pass = body.TryGetProperty("pass", out var pEl) ? pEl.GetString() : null;
        if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(pass))
            return Unauthorized(new { error = "Неверный логин или пароль." });

        var user = await _users.FindByNameAsync(login);
        if (user == null || user.Disabled || user.RoleName is not ("owner" or "staff"))
            return Unauthorized(new { error = "Неверный логин или пароль." });

        var r = await _signIn.PasswordSignInAsync(user, pass, isPersistent: true, lockoutOnFailure: true);
        if (!r.Succeeded) return Unauthorized(new { error = "Неверный логин или пароль." });

        await _site.AuditAsync(user.UserName!, user.RoleName, "login");
        return Ok(new { ok = true });
    }

    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await _signIn.SignOutAsync();
        return Ok(new { ok = true });
    }

    [HttpPost("auth/register")]
    public async Task<IActionResult> RegisterCaptain([FromBody] JsonElement body)
    {
        var login = Str(body, "login", 24).ToLowerInvariant();
        var name = Str(body, "name", 40);
        var password = body.TryGetProperty("password", out var p) ? p.GetString() ?? "" : "";
        var consent = body.TryGetProperty("consent", out var c) && c.ValueKind == JsonValueKind.True;

        if (!Regex.IsMatch(login, @"^[a-z0-9_.-]{3,24}$"))
            return BadRequest(new { error = "Логин: 3–24 символа, латиница, цифры, точка, дефис, подчёркивание." });
        if (name.Length < 2) return BadRequest(new { error = "Имя или ник: 2–40 символов." });
        if (password.Length < 8 || password.Length > 72)
            return BadRequest(new { error = "Пароль: от 8 до 72 символов." });
        if (!consent) return BadRequest(new { error = "Нужно согласие на обработку данных." });
        if (await _users.FindByNameAsync(login) != null)
            return Conflict(new { error = "Такой логин уже занят." });

        var user = new AppUser
        {
            UserName = login,
            DisplayName = name,
            RoleName = "captain",
            ConsentAt = DateTime.UtcNow,
            EmailConfirmed = true
        };
        var r = await _users.CreateAsync(user, password);
        if (!r.Succeeded)
            return BadRequest(new { error = string.Join(" ", r.Errors.Select(e => e.Description)) });

        await _signIn.SignInAsync(user, isPersistent: true);
        await _site.NotifyStaffAsync("captain", "Новый капитан", $"{name} ({login}) зарегистрировался", "#admin/users");
        await _site.NotifyAsync(user.Id, "welcome", "Добро пожаловать!", "Аккаунт капитана создан. Дальше можно создать профиль команды.");
        return Ok(new { ok = true, account = PublicUser(user) });
    }

    [HttpPost("auth/login")]
    public async Task<IActionResult> PlatformLogin([FromBody] JsonElement body)
    {
        var login = Str(body, "login", 24).ToLowerInvariant();
        var password = body.TryGetProperty("password", out var p) ? p.GetString() ?? "" : "";
        var user = await _users.FindByNameAsync(login);
        if (user == null || user.Disabled)
            return Unauthorized(new { error = "Неверный логин или пароль." });

        var r = await _signIn.PasswordSignInAsync(user, password, isPersistent: true, lockoutOnFailure: true);
        if (!r.Succeeded) return Unauthorized(new { error = "Неверный логин или пароль." });

        return Ok(new { ok = true, account = PublicUser(user) });
    }

    [HttpGet("account")]
    [Authorize]
    public IActionResult Account()
    {
        var u = CurrentUser();
        if (u == null) return Unauthorized(new { error = "Нужен вход." });
        return Ok(new { account = PublicUser(u) });
    }

    [HttpPost("account/password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword([FromBody] JsonElement body)
    {
        var u = await _users.GetUserAsync(User);
        if (u == null) return Unauthorized(new { error = "Нужен вход." });
        var oldP = body.TryGetProperty("old", out var o) ? o.GetString() ?? "" : "";
        var newP = body.TryGetProperty("password", out var n) ? n.GetString() ?? "" : "";
        var r = await _users.ChangePasswordAsync(u, oldP, newP);
        if (!r.Succeeded) return BadRequest(new { error = string.Join(" ", r.Errors.Select(e => e.Description)) });
        u.MustChangePassword = false;
        await _users.UpdateAsync(u);
        return Ok(new { ok = true });
    }

    // ─── notifications ──────────────────────────────────────
    [HttpGet("notifications")]
    [Authorize]
    public async Task<IActionResult> Notifications([FromQuery] int limit = 50, [FromQuery] bool unread = false)
    {
        var u = CurrentUser();
        if (u == null) return Unauthorized(new { error = "Нужен вход." });
        var uid = u.RoleName == "owner" ? "0" : u.Id;
        limit = Math.Min(limit, 200);
        var q = _db.Notifications.AsNoTracking().Where(n => n.UserId == uid);
        if (unread) q = q.Where(n => n.ReadAt == null);
        var items = await q.OrderByDescending(n => n.Created).Take(limit)
            .Select(n => new { n.Id, n.Kind, n.Title, n.Body, n.Link, n.Created, n.ReadAt }).ToListAsync();
        var unreadCount = await _db.Notifications.CountAsync(n => n.UserId == uid && n.ReadAt == null);
        return Ok(new { items, unread = unreadCount });
    }

    [HttpPost("notifications/read")]
    [Authorize]
    public async Task<IActionResult> ReadNotifications([FromBody] JsonElement body)
    {
        var u = CurrentUser();
        if (u == null) return Unauthorized(new { error = "Нужен вход." });
        var uid = u.RoleName == "owner" ? "0" : u.Id;
        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        if (body.TryGetProperty("all", out var all) && all.ValueKind == JsonValueKind.True)
        {
            await _db.Notifications.Where(n => n.UserId == uid && n.ReadAt == null)
                .ExecuteUpdateAsync(s => s.SetProperty(n => n.ReadAt, now));
        }
        return Ok(new { ok = true });
    }

    // ─── team ───────────────────────────────────────────────
    async Task<object?> TeamOfCaptain(string captainId)
    {
        var t = await _db.Teams.AsNoTracking().FirstOrDefaultAsync(x => x.CaptainId == captainId);
        if (t == null) return null;
        var players = await _db.Players.AsNoTracking().Where(p => p.TeamId == t.Id).OrderBy(p => p.Sort).ThenBy(p => p.Id)
            .Select(p => new { p.Id, p.Nick, p.Role, p.Steam, p.Sort }).ToListAsync();
        var app = await _db.TeamApps.AsNoTracking().Where(a => a.TeamId == t.Id).OrderByDescending(a => a.Id)
            .Select(a => new { a.Id, a.Status, a.At, a.DecidedAt, a.Note }).FirstOrDefaultAsync();
        return new { t.Id, t.Name, t.Tag, t.Logo, t.Contact, t.Created, t.Updated, players, application = app };
    }

    [HttpGet("team")]
    [Authorize]
    public async Task<IActionResult> GetTeam()
    {
        var u = CurrentUser();
        if (u == null) return Unauthorized(new { error = "Нужен вход." });
        if (u.RoleName != "captain") return Ok(new { team = (object?)null });
        return Ok(new { team = await TeamOfCaptain(u.Id) });
    }

    [HttpPost("team")]
    [Authorize]
    public async Task<IActionResult> CreateTeam([FromBody] JsonElement body)
    {
        var u = CurrentUser();
        if (u?.RoleName != "captain") return StatusCode(403, new { error = "Только капитан может создать команду." });
        if (await _db.Teams.AnyAsync(t => t.CaptainId == u.Id))
            return Conflict(new { error = "У вас уже есть команда." });

        var name = Str(body, "name", 40);
        var tag = Str(body, "tag", 8);
        var contact = Str(body, "contact", 80);
        if (name.Length < 2) return BadRequest(new { error = "Название команды: минимум 2 символа." });
        var nn = SiteService.Norm(name);
        if (await _db.Teams.AnyAsync(t => t.NameNorm == nn))
            return Conflict(new { error = "Команда с таким названием уже существует." });

        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var team = new TeamEntity
        {
            CaptainId = u.Id, Name = name, NameNorm = nn, Tag = tag, Contact = contact,
            Created = now, Updated = now
        };
        _db.Teams.Add(team);
        await _db.SaveChangesAsync();

        if (body.TryGetProperty("players", out var pl) && pl.ValueKind == JsonValueKind.Array)
        {
            var i = 0;
            foreach (var p in pl.EnumerateArray().Take(12))
            {
                var nick = p.ValueKind == JsonValueKind.String ? p.GetString() ?? "" :
                    (p.TryGetProperty("nick", out var n) ? n.GetString() ?? "" : "");
                nick = nick.Trim();
                if (nick.Length == 0) continue;
                var role = p.ValueKind == JsonValueKind.Object && p.TryGetProperty("role", out var r) ? r.GetString() ?? "player" : "player";
                _db.Players.Add(new PlayerEntity { TeamId = team.Id, Nick = nick[..Math.Min(40, nick.Length)], Role = role, Sort = i++, Created = now });
            }
            await _db.SaveChangesAsync();
        }

        await _site.AuditAsync(u.UserName!, u.RoleName, "team.create", name);
        await _site.NotifyStaffAsync("team", "Новая команда", $"{name} (капитан {u.DisplayName})", "#admin/teams");
        return Ok(new { ok = true, team = await TeamOfCaptain(u.Id) });
    }

    [HttpPatch("team")]
    [Authorize]
    public async Task<IActionResult> UpdateTeam([FromBody] JsonElement body)
    {
        var u = CurrentUser();
        if (u?.RoleName != "captain") return StatusCode(403, new { error = "Только капитан." });
        var t = await _db.Teams.FirstOrDefaultAsync(x => x.CaptainId == u.Id);
        if (t == null) return NotFound(new { error = "Сначала создайте команду." });
        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        if (body.TryGetProperty("name", out var nameEl))
        {
            var name = (nameEl.GetString() ?? "").Trim();
            if (name.Length < 2) return BadRequest(new { error = "Название слишком короткое." });
            var nn = SiteService.Norm(name);
            if (nn != t.NameNorm && await _db.Teams.AnyAsync(x => x.NameNorm == nn))
                return Conflict(new { error = "Название уже занято." });
            t.Name = name; t.NameNorm = nn;
        }
        if (body.TryGetProperty("tag", out var tagEl)) t.Tag = (tagEl.GetString() ?? "").Trim()[..Math.Min(8, (tagEl.GetString() ?? "").Trim().Length)];
        if (body.TryGetProperty("contact", out var cEl)) t.Contact = (cEl.GetString() ?? "").Trim()[..Math.Min(80, (cEl.GetString() ?? "").Length)];
        if (body.TryGetProperty("logo", out var logoEl))
        {
            var logo = logoEl.GetString();
            if (string.IsNullOrEmpty(logo)) t.Logo = "";
            else
            {
                try
                {
                    var buf = Convert.FromBase64String(logo);
                    if (buf.Length > 200_000) return BadRequest(new { error = "Логотип: до 200 КБ." });
                    var mime = Sniff(buf);
                    if (mime == null) return BadRequest(new { error = "Логотип: PNG/JPEG/WebP." });
                    t.Logo = $"data:{mime};base64,{logo}";
                }
                catch { return BadRequest(new { error = "Некорректный логотип." }); }
            }
        }
        if (body.TryGetProperty("players", out var pl) && pl.ValueKind == JsonValueKind.Array)
        {
            await _db.Players.Where(p => p.TeamId == t.Id).ExecuteDeleteAsync();
            var i = 0;
            foreach (var p in pl.EnumerateArray().Take(12))
            {
                var nick = p.ValueKind == JsonValueKind.String ? p.GetString() ?? "" :
                    (p.TryGetProperty("nick", out var n) ? n.GetString() ?? "" : "");
                nick = nick.Trim();
                if (nick.Length == 0) continue;
                var role = p.ValueKind == JsonValueKind.Object && p.TryGetProperty("role", out var r) ? r.GetString() ?? "player" : "player";
                _db.Players.Add(new PlayerEntity { TeamId = t.Id, Nick = nick[..Math.Min(40, nick.Length)], Role = role, Sort = i++, Created = now });
            }
        }
        t.Updated = now;
        await _db.SaveChangesAsync();
        await _site.AuditAsync(u.UserName!, u.RoleName, "team.update", t.Name);
        return Ok(new { ok = true, team = await TeamOfCaptain(u.Id) });
    }

    [HttpPost("team/apply")]
    [Authorize]
    public async Task<IActionResult> TeamApply()
    {
        var u = CurrentUser();
        if (u?.RoleName != "captain") return StatusCode(403, new { error = "Только капитан." });
        var t = await _db.Teams.FirstOrDefaultAsync(x => x.CaptainId == u.Id);
        if (t == null) return BadRequest(new { error = "Сначала создайте профиль команды." });
        if (!await _db.Players.AnyAsync(p => p.TeamId == t.Id))
            return BadRequest(new { error = "Добавьте хотя бы одного игрока в состав." });
        var last = await _db.TeamApps.Where(a => a.TeamId == t.Id).OrderByDescending(a => a.Id).FirstOrDefaultAsync();
        if (last?.Status == "pending") return Conflict(new { error = "Заявка уже на рассмотрении." });
        if (last?.Status == "accepted") return Conflict(new { error = "Команда уже принята." });
        var app = new TeamApp { TeamId = t.Id, Status = "pending", At = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() };
        _db.TeamApps.Add(app);
        await _db.SaveChangesAsync();
        await _site.NotifyStaffAsync("application", "Заявка команды", $"{t.Name} подала заявку", "#admin/apps");
        await _site.NotifyAsync(u.Id, "application", "Заявка отправлена", $"Команда «{t.Name}» подала заявку.");
        return Ok(new { ok = true, application_id = app.Id });
    }

    [HttpPost("team/withdraw")]
    [Authorize]
    public async Task<IActionResult> TeamWithdraw()
    {
        var u = CurrentUser();
        if (u?.RoleName != "captain") return StatusCode(403, new { error = "Только капитан." });
        var t = await _db.Teams.FirstOrDefaultAsync(x => x.CaptainId == u.Id);
        if (t == null) return NotFound(new { error = "Команда не найдена." });
        var app = await _db.TeamApps.Where(a => a.TeamId == t.Id && a.Status == "pending").OrderByDescending(a => a.Id).FirstOrDefaultAsync();
        if (app == null) return NotFound(new { error = "Нет активной заявки." });
        app.Status = "withdrawn";
        app.DecidedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        await _db.SaveChangesAsync();
        return Ok(new { ok = true });
    }

    // ─── users ──────────────────────────────────────────────
    [HttpGet("users")]
    [Authorize]
    public async Task<IActionResult> Users()
    {
        var u = CurrentUser();
        if (!CanManageUsers(u)) return StatusCode(403, new { error = "Недостаточно прав." });
        var items = await _db.Users.AsNoTracking().OrderByDescending(x => x.CreatedAt).Take(500)
            .Select(x => new { id = x.Id, login = x.UserName, name = x.DisplayName, role = x.RoleName, disabled = x.Disabled, must_change = x.MustChangePassword, created = x.CreatedAt }).ToListAsync();
        return Ok(new { items });
    }

    [HttpPost("users")]
    [Authorize]
    public async Task<IActionResult> CreateUser([FromBody] JsonElement body)
    {
        var me = CurrentUser();
        if (!CanManageUsers(me)) return StatusCode(403, new { error = "Недостаточно прав." });
        var login = Str(body, "login", 24).ToLowerInvariant();
        var name = Str(body, "name", 40);
        var role = Str(body, "role", 16);
        if (role is not ("judge" or "staff")) return BadRequest(new { error = "Роль: judge или staff." });
        if (role == "staff" && me!.RoleName != "owner") return StatusCode(403, new { error = "Сотрудников создаёт только владелец." });
        if (!Regex.IsMatch(login, @"^[a-z0-9_.-]{3,24}$") || name.Length < 2)
            return BadRequest(new { error = "Нужны логин (3–24) и имя." });
        if (await _users.FindByNameAsync(login) != null) return Conflict(new { error = "Такой логин уже занят." });

        var temp = Convert.ToBase64String(Guid.NewGuid().ToByteArray())[..12];
        var user = new AppUser { UserName = login, DisplayName = name, RoleName = role, MustChangePassword = true, EmailConfirmed = true };
        var r = await _users.CreateAsync(user, temp);
        if (!r.Succeeded) return BadRequest(new { error = string.Join(" ", r.Errors.Select(e => e.Description)) });
        await _site.AuditAsync(me!.UserName!, me.RoleName, "user.create", login, role);
        await _site.NotifyAsync(user.Id, "welcome", "Аккаунт создан", "Смените временный пароль после первого входа.");
        return Ok(new { ok = true, id = user.Id, login, temp_password = temp });
    }

    // ─── matches ────────────────────────────────────────────
    [HttpGet("matches")]
    [Authorize]
    public async Task<IActionResult> Matches()
    {
        var site = await _site.GetSiteAsync();
        var rounds = _site.BuildBracket(site);
        var meta = await _db.MatchMetas.AsNoTracking().ToDictionaryAsync(m => m.Key);
        var judges = await _db.Users.AsNoTracking().Where(u => u.RoleName == "judge")
            .ToDictionaryAsync(u => u.Id, u => u.DisplayName);
        var items = new List<object>();
        foreach (dynamic R in rounds)
        {
            int n = R.n;
            foreach (dynamic m in R.ms)
            {
                meta.TryGetValue((string)m.key, out var mm);
                object? result = null;
                if (m.rv != null)
                {
                    int w = m.rv.w;
                    string? sc = m.rv.sc;
                    result = new { winner = w, score = sc ?? "" };
                }
                object? judge = null;
                if (mm?.JudgeId != null && judges.TryGetValue(mm.JudgeId, out var jn))
                    judge = new { id = mm.JudgeId, name = jn };
                items.Add(new
                {
                    key = (string)m.key,
                    stage = SiteService.StageName(n),
                    a = (string?)m.a,
                    b = (string?)m.b,
                    playable = (bool)m.playable,
                    result,
                    judge,
                    scheduled_at = mm?.ScheduledAt
                });
            }
        }
        return Ok(new { items });
    }

    [HttpPost("matches/result")]
    [Authorize]
    public async Task<IActionResult> MatchResult([FromBody] JsonElement body)
    {
        var me = CurrentUser();
        if (me == null || me.RoleName is not ("owner" or "staff" or "judge"))
            return StatusCode(403, new { error = "Недостаточно прав." });

        var key = Str(body, "key", 20);
        if (!body.TryGetProperty("winner", out var wEl) || (wEl.GetInt32() is not (0 or 1)))
            return BadRequest(new { error = "Укажите победителя: 0 или 1." });
        var winner = wEl.GetInt32();
        var score = Str(body, "score", 12);

        var site = await _site.GetSiteAsync();
        var results = site["results"] as JsonObject ?? new JsonObject();
        results[key] = string.IsNullOrEmpty(score)
            ? new JsonObject { ["w"] = winner }
            : new JsonObject { ["w"] = winner, ["sc"] = score };
        // clear downstream
        var parts = key.Split('-');
        if (parts.Length == 2 && int.TryParse(parts[0], out var r) && int.TryParse(parts[1], out var i))
        {
            for (var q = r + 1; q < 8; q++)
            {
                i >>= 1;
                results.Remove($"{q}-{i}");
            }
        }
        site["results"] = results;
        await _site.PutSiteAsync(site);
        await _site.AuditAsync(me.UserName!, me.RoleName, "result.set", key, new { winner, score });
        await _site.NotifyStaffAsync("result", "Результат матча", $"Матч {key}. Победитель: сторона {winner}", "#matches");
        return Ok(new { ok = true });
    }

    [HttpPost("matches/assign")]
    [Authorize]
    public async Task<IActionResult> MatchAssign([FromBody] JsonElement body)
    {
        var me = CurrentUser();
        if (!IsStaff(me)) return StatusCode(403, new { error = "Недостаточно прав." });
        var key = Str(body, "key", 20);
        string? judgeId = body.TryGetProperty("judge_id", out var j) ? j.GetString() : null;
        long? when = body.TryGetProperty("scheduled_at", out var s) && s.ValueKind == JsonValueKind.Number ? s.GetInt64() : null;
        var row = await _db.MatchMetas.FindAsync(key);
        if (row == null)
        {
            row = new MatchMeta { Key = key, JudgeId = judgeId, ScheduledAt = when, Updated = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() };
            _db.MatchMetas.Add(row);
        }
        else
        {
            row.JudgeId = judgeId;
            row.ScheduledAt = when;
            row.Updated = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }
        await _db.SaveChangesAsync();
        if (judgeId != null)
            await _site.NotifyAsync(judgeId, "assign", "Вам назначен матч", key, "#matches");
        return Ok(new { ok = true });
    }

    // ─── ratings / archive / appeals / stats ────────────────
    [HttpGet("ratings")]
    public async Task<IActionResult> Ratings()
    {
        var site = await _site.GetSiteAsync();
        var rounds = _site.BuildBracket(site);
        var teamStats = new Dictionary<string, (int wins, int losses, int played)>();
        void Ens(string? n) { if (!string.IsNullOrEmpty(n) && !teamStats.ContainsKey(n)) teamStats[n] = (0, 0, 0); }
        foreach (dynamic R in rounds)
            foreach (dynamic m in R.ms)
            {
                if (m.rv == null || m.a == null || m.b == null) continue;
                string a = m.a, b = m.b; int w = m.rv.w;
                var winner = w == 0 ? a : b; var loser = w == 0 ? b : a;
                Ens(winner); Ens(loser);
                var W = teamStats[winner]; var L = teamStats[loser];
                teamStats[winner] = (W.wins + 1, W.losses, W.played + 1);
                teamStats[loser] = (L.wins, L.losses + 1, L.played + 1);
            }
        var teams = teamStats.Select(kv => new
        {
            name = kv.Key,
            wins = kv.Value.wins,
            losses = kv.Value.losses,
            played = kv.Value.played,
            winrate = kv.Value.played > 0 ? Math.Round(kv.Value.wins * 1000.0 / kv.Value.played) / 10 : 0
        }).OrderByDescending(t => t.wins).ThenByDescending(t => t.winrate).ToList();

        var players = await _db.Players.AsNoTracking()
            .Join(_db.Teams, p => p.TeamId, t => t.Id, (p, t) => new { p.Nick, team = t.Name })
            .ToListAsync();
        var votes = await _db.MvpVotes.AsNoTracking()
            .GroupBy(v => v.PlayerNick.ToLower())
            .Select(g => new { nick = g.First().PlayerNick, votes = g.Count(), team = g.First().TeamName })
            .OrderByDescending(x => x.votes).ToListAsync();

        return Ok(new { teams, players = votes, mvp = votes.FirstOrDefault() });
    }

    [HttpPost("mvp/vote")]
    [Authorize]
    public async Task<IActionResult> MvpVote([FromBody] JsonElement body)
    {
        var u = CurrentUser();
        if (u == null) return Unauthorized(new { error = "Нужен вход." });
        var nick = Str(body, "player_nick", 40);
        if (nick.Length < 2 && body.TryGetProperty("nick", out var n2)) nick = (n2.GetString() ?? "").Trim();
        if (nick.Length < 2) return BadRequest(new { error = "Укажите ник игрока." });
        var team = Str(body, "team", 40);
        var existing = await _db.MvpVotes.FirstOrDefaultAsync(v => v.VoterId == u.Id);
        if (existing != null)
        {
            existing.PlayerNick = nick; existing.TeamName = team;
            existing.Created = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }
        else
        {
            _db.MvpVotes.Add(new MvpVote
            {
                VoterId = u.Id, PlayerNick = nick, TeamName = team,
                Created = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
            });
        }
        await _db.SaveChangesAsync();
        return Ok(new { ok = true });
    }

    [HttpGet("archive")]
    public async Task<IActionResult> GetArchive()
    {
        var items = await _db.Archive.AsNoTracking().OrderByDescending(a => a.Finished).Take(100)
            .Select(a => new { a.Id, a.Title, a.Started, a.Finished, a.Size, a.Champion, runner_up = a.RunnerUp, a.Third, a.Mvp, a.Prize, a.Note, a.Created })
            .ToListAsync();
        return Ok(new { items });
    }

    [HttpPost("archive")]
    [Authorize]
    public async Task<IActionResult> PostArchive([FromBody] JsonElement body)
    {
        var me = CurrentUser();
        if (!IsStaff(me)) return StatusCode(403, new { error = "Недостаточно прав." });
        var site = await _site.GetSiteAsync();
        var title = Str(body, "title", 80);
        if (string.IsNullOrEmpty(title)) title = "MAJOR CSS — " + DateTime.Now.ToString("dd.MM.yyyy");
        var entry = new ArchiveEntry
        {
            Title = title,
            Finished = body.TryGetProperty("finished", out var f) && f.ValueKind == JsonValueKind.Number ? f.GetInt64() : DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            Size = site["cfg"]?["size"]?.GetValue<int>() ?? 64,
            Champion = Str(body, "champion", 60),
            RunnerUp = Str(body, "runner_up", 60),
            Third = Str(body, "third", 60),
            Mvp = Str(body, "mvp", 40),
            Prize = Str(body, "prize", 40),
            Note = Str(body, "note", 300),
            BracketJson = site.ToJsonString(),
            Created = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        };
        _db.Archive.Add(entry);
        await _db.SaveChangesAsync();
        await _site.AuditAsync(me!.UserName!, me.RoleName, "archive.create", title);
        return Ok(new { ok = true, id = entry.Id });
    }

    [HttpDelete("archive/{id:int}")]
    [Authorize]
    public async Task<IActionResult> DeleteArchive(int id)
    {
        var me = CurrentUser();
        if (!IsStaff(me)) return StatusCode(403, new { error = "Недостаточно прав." });
        var row = await _db.Archive.FindAsync(id);
        if (row == null) return NotFound(new { error = "Не найдено." });
        _db.Archive.Remove(row);
        await _db.SaveChangesAsync();
        return Ok(new { ok = true });
    }

    [HttpGet("appeals")]
    [Authorize]
    public async Task<IActionResult> GetAppeals()
    {
        var me = CurrentUser();
        if (me == null) return Unauthorized(new { error = "Нужен вход." });
        IQueryable<Appeal> q = _db.Appeals.AsNoTracking();
        if (!IsStaff(me)) q = q.Where(a => a.AuthorId == me.Id);
        var items = await q.OrderBy(a => a.Status == "open" ? 0 : 1).ThenByDescending(a => a.Id).Take(200).ToListAsync();
        return Ok(new { items });
    }

    [HttpPost("appeals")]
    [Authorize]
    public async Task<IActionResult> CreateAppeal([FromBody] JsonElement body)
    {
        var me = CurrentUser();
        if (me == null) return Unauthorized(new { error = "Нужен вход." });
        var key = body.TryGetProperty("match_key", out var mk) ? mk.GetString() ?? "" : Str(body, "key", 20);
        var reason = Str(body, "reason", 1000);
        if (key.Length == 0 || reason.Length < 10)
            return BadRequest(new { error = "Укажите матч и причину (минимум 10 символов)." });
        if (await _db.Appeals.AnyAsync(a => a.MatchKey == key && a.Status == "open"))
            return Conflict(new { error = "По этому матчу уже есть открытая апелляция." });
        var app = new Appeal
        {
            MatchKey = key, AuthorId = me.Id, AuthorRole = me.RoleName, Reason = reason,
            Created = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        };
        _db.Appeals.Add(app);
        await _db.SaveChangesAsync();
        await _site.NotifyStaffAsync("appeal", "Новая апелляция", key, "#appeals");
        return Ok(new { ok = true, id = app.Id });
    }

    [HttpPost("appeals/{id:int}")]
    [Authorize]
    public async Task<IActionResult> DecideAppeal(int id, [FromBody] JsonElement body)
    {
        var me = CurrentUser();
        if (!IsStaff(me)) return StatusCode(403, new { error = "Недостаточно прав." });
        var app = await _db.Appeals.FindAsync(id);
        if (app == null) return NotFound(new { error = "Апелляция не найдена." });
        if (app.Status != "open") return Conflict(new { error = "Уже рассмотрена." });
        var status = Str(body, "status", 16);
        if (status is not ("accepted" or "rejected")) return BadRequest(new { error = "status: accepted или rejected." });
        app.Status = status;
        app.Decision = Str(body, "decision", 500);
        app.DecidedAt = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        app.DecidedBy = me!.UserName ?? "";
        if (status == "accepted" && body.TryGetProperty("reset_result", out var rr) && rr.ValueKind == JsonValueKind.True)
        {
            var site = await _site.GetSiteAsync();
            var results = site["results"] as JsonObject;
            results?.Remove(app.MatchKey);
            if (results != null) { site["results"] = results; await _site.PutSiteAsync(site); }
        }
        await _db.SaveChangesAsync();
        await _site.NotifyAsync(app.AuthorId, "appeal", status == "accepted" ? "Апелляция принята" : "Апелляция отклонена", app.Decision);
        return Ok(new { ok = true });
    }

    [HttpGet("admin/stats")]
    [Authorize]
    public async Task<IActionResult> AdminStats()
    {
        var me = CurrentUser();
        if (!IsStaff(me)) return StatusCode(403, new { error = "Недостаточно прав." });
        var site = await _site.GetSiteAsync();
        var teamsCount = site["teams"]?.AsArray()?.Count ?? 0;
        var size = site["cfg"]?["size"]?.GetValue<int>() ?? 64;
        var rounds = _site.BuildBracket(site);
        var played = 0; var total = 0;
        foreach (dynamic R in rounds)
            foreach (dynamic m in R.ms)
            {
                if (m.playable || m.rv != null) total++;
                if (m.rv != null) played++;
            }
        return Ok(new
        {
            users = await _db.Users.Where(u => !u.Disabled).GroupBy(u => u.RoleName).Select(g => new { role = g.Key, n = g.Count() }).ToDictionaryAsync(x => x.role, x => x.n),
            appeals_open = await _db.Appeals.CountAsync(a => a.Status == "open"),
            archive_count = await _db.Archive.CountAsync(),
            teams_in_bracket = teamsCount,
            bracket_size = size,
            matches_played = played,
            matches_total = total,
            reg_open = site["regOpen"]?.GetValue<bool>() ?? true,
            team_apps = await _db.TeamApps.GroupBy(a => a.Status).Select(g => new { s = g.Key, n = g.Count() }).ToDictionaryAsync(x => x.s, x => x.n)
        });
    }

    [HttpGet("audit")]
    [Authorize]
    public async Task<IActionResult> Audit([FromQuery] int limit = 100)
    {
        var me = CurrentUser();
        if (me == null) return Unauthorized(new { error = "Нужен вход." });
        limit = Math.Min(limit, 500);
        if (IsStaff(me))
        {
            var items = await _db.AuditLogs.AsNoTracking().OrderByDescending(a => a.Id).Take(limit).ToListAsync();
            return Ok(new { items });
        }
        var mine = await _db.AuditLogs.AsNoTracking().Where(a => a.Actor == me.UserName).OrderByDescending(a => a.Id).Take(limit)
            .Select(a => new { a.At, a.Action, a.Target, a.Detail }).ToListAsync();
        return Ok(new { items = mine });
    }

    [HttpGet("backup")]
    [Authorize]
    public async Task<IActionResult> Backup()
    {
        var me = CurrentUser();
        if (!IsOwner(me) && !IsStaff(me)) return StatusCode(403, new { error = "Недостаточно прав." });
        var site = await _site.GetSiteAsync();
        var regs = await _db.Registrations.AsNoTracking().ToListAsync();
        return Ok(new { site, regs });
    }

    [HttpGet("registrations")]
    [Authorize]
    public async Task<IActionResult> Registrations()
    {
        var me = CurrentUser();
        if (!IsStaff(me)) return StatusCode(403, new { error = "Недостаточно прав." });
        var items = await _db.Registrations.AsNoTracking().OrderByDescending(r => r.At).ToListAsync();
        return Ok(new { ok = true, items });
    }

    [HttpGet("challenge")]
    public IActionResult GetChallenge()
    {
        // simplified: frontend may call this; PoW optional on C# side
        var nonce = Guid.NewGuid().ToString("N")[..16];
        return Ok(new { ok = true, token = nonce + ".16." + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(), nonce, bits = 16 });
    }

    // ─── helpers ────────────────────────────────────────────
    static string Str(JsonElement body, string prop, int max)
    {
        if (!body.TryGetProperty(prop, out var el)) return "";
        var s = (el.GetString() ?? "").Trim();
        return s.Length <= max ? s : s[..max];
    }

    static string? Sniff(byte[] buf)
    {
        if (buf.Length > 8 && buf[0] == 0x89 && buf[1] == 0x50) return "image/png";
        if (buf.Length > 3 && buf[0] == 0xFF && buf[1] == 0xD8) return "image/jpeg";
        if (buf.Length > 12 && buf[0] == 'R' && buf[8] == 'W') return "image/webp";
        return null;
    }
}
