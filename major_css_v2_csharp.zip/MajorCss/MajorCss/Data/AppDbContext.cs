using MajorCss.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace MajorCss.Data;

public class AppDbContext : IdentityDbContext<AppUser>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<SiteData> Site { get; set; } = null!;
    public DbSet<Registration> Registrations { get; set; } = null!;
    public DbSet<TeamEntity> Teams { get; set; } = null!;
    public DbSet<PlayerEntity> Players { get; set; } = null!;
    public DbSet<TeamApp> TeamApps { get; set; } = null!;
    public DbSet<MatchMeta> MatchMetas { get; set; } = null!;
    public DbSet<Proof> Proofs { get; set; } = null!;
    public DbSet<Notification> Notifications { get; set; } = null!;
    public DbSet<AuditLog> AuditLogs { get; set; } = null!;
    public DbSet<ArchiveEntry> Archive { get; set; } = null!;
    public DbSet<Appeal> Appeals { get; set; } = null!;
    public DbSet<MvpVote> MvpVotes { get; set; } = null!;
    public DbSet<Ban> Bans { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);
        b.Entity<SiteData>().HasKey(x => x.Id);
        b.Entity<Registration>().HasKey(x => x.Id);
        b.Entity<Registration>().HasIndex(x => x.TeamNorm);
        b.Entity<TeamEntity>().HasIndex(x => x.NameNorm);
        b.Entity<TeamEntity>().HasIndex(x => x.CaptainId).IsUnique();
        b.Entity<PlayerEntity>().HasIndex(x => x.TeamId);
        b.Entity<MatchMeta>().HasKey(x => x.Key);
        b.Entity<Ban>().HasKey(x => x.Ip);
        b.Entity<MvpVote>().HasIndex(x => x.VoterId).IsUnique();
        b.Entity<Notification>().HasIndex(x => new { x.UserId, x.ReadAt, x.Created });
        b.Entity<Appeal>().HasIndex(x => x.Status);
    }
}
