using Microsoft.AspNetCore.Identity;

namespace MajorCss.Models;

public class AppUser : IdentityUser
{
    public string DisplayName { get; set; } = "";
    /// <summary>owner | staff | judge | captain</summary>
    public string RoleName { get; set; } = "captain";
    public bool MustChangePassword { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ConsentAt { get; set; }
    public bool Disabled { get; set; }
}

public class SiteData
{
    public int Id { get; set; } = 1;
    public string Json { get; set; } = "{}";
    public long Updated { get; set; }
}

public class Registration
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public long At { get; set; }
    public string Status { get; set; } = "new"; // new, accepted, rejected
    public bool Confirmed { get; set; }
    public long? ConfirmedAt { get; set; }
    public string CToken { get; set; } = "";
    public string Team { get; set; } = "";
    public string TeamNorm { get; set; } = "";
    public string Captain { get; set; } = "";
    public string Contact { get; set; } = "";
    public string Roster { get; set; } = "";
    public long? ConsentAt { get; set; }
}

public class TeamEntity
{
    public int Id { get; set; }
    public string CaptainId { get; set; } = "";
    public string Name { get; set; } = "";
    public string NameNorm { get; set; } = "";
    public string Tag { get; set; } = "";
    public string Logo { get; set; } = "";
    public string Contact { get; set; } = "";
    public long Created { get; set; }
    public long Updated { get; set; }
    public List<PlayerEntity> Players { get; set; } = new();
}

public class PlayerEntity
{
    public int Id { get; set; }
    public int TeamId { get; set; }
    public string Nick { get; set; } = "";
    public string Role { get; set; } = "player";
    public string Steam { get; set; } = "";
    public int Sort { get; set; }
    public long Created { get; set; }
}

public class TeamApp
{
    public int Id { get; set; }
    public int TeamId { get; set; }
    public string Status { get; set; } = "pending";
    public long At { get; set; }
    public long? DecidedAt { get; set; }
    public string Note { get; set; } = "";
}

public class MatchMeta
{
    public string Key { get; set; } = "";
    public string? JudgeId { get; set; }
    public long? ScheduledAt { get; set; }
    public long Updated { get; set; }
}

public class Proof
{
    public int Id { get; set; }
    public string MatchKey { get; set; } = "";
    public string Uploader { get; set; } = "";
    public string Mime { get; set; } = "";
    public byte[] Data { get; set; } = Array.Empty<byte>();
    public long Created { get; set; }
}

public class Notification
{
    public int Id { get; set; }
    public string UserId { get; set; } = ""; // "0" for owner staff box
    public string Kind { get; set; } = "";
    public string Title { get; set; } = "";
    public string Body { get; set; } = "";
    public string Link { get; set; } = "";
    public long Created { get; set; }
    public long? ReadAt { get; set; }
}

public class AuditLog
{
    public int Id { get; set; }
    public long At { get; set; }
    public string Actor { get; set; } = "";
    public string Role { get; set; } = "";
    public string Action { get; set; } = "";
    public string Target { get; set; } = "";
    public string Detail { get; set; } = "";
}

public class ArchiveEntry
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public long? Started { get; set; }
    public long Finished { get; set; }
    public int Size { get; set; }
    public string Champion { get; set; } = "";
    public string RunnerUp { get; set; } = "";
    public string Third { get; set; } = "";
    public string Mvp { get; set; } = "";
    public string Prize { get; set; } = "";
    public string Note { get; set; } = "";
    public string BracketJson { get; set; } = "{}";
    public long Created { get; set; }
}

public class Appeal
{
    public int Id { get; set; }
    public string MatchKey { get; set; } = "";
    public string AuthorId { get; set; } = "";
    public string AuthorRole { get; set; } = "";
    public string Reason { get; set; } = "";
    public string Status { get; set; } = "open";
    public string Decision { get; set; } = "";
    public long Created { get; set; }
    public long? DecidedAt { get; set; }
    public string DecidedBy { get; set; } = "";
}

public class MvpVote
{
    public int Id { get; set; }
    public string VoterId { get; set; } = "";
    public string PlayerNick { get; set; } = "";
    public string TeamName { get; set; } = "";
    public long Created { get; set; }
}

public class Ban
{
    public string Ip { get; set; } = "";
    public long Until { get; set; }
    public string? Reason { get; set; }
    public long At { get; set; }
}
