using System.Text.Json;
using MajorCss.Data;
using MajorCss.Models;
using MajorCss.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

var dbPath = Path.Combine(builder.Environment.ContentRootPath, "data", "major.db");
Directory.CreateDirectory(Path.GetDirectoryName(dbPath)!);

builder.Services.AddDbContext<AppDbContext>(o => o.UseSqlite($"Data Source={dbPath}"));
builder.Services.AddIdentity<AppUser, IdentityRole>(opt =>
{
    opt.Password.RequiredLength = 8;
    opt.Password.RequireDigit = false;
    opt.Password.RequireLowercase = false;
    opt.Password.RequireUppercase = false;
    opt.Password.RequireNonAlphanumeric = false;
    opt.User.RequireUniqueEmail = false;
})
.AddEntityFrameworkStores<AppDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(o =>
{
    o.Cookie.Name = "sid";
    o.Cookie.HttpOnly = true;
    o.Cookie.SameSite = SameSiteMode.Lax;
    o.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    o.SlidingExpiration = true;
    o.ExpireTimeSpan = TimeSpan.FromHours(12);
    o.Events.OnRedirectToLogin = ctx => { ctx.Response.StatusCode = 401; return Task.CompletedTask; };
    o.Events.OnRedirectToAccessDenied = ctx => { ctx.Response.StatusCode = 403; return Task.CompletedTask; };
});

builder.Services.AddScoped<SiteService>();
builder.Services.AddControllers().AddJsonOptions(o =>
{
    o.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
});
// CORS: доступ с телефона по IP в локальной сети
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.SetIsOriginAllowed(_ => true).AllowAnyHeader().AllowAnyMethod().AllowCredentials()));

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    await db.Database.EnsureCreatedAsync();
    var um = scope.ServiceProvider.GetRequiredService<UserManager<AppUser>>();
    if (!db.Site.Any())
    {
        db.Site.Add(new SiteData
        {
            Id = 1,
            Json = SiteService.DefaultSite().ToJsonString(),
            Updated = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });
        await db.SaveChangesAsync();
    }
    if (!um.Users.Any())
    {
        var admin = new AppUser
        {
            UserName = "admin",
            DisplayName = "admin",
            RoleName = "owner",
            EmailConfirmed = true
        };
        var pw = Environment.GetEnvironmentVariable("ADMIN_PASSWORD") ?? "ChangeMe_Now1";
        var r = await um.CreateAsync(admin, pw);
        if (r.Succeeded)
            Console.WriteLine($"\nСоздан администратор.  Логин: admin   Пароль: {pw}\nСмените пароль после входа!\n");
        else
            Console.WriteLine("Не удалось создать admin: " + string.Join("; ", r.Errors.Select(e => e.Description)));
    }
}

app.Use(async (ctx, next) =>
{
    ctx.Response.Headers["X-Content-Type-Options"] = "nosniff";
    ctx.Response.Headers["X-Frame-Options"] = "DENY";
    ctx.Response.Headers["Referrer-Policy"] = "same-origin";
    await next();
});

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.MapFallbackToFile("index.html");

var port = Environment.GetEnvironmentVariable("PORT") ?? "5000";
app.Urls.Clear();
app.Urls.Add($"http://0.0.0.0:{port}");
Console.WriteLine($"MAJOR CSS v2.0 (ASP.NET Core) → http://localhost:{port}");
app.Run();
