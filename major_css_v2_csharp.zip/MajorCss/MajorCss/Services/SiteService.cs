using System.Text.Json;
using System.Text.Json.Nodes;
using MajorCss.Data;
using MajorCss.Models;
using Microsoft.EntityFrameworkCore;

namespace MajorCss.Services;

public class SiteService
{
    private readonly AppDbContext _db;
    private static readonly JsonSerializerOptions JsonOpts = new() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, WriteIndented = false };

    public SiteService(AppDbContext db) => _db = db;

    public async Task<JsonObject> GetSiteAsync()
    {
        var row = await _db.Site.AsNoTracking().FirstOrDefaultAsync(x => x.Id == 1);
        if (row == null) return DefaultSite();
        try
        {
            var node = JsonNode.Parse(row.Json) as JsonObject;
            return node ?? DefaultSite();
        }
        catch { return DefaultSite(); }
    }

    public async Task PutSiteAsync(JsonObject site)
    {
        var json = site.ToJsonString(JsonOpts);
        var row = await _db.Site.FirstOrDefaultAsync(x => x.Id == 1);
        var now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        if (row == null)
            _db.Site.Add(new SiteData { Id = 1, Json = json, Updated = now });
        else
        {
            row.Json = json;
            row.Updated = now;
        }
        await _db.SaveChangesAsync();
    }

    public static JsonObject DefaultSite()
    {
        var s = new JsonObject
        {
            ["news"] = new JsonArray(),
            ["prizes"] = new JsonArray(),
            ["schedule"] = new JsonArray(),
            ["teams"] = new JsonArray(),
            ["streams"] = new JsonArray(),
            ["partners"] = new JsonArray(),
            ["packages"] = new JsonArray(),
            ["results"] = new JsonObject(),
            ["maps"] = new JsonArray(),
            ["mapsNote"] = "",
            ["donateUrl"] = "",
            ["regOpen"] = true,
            ["regMax"] = 0,
            ["regUntil"] = "",
            ["regAuto"] = true,
            ["cfg"] = new JsonObject
            {
                ["size"] = 64,
                ["format"] = "single",
                ["bo"] = 1,
                ["boSemi"] = 3,
                ["boFinal"] = 3
            },
            ["privOrg"] = "Организатор турнира MAJOR CSS",
            ["privContact"] = "Telegram: @Aleksus_06",
            ["privRetention"] = "Данные хранятся до завершения турнира."
        };
        return s;
    }

    public object RegState(JsonObject site)
    {
        var teams = site["teams"]?.AsArray() ?? new JsonArray();
        var cfg = site["cfg"]?.AsObject();
        var size = cfg?["size"]?.GetValue<int>() ?? 64;
        var regOpen = site["regOpen"]?.GetValue<bool>() ?? true;
        var regMax = site["regMax"]?.GetValue<int>() ?? 0;
        var regUntil = site["regUntil"]?.GetValue<string>() ?? "";
        var left = Math.Max(0, size - teams.Count);
        string? reason = null;
        var open = regOpen;
        if (!regOpen) reason = "closed";
        else if (left <= 0) { open = false; reason = "full"; }
        else if (regMax > 0)
        {
            // cap checked by caller with reg count if needed
        }
        if (!string.IsNullOrEmpty(regUntil) && DateTimeOffset.TryParse(regUntil, out var until) && until < DateTimeOffset.UtcNow)
        { open = false; reason = "expired"; }

        return new { open, left, until = string.IsNullOrEmpty(regUntil) ? null : regUntil, reason, size };
    }

    public List<object> BuildBracket(JsonObject site)
    {
        var cfg = site["cfg"]?.AsObject();
        var size = cfg?["size"]?.GetValue<int>() ?? 64;
        if (size is not (8 or 16 or 32 or 64)) size = 64;
        var teams = (site["teams"]?.AsArray() ?? new JsonArray())
            .Select(t => t?.GetValue<string>())
            .Where(t => !string.IsNullOrEmpty(t))
            .Take(size)
            .ToList()!;
        while (teams.Count < size) teams.Add(null);

        var results = site["results"]?.AsObject() ?? new JsonObject();
        var rounds = new List<object>();
        var cur = teams.Select(t => (string?)t).ToList();
        var r = 0;
        while (cur.Count >= 2)
        {
            var ms = new List<object>();
            var next = new List<string?>();
            for (var i = 0; i < cur.Count; i += 2)
            {
                var a = cur[i];
                var b = i + 1 < cur.Count ? cur[i + 1] : null;
                var key = $"{r}-{i / 2}";
                object? rv = null;
                if (results[key] != null)
                {
                    var node = results[key]!;
                    if (node is JsonObject jo)
                        rv = new { w = jo["w"]?.GetValue<int>() ?? 0, sc = jo["sc"]?.GetValue<string>() };
                    else if (node is JsonValue jv)
                        rv = new { w = jv.GetValue<int>(), sc = (string?)null };
                }
                string? winner = null;
                if (rv != null)
                {
                    dynamic d = rv;
                    int w = d.w;
                    winner = w == 0 ? a : b;
                }
                ms.Add(new { key, a, b, rv, playable = a != null && b != null });
                next.Add(winner);
            }
            rounds.Add(new { n = cur.Count, ms });
            cur = next;
            r++;
        }
        return rounds;
    }

    public static string StageName(int n) => n switch
    {
        2 => "Финал",
        4 => "Полуфинал",
        8 => "Четвертьфинал",
        _ => $"1/{n / 2} финала"
    };

    public async Task NotifyAsync(string userId, string kind, string title, string body = "", string link = "")
    {
        _db.Notifications.Add(new Notification
        {
            UserId = userId,
            Kind = kind,
            Title = title,
            Body = body,
            Link = link,
            Created = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        });
        await _db.SaveChangesAsync();
    }

    public async Task NotifyStaffAsync(string kind, string title, string body, string link = "")
    {
        await NotifyAsync("0", kind, title, body, link);
        var staff = await _db.Users.Where(u => u.RoleName == "staff" && !u.Disabled).Select(u => u.Id).ToListAsync();
        foreach (var id in staff)
            await NotifyAsync(id, kind, title, body, link);
    }

    public async Task AuditAsync(string actor, string role, string action, string target = "", object? detail = null)
    {
        _db.AuditLogs.Add(new AuditLog
        {
            At = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
            Actor = actor,
            Role = role,
            Action = action,
            Target = target,
            Detail = detail is string s ? s : (detail == null ? "" : JsonSerializer.Serialize(detail))
        });
        await _db.SaveChangesAsync();
    }

    public static string Norm(string s) =>
        string.Join(' ', (s ?? "").ToLowerInvariant().Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries));
}
