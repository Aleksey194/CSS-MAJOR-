const menu=document.getElementById('menu'),links=document.getElementById('links');
const setMenu=o=>{links.classList.toggle('open',o);$('admDrop').classList.toggle('open',o);menu.setAttribute('aria-expanded',o);menu.setAttribute('aria-label',o?'Закрыть меню':'Открыть меню');document.body.classList.toggle('menu-open',o)};
menu.addEventListener('click',()=>setMenu(!links.classList.contains('open')));
links.querySelectorAll('a,button').forEach(a=>a.addEventListener('click',()=>setMenu(false)));
document.addEventListener('keydown',e=>{if(e.key==='Escape')setMenu(false)});
document.addEventListener('click',e=>{if(!e.target.closest('header'))setMenu(false)});
if('IntersectionObserver' in window){
  const ladder=document.getElementById('ladder');
  new IntersectionObserver((es,o)=>es.forEach(e=>{if(e.isIntersecting){ladder.classList.add('in');o.disconnect()}}),{threshold:.3}).observe(ladder);
  const map={};links.querySelectorAll('a').forEach(a=>map[a.getAttribute('href').slice(1)]=a);
  const spy=new IntersectionObserver(es=>es.forEach(e=>{const a=map[e.target.id];if(a&&e.isIntersecting){Object.values(map).forEach(x=>x.classList.remove('active'));a.classList.add('active')}}),{rootMargin:'-45% 0px -50% 0px'});
  Object.keys(map).forEach(id=>{const s=document.getElementById(id);if(s)spy.observe(s)});
}else{document.getElementById('ladder').classList.add('in')}

/* Вход админов. ВАЖНО: это проверка на стороне браузера — она скрывает интерфейс, но не защищает данные.
   Для настоящей защиты нужен серверный вход. Хранятся только соли и хэши, паролей в коде нет. */
const SALT="0a06588e2d46623e";
const ADMINS={"admin":"843bcde806b2575aaa46d90ee8231011a1a7172af0d2e7aa6290bd3d2e1d9757"}; /* логин: SHA-256(соль:логин:пароль) */
const $=id=>document.getElementById(id),dlg=$('dlg');
function sha256js(str){
 const rr=(v,a)=>(v>>>a)|(v<<(32-a)),B=[...new TextEncoder().encode(str)],L=B.length*8;
 B.push(128);while(B.length%64!==56)B.push(0);
 B.push(0,0,0,0,(L>>>24)&255,(L>>>16)&255,(L>>>8)&255,L&255);
 const K=[],H=[];
 for(let n=2;K.length<64;n++){let pr=true;for(let d=2;d*d<=n;d++)if(n%d===0){pr=false;break}
  if(pr){if(H.length<8)H.push((Math.pow(n,.5)%1)*4294967296|0);K.push((Math.pow(n,1/3)%1)*4294967296|0)}}
 for(let o=0;o<B.length;o+=64){const w=[];
  for(let i=0;i<64;i++){if(i<16)w[i]=(B[o+i*4]<<24)|(B[o+i*4+1]<<16)|(B[o+i*4+2]<<8)|B[o+i*4+3];
   else{const a=w[i-15],b=w[i-2];w[i]=(w[i-16]+(rr(a,7)^rr(a,18)^(a>>>3))+w[i-7]+(rr(b,17)^rr(b,19)^(b>>>10)))|0}}
  let[a,b,c,d,e,f,g,hh]=H;
  for(let i=0;i<64;i++){const t1=(hh+(rr(e,6)^rr(e,11)^rr(e,25))+((e&f)^(~e&g))+K[i]+w[i])|0,t2=((rr(a,2)^rr(a,13)^rr(a,22))+((a&b)^(a&c)^(b&c)))|0;
   hh=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0}
  [a,b,c,d,e,f,g,hh].forEach((v,i)=>H[i]=(H[i]+v)|0)}
 return H.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('')}
const sha=async s=>{
 try{if(window.crypto&&crypto.subtle)return[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))].map(b=>b.toString(16).padStart(2,'0')).join('')}catch(e){}
 return sha256js(s)};
/* <dialog> для старых телефонов */
const openD=d=>{if(typeof d.showModal==='function')d.showModal();else{d.classList.add('fb');d.setAttribute('open','')}};
const closeD=d=>{if(typeof d.close==='function')d.close();else d.removeAttribute('open')};
function openPrivacy(e){if(e)e.preventDefault();
 if(typeof DATA!=='undefined'&&DATA){$('privOrgTxt').textContent=DATA.privOrg||'Организатор турнира MAJOR CSS';$('privContactTxt').textContent=DATA.privContact||'Telegram: @Aleksus_06';$('privKeepTxt').textContent=DATA.privRetention||'Данные хранятся до завершения турнира'}
 openD($('privDlg'))}
document.querySelectorAll('.privLink').forEach(a=>a.addEventListener('click',openPrivacy));
$('privClose').onclick=()=>closeD($('privDlg'));
if(location.hash==='#privacy')setTimeout(openPrivacy,0);
let fails=0,lockUntil=0;
let MEM=null,DRAFT=null; /* запасное хранение в памяти: в предпросмотре и приватном режиме браузерное хранилище заблокировано */
const safeGet=()=>{if(MEM)return MEM;try{return sessionStorage.getItem('admin')}catch(e){return null}};
const safeSet=v=>{MEM=v||null;try{v?sessionStorage.setItem('admin',v):sessionStorage.removeItem('admin')}catch(e){}};
function render(){const u=safeGet();$('adminbar').hidden=!u;$('who').textContent=u||'';renderAll();$('inbBtn').hidden=!(API&&u);$('bkBtn').hidden=!(API&&u);$('regBtn').hidden=!(API&&u);if(API&&u)loadRegs();
 [$('loginBtn'),$('loginBtn3')].forEach(b=>{b.textContent=u?'Выйти':'Вход для админов'})}
function toggle(){if(safeGet()){logout()}else{$('err').textContent='';openD(dlg);$('u').focus()}}
$('loginBtn').onclick=$('loginBtn3').onclick=()=>{setMenu(false);toggle()};$('logout').onclick=()=>logout();
$('cancel').onclick=()=>closeD(dlg);
async function doLogin(){
 if(Date.now()<lockUntil){$('err').textContent='Слишком много попыток. Подождите '+Math.ceil((lockUntil-Date.now())/1000)+' с.';return}
 if(API){const uu=$('u').value.trim().toLowerCase(),r=await api('/login',{method:'POST',body:{user:uu,pass:$('pw').value}});$('pw').value='';if(r.ok){safeSet(uu);closeD(dlg);render()}else $('err').textContent=r.error||'Неверный логин или пароль.';return}
 let u,hx;try{u=$('u').value.trim().toLowerCase();hx=await sha(SALT+':'+u+':'+$('pw').value)}catch(err){$('err').textContent='Ошибка проверки. Обновите страницу.';return}
 if(ADMINS[u]&&ADMINS[u]===hx){fails=0;safeSet(u);$('pw').value='';closeD(dlg);render()}
 else{fails++;$('pw').value='';$('err').textContent='Неверный логин или пароль.';if(fails>=5){lockUntil=Date.now()+30000;fails=0}}
}
$('loginGo').onclick=doLogin;
[$('u'),$('pw')].forEach(i=>i.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();doLogin()}}));
/* ===== Данные сайта ===== */
let BASE=JSON.parse($('siteData').textContent),API=false,REGS=[],REGST=null;const PKG0=BASE.packages;
const h=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const isAdmin=()=>!!safeGet();
let DATA=BASE;
function loadData(){let d=null;if(isAdmin()&&!API){try{d=JSON.parse(DRAFT||localStorage.getItem('draft'))}catch(e){}}DATA=Object.assign({news:[],prizes:[],schedule:[],teams:[],streams:[],partners:[],results:{}},d||BASE);if(!Array.isArray(DATA.packages))DATA.packages=PKG0;DATA.donateUrl=DATA.donateUrl||'';DATA.regOpen=DATA.regOpen!==false;DATA.regAuto=true;DATA.checkinUntil='';DATA.maps=Array.isArray(DATA.maps)?DATA.maps:[];DATA.mapsNote=DATA.mapsNote||'';DATA.privOrg=DATA.privOrg||'';DATA.privContact=DATA.privContact||'';DATA.privRetention=DATA.privRetention||'';DATA.regMax=+DATA.regMax||0;DATA.regUntil=DATA.regUntil||'';DATA.cfg=Object.assign({size:64,format:'single',bo:1,boSemi:1,boFinal:1},DATA.cfg||{})}
function saveDraft(){if(API){BASE=DATA;api('/data',{method:'PUT',body:DATA}).then(r=>{if(!r.ok)alert('Не удалось сохранить: '+(r.error||r.status));else refreshReg()});return}DRAFT=JSON.stringify(DATA);try{localStorage.setItem('draft',JSON.stringify(DATA))}catch(e){}}


/* ===== Связь с сервером (если сайт запущен через server.js) ===== */
const api=(pth,o={})=>fetch('/api'+pth,{method:o.method||'GET',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:o.body?JSON.stringify(o.body):undefined}).then(async r=>({ok:r.ok,status:r.status,...(await r.json().catch(()=>({})))})).catch(()=>({ok:false,error:'Нет связи с сервером'}));
async function logout(){if(API)await api('/logout',{method:'POST'});safeSet(null);render()}

/* ===== Подписи ===== */
const FMT={single:'Single Elimination',roundrobin:'Round Robin (круговой)'};
const f1=n=>n%10===1&&n%100!==11,f2=n=>n%10>=2&&n%10<=4&&(n%100<10||n%100>=20);
const teamsWord=n=>n+' '+(f1(n)?'команда':f2(n)?'команды':'команд');
const matchWord=n=>n+' '+(f1(n)?'матч':f2(n)?'матча':'матчей');
const stageName=n=>n==2?'Финал':n==4?'Полуфинал':n==8?'Четвертьфинал':'1/'+n/2+' финала';
const boFor=(n,c)=>n==2?c.boFinal:n==4?c.boSemi:c.bo;
const boText=c=>c.format==='single'?`Система турнира — Single Elimination. Матчи играются до ${c.bo==1?'одной карты (BO1)':'победы в серии BO'+c.bo}`+(c.boSemi!=c.bo?`, полуфиналы — BO${c.boSemi}`:'')+(c.boFinal!=c.bo?`, финал — BO${c.boFinal}`:'')+'. Карты и детали — в регламенте.':`Система турнира — Round Robin, матчи в формате BO${c.bo}. Карты и детали — в регламенте.`;
const safeUrl=u=>/^https?:\/\/[^\s]+$/i.test(String(u||''))?u:'';
const resW=rv=>rv==null?null:(typeof rv==='object'?rv.w:rv);

/* ===== Сетки ===== */
function buildBracket(){
 const c=DATA.cfg;let cur=DATA.teams.slice(0,c.size);while(cur.length<c.size)cur.push(null);
 const rounds=[];let r=0;
 while(cur.length>1){const ms=[],next=[];
  for(let i=0;i<cur.length;i+=2){const a=cur[i],b=cur[i+1],rv=DATA.results[r+'-'+(i/2)];
   // Результат только из сохранённых данных. Авто-бай (один соперник пуст) — только в 1-м раунде,
   // иначе победитель «пролетал» до финала, пока второй матч ещё не сыгран.
   let wi=resW(rv);
   if(wi===null&&r===0){if(a&&!b)wi=0;else if(!a&&b)wi=1}
   if(wi!==null&&!(wi?b:a))wi=null;
   next.push(wi===null?null:(wi?b:a));
   ms.push({a,b,wi,sc:(a&&b&&rv&&typeof rv==='object'&&rv.sc)||''})}
  rounds.push({n:cur.length,ms});cur=next;r++}
 return{rounds,champ:cur[0]}}

function renderRR(T,adm){
 const w=T.map(()=>0),pl=T.map(()=>0),ms=[];
 for(let i=0;i<T.length;i++)for(let j=i+1;j<T.length;j++){const rv=DATA.results['rr:'+i+'-'+j],wi=resW(rv);if(wi!==null){pl[i]++;pl[j]++;w[wi?j:i]++}ms.push({i,j,wi,sc:(rv&&rv.sc)||''})}
 const order=T.map((t,i)=>i).sort((a,b)=>w[b]-w[a]||pl[b]-pl[a]||String(T[a]).localeCompare(T[b]));
 const tbl='<div class="bwrap"><table class="rrt"><thead><tr><th>#</th><th>Команда</th><th>И</th><th>В</th><th>П</th></tr></thead><tbody>'+order.map((i,k)=>`<tr><td>${k+1}</td><td>${h(T[i])}</td><td>${pl[i]}</td><td>${w[i]}</td><td>${pl[i]-w[i]}</td></tr>`).join('')+'</tbody></table></div>';
 const bt=(m,s)=>`<button class="bt${m.wi===s?' win':''}" data-rr="${m.i}-${m.j}" data-s="${s}"${adm?'':' disabled'} title="${h(T[s?m.j:m.i])}">${h(T[s?m.j:m.i])}</button>`;
 const scCell=sc=>{if(!sc)return'';const tp=/^т\.?\s*п\.?$|^tp$|тех/i.test(String(sc));return`<div class="sc${tp?' tp':''}">${h(tp?'ТП':sc)}</div>`};
 return (adm?'<p class="note" style="margin:0 0 12px">Нажмите на победителя. Можно указать счёт или поставить техническое поражение сопернику.</p>':'')+tbl+`<details class="rrm"${adm?' open':''}><summary>Матчи (${ms.length}) · BO${DATA.cfg.bo}</summary><div class="rrgrid">`+ms.map(m=>`<div class="bm">${bt(m,0)}${bt(m,1)}${scCell(m.sc)}</div>`).join('')+'</div></details>'}

function renderAll(){
 loadData();const adm=isAdmin(),c=DATA.cfg,T=DATA.teams.slice(0,c.size);
 document.querySelectorAll('[data-t]').forEach(el=>{const k=el.dataset.t;
  el.textContent=k==='teams'?teamsWord(c.size):k==='size'?c.size:k==='fmt'?FMT[c.format]:
  k==='fmtDesc'?(c.format==='single'?'Матчи на выбывание: победитель проходит в следующий раунд.':'Каждая команда играет со всеми остальными. Выше в таблице тот, у кого больше побед.'):
  k==='fmtFaq'?(c.format==='single'?'Система на выбывание: проигравшая команда покидает турнир, победившая играет дальше, пока не определится чемпион.':'Круговая система: каждая команда играет с каждой, чемпионом становится лидер таблицы.'):boText(c)});
 const lad=$('ladder');lad.hidden=c.format!=='single';let L='';
 for(let n=c.size,i=0;n>=2;n/=2,i++)L+=`<li class="rung${n==2?' final':''}" style="--w:${Math.max(n/c.size*100,3.2)};--i:${i}"><span class="rung-name">${stageName(n)}</span><span class="rung-bar"><i></i><b>${n}</b></span><span class="rung-count">${matchWord(n/2)} · BO${boFor(n,c)}</span></li>`;
 lad.innerHTML=L;
 $('ladderNote').textContent=c.format==='single'?`Всего в сетке ${matchWord(c.size-1)}.`:`Всего ${matchWord(c.size*(c.size-1)/2)}: каждая команда играет со всеми.`;
 $('newsList').innerHTML=DATA.news.length?DATA.news.map(n=>`<article><h3>${h(n.title)}</h3><p>${h(n.text)}</p></article>`).join(''):'<p class="note">Пока нет объявлений.</p>';
 $('streamList').innerHTML=DATA.streams.length?DATA.streams.map(s=>{const u=safeUrl(s.url);return `<article><h3>${h(s.title)}</h3><p>${h(s.when||'')}</p>${u?`<a class="btn" href="${h(u)}" target="_blank" rel="noopener noreferrer">Смотреть ↗</a>`:'<p class="note">Ссылка появится позже.</p>'}</article>`}).join(''):'<p class="note">Ссылки на трансляции появятся здесь перед стартом турнира.</p>';
 const pl=$('partnerList');pl.hidden=!DATA.partners.length;pl.innerHTML=DATA.partners.map(x=>{const u=safeUrl(x.url);return u?`<a class="partner" href="${h(u)}" target="_blank" rel="noopener noreferrer sponsored">${h(x.name)}</a>`:`<span class="partner">${h(x.name)}</span>`}).join('');
 $('regBtn').textContent='Приём заявок: '+(DATA.regOpen?'открыт':'закрыт');
 $('donateBtn').href=safeUrl(DATA.donateUrl)||'https://t.me/Aleksus_06';
 const pk=DATA.packages;$('pkgWrap').hidden=!pk.length;
 $('pkgList').innerHTML=pk.map((x,i)=>`<article class="pkg${pk.length>1&&i===pk.length-1?' top':''}"><h4>${h(x.name)}</h4><div class="price">${h(x.price)}</div><ul>${String(x.perks||'').split(';').map(s=>s.trim()).filter(Boolean).map(s=>`<li>${h(s)}</li>`).join('')}</ul><a class="btn" href="https://t.me/Aleksus_06" target="_blank" rel="noopener">Стать партнёром ↗</a></article>`).join('');
 $('mapList').innerHTML=DATA.maps.length?DATA.maps.map(x=>`<div class="map">${h(x.name)}${x.note?`<small>${h(x.note)}</small>`:''}</div>`).join(''):'<p class="note" style="margin:0;grid-column:1/-1">Карты будут объявлены организаторами.</p>';
 $('mapsNote').hidden=!DATA.mapsNote;$('mapsNote').textContent=DATA.mapsNote||'';
 $('prizeList').innerHTML=DATA.prizes.map(x=>`<li><span>${h(x.place)}</span><span>${h(x.sum)}</span></li>`).join('');
 $('prizeNote').hidden=DATA.prizes.length>0;
 $('schedList').innerHTML=DATA.schedule.map(x=>`<li><span>${h(x.stage)}</span><span>${h(x.when)}</span></li>`).join('');
 $('teamCount').textContent=T.length?`В сетке команд: ${T.length} из ${c.size}.`+(adm&&DATA.teams.length>c.size?` Лишние (${DATA.teams.length-c.size}) в сетку не попадут.`:''):'Список появится после подтверждения участников.';
 $('teamList').innerHTML=T.map((x,i)=>`<div class="team"><b>${i+1}</b><span>${h(x)}</span></div>`).join('');
 const box=$('bracketBox');
 if(T.length<2){box.innerHTML='<div class="notice"><div><strong>Сетка и расписание матчей</strong><br>Появятся на этой странице после подтверждения списка участников.</div></div>';return}
 if(c.format==='roundrobin'){box.innerHTML=renderRR(T,adm);return}
 const B=buildBracket();
 const scHtml=sc=>{if(!sc)return'';const tp=/^т\.?\s*п\.?$|^tp$|тех/i.test(String(sc));return`<div class="sc${tp?' tp':''}">${h(tp?'ТП':sc)}</div>`};
 const mkBt=(tm,s,r,i)=>`<button class="bt${tm?'':' empty'}${B.rounds[r].ms[i].wi===s?' win':''}" data-r="${r}" data-m="${i}" data-s="${s}"${adm&&tm&&B.rounds[r].ms[i].a&&B.rounds[r].ms[i].b?'':' disabled'}${tm?` title="${h(tm)}"`:''}>${tm?h(tm):'—'}</button>`;
 const desk='<div class="bwrap bdesk">'+B.rounds.map((R,r)=>`<div class="bcol"><h3>${stageName(R.n)} · BO${boFor(R.n,c)}</h3><div class="bms">`+R.ms.map((m,i)=>`<div class="bm">${mkBt(m.a,0,r,i)}${mkBt(m.b,1,r,i)}${scHtml(m.sc)}</div>`).join('')+'</div></div>').join('')+
  `<div class="champ"><small>Чемпион</small>${B.champ?h(B.champ):'Определится в финале'}</div></div>`;
 // На телефоне — раунды аккордеоном (не огромная горизонтальная/вертикальная сетка)
 const openIdx=B.rounds.findIndex(R=>R.ms.some(m=>m.a&&m.b&&m.wi===null));
 const mob='<div class="bmob">'+B.rounds.map((R,r)=>{
   const done=R.ms.filter(m=>m.wi!==null).length,total=R.ms.length,isOpen=r===(openIdx>=0?openIdx:B.rounds.length-1);
   return `<details class="bmob-round"${isOpen?' open':''}><summary>${stageName(R.n)} · BO${boFor(R.n,c)} <span>${done}/${total}</span></summary><div class="bmob-list">`+
    R.ms.map((m,i)=>`<div class="bm">${mkBt(m.a,0,r,i)}${mkBt(m.b,1,r,i)}${scHtml(m.sc)}</div>`).join('')+
    '</div></details>'}).join('')+
  `<div class="bmob-champ"><small>Чемпион</small>${B.champ?h(B.champ):'Определится в финале'}</div></div>`;
 box.innerHTML=(adm?'<p class="note" style="margin:0 0 12px">Нажмите на победителя матча. Можно указать счёт или поставить техническое поражение сопернику. Повторное нажатие снимает результат.</p>':'')+desk+mob}

let pendingMatch=null;
function applyMatchResult(k,s,sc,r,m){
 DATA.results[k]=sc?{w:s,sc}:{w:s};
 if(r!==undefined){let mm=m;for(let q=r+1;q<8;q++){mm>>=1;delete DATA.results[q+'-'+mm]}}
 saveDraft();renderAll()}
function openMatchDlg(winnerName,loserName,k,s,r,m){
 pendingMatch={k,s,r,m};
 $('msInfo').innerHTML='Победитель: <strong style="color:#fff">'+h(winnerName)+'</strong>'+(loserName?'<br>Соперник: '+h(loserName):'');
 $('msScore').value='';
 openD($('msDlg'));
 setTimeout(()=>{try{$('msScore').focus()}catch(e){}},50)}
$('msCancel').onclick=()=>{pendingMatch=null;closeD($('msDlg'))};
$('msOk').onclick=()=>{if(!pendingMatch)return;const{k,s,r,m}=pendingMatch;const sc=($('msScore').value||'').trim().slice(0,12);pendingMatch=null;closeD($('msDlg'));applyMatchResult(k,s,sc,r,m)};
$('msTP').onclick=()=>{if(!pendingMatch)return;const{k,s,r,m}=pendingMatch;pendingMatch=null;closeD($('msDlg'));applyMatchResult(k,s,'ТП',r,m)};
$('msScore').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('msOk').click()}});

$('bracketBox').addEventListener('click',e=>{
 const b=e.target.closest('.bt');if(!b||b.disabled||!isAdmin())return;
 const s=+b.dataset.s;let k,r,m,winnerName=b.textContent.trim(),loserName='';
 if(b.dataset.rr){
  k='rr:'+b.dataset.rr;
  const parts=b.dataset.rr.split('-'),i=+parts[0],j=+parts[1],T=DATA.teams.slice(0,DATA.cfg.size);
  winnerName=T[s?j:i]||winnerName;loserName=T[s?i:j]||'';
 }else{
  r=+b.dataset.r;m=+b.dataset.m;k=r+'-'+m;
  const B=buildBracket(),match=B.rounds[r]&&B.rounds[r].ms[m];
  if(match){winnerName=(s?match.b:match.a)||winnerName;loserName=(s?match.a:match.b)||''}
 }
 if(resW(DATA.results[k])===s){delete DATA.results[k];if(r!==undefined){let mm=m;for(let q=r+1;q<8;q++){mm>>=1;delete DATA.results[q+'-'+mm]}}saveDraft();renderAll();return}
 openMatchDlg(winnerName,loserName,k,s,r,m)});

/* ===== Редактор ===== */
const ed=$('edDlg'),inb=$('inbDlg'),lines=s=>s.split('\n').map(x=>x.trim()).filter(Boolean),pair=l=>{const i=l.indexOf('|');return i<0?[l,'']:[l.slice(0,i).trim(),l.slice(i+1).trim()]};
$('editBtn').onclick=()=>{const c=DATA.cfg;
 $('edRegOpen').value=DATA.regOpen?'1':'0';$('edRegMax').value=DATA.regMax||0;
 $('edRegUntil').value=fmtRuDate(DATA.regUntil);
 $('edMaps').value=DATA.maps.map(x=>[x.name,x.note].join(' | ')).join('\n');$('edMapsNote').value=DATA.mapsNote;$('edPrivOrg').value=DATA.privOrg;$('edPrivContact').value=DATA.privContact;$('edPrivKeep').value=DATA.privRetention;
 $('edSize').value=c.size;$('edFmt').value=c.format;$('edBo').value=c.bo;$('edBoSemi').value=c.boSemi;$('edBoFinal').value=c.boFinal;
 $('edNews').value=DATA.news.map(n=>n.title+' | '+n.text).join('\n');
 $('edPrizes').value=DATA.prizes.map(x=>x.place+' | '+x.sum).join('\n');
 $('edSched').value=DATA.schedule.map(x=>x.stage+' | '+x.when).join('\n');
 $('edStreams').value=DATA.streams.map(s=>[s.title,s.url,s.when].join(' | ')).join('\n');
 $('edPartners').value=DATA.partners.map(x=>[x.name,x.url].join(' | ')).join('\n');
 $('edPkgs').value=DATA.packages.map(x=>[x.name,x.price,x.perks].join(' | ')).join('\n');
 $('edDonate').value=DATA.donateUrl||'';
 $('edTeams').value=DATA.teams.join('\n');openD(ed)};
$('edSave').onclick=()=>{
 const c={size:+$('edSize').value,format:$('edFmt').value,bo:+$('edBo').value,boSemi:+$('edBoSemi').value,boFinal:+$('edBoFinal').value};
 if(c.format==='roundrobin'&&c.size>16){alert('Круговой формат доступен для 8 и 16 команд.');return}
 const teams=lines($('edTeams').value).slice(0,64),was=JSON.stringify([DATA.teams,DATA.cfg.size,DATA.cfg.format]);
 DATA.news=lines($('edNews').value).map(l=>{const[a,b]=pair(l);return{title:a,text:b}});
 DATA.prizes=lines($('edPrizes').value).map(l=>{const[a,b]=pair(l);return{place:a,sum:b}});
 DATA.schedule=lines($('edSched').value).map(l=>{const[a,b]=pair(l);return{stage:a,when:b}});
 const parts=l=>l.split('|').map(x=>x.trim());
 DATA.streams=lines($('edStreams').value).map(l=>{const a=parts(l);return{title:a[0],url:a[1]||'',when:a[2]||''}});
 DATA.partners=lines($('edPartners').value).map(l=>{const a=parts(l);return{name:a[0],url:a[1]||''}});
 DATA.packages=lines($('edPkgs').value).map(l=>{const a=parts(l);return{name:a[0],price:a[1]||'',perks:a[2]||''}});
 DATA.donateUrl=$('edDonate').value.trim();
 DATA.maps=lines($('edMaps').value).map(l=>{const a=parts(l);return{name:a[0],note:a[1]||''}}).filter(x=>x.name);DATA.mapsNote=$('edMapsNote').value.trim();DATA.regAuto=true;DATA.checkinUntil='';DATA.privOrg=$('edPrivOrg').value.trim();DATA.privContact=$('edPrivContact').value.trim();DATA.privRetention=$('edPrivKeep').value.trim();
 DATA.regOpen=$('edRegOpen').value==='1';DATA.regMax=Math.max(0,parseInt($('edRegMax').value,10)||0);DATA.regUntil=parseRuDate($('edRegUntil').value)
 DATA.teams=teams;if(JSON.stringify([teams,c.size,c.format])!==was)DATA.results={};
 DATA.cfg=c;saveDraft();renderAll();closeD(ed)};
$('edClose').onclick=()=>closeD(ed);
$('edReset').onclick=()=>{DRAFT=null;try{localStorage.removeItem('draft')}catch(e){}closeD(ed);renderAll()};
$('edDl').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(DATA)],{type:'application/json'}));a.download='site-data.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};

/* ===== Приём заявок: состояние ===== */
function renderReg(){
 const r=REGST;if(!API||!r)return;
 $('regForm').hidden=!r.open||!$('regDone').hidden;$('regClosed').hidden=r.open;
 if(!r.open)$('regClosed').querySelector('span').textContent={closed:'Приём заявок закрыт.',full:'Приём заявок закрыт: сетка заполнена, свободных мест нет.',cap:'Приём заявок закрыт: набрано максимальное число заявок.',expired:'Приём заявок завершён.'}[r.reason]||'Приём заявок закрыт.';
 $('regInfo').textContent=r.open?[r.left!=null?'Свободных мест в сетке: '+r.left+'.':'',r.until?'Приём до '+new Date(r.until).toLocaleString('ru-RU',{dateStyle:'long',timeStyle:'short'})+'.':''].filter(Boolean).join(' '):'';
}
const toLocal=iso=>{const d=iso?new Date(iso):null,q=n=>String(n).padStart(2,'0');return d&&!isNaN(d)?`${d.getFullYear()}-${q(d.getMonth()+1)}-${q(d.getDate())}T${q(d.getHours())}:${q(d.getMinutes())}`:''};
const fromLocal=v=>{const d=v?new Date(v):null;return d&&!isNaN(d)?d.toISOString():''};
const fmtRuDate=iso=>{const d=iso?new Date(iso):null,q=n=>String(n).padStart(2,'0');return d&&!isNaN(d)?`${q(d.getDate())}.${q(d.getMonth()+1)}.${d.getFullYear()} ${q(d.getHours())}:${q(d.getMinutes())}`:''};
const parseRuDate=v=>{
 v=String(v||'').trim();if(!v)return'';
 let m=v.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})(?:[ T](\d{1,2}):(\d{2}))?$/);
 if(m){const d=new Date(+m[3],+m[2]-1,+m[1],+(m[4]||0),+(m[5]||0));return isNaN(d)? '':d.toISOString()}
 const d=new Date(v);return isNaN(d)?'':d.toISOString()
};
async function pullSite(){const d=await api('/data');if(d.ok&&d.site){BASE=d.site;REGST=d.reg||null;renderReg();renderAll()}}
function showDone(r){
 $('rdTitle').textContent=r.status==='accepted'?'Команда принята в турнир':'Заявка отправлена';
 $('rdText').textContent=r.status==='accepted'?'Место в сетке закреплено автоматически. Дополнительно ничего делать не нужно — вы зарегистрированы.':'Заявка получена.';
 $('rdLink').parentElement.hidden=true;
 $('regDone').hidden=false;$('regForm').hidden=true;$('regDone').scrollIntoView({behavior:'smooth',block:'center'})}
$('rdCopy').onclick=async()=>{try{await navigator.clipboard.writeText($('rdLink').value);$('rdCopy').textContent='Скопировано'}catch(e){$('rdLink').select()}};
async function refreshReg(){const d=await api('/data');if(d.ok){REGST=d.reg||null;renderReg()}}
$('regBtn').onclick=()=>{DATA.regOpen=!DATA.regOpen;saveDraft();renderAll()};

/* ===== Защита формы от ботов: небольшая вычислительная задача (proof-of-work) ===== */
const K256=new Int32Array(64),H256=new Int32Array(8),W256=new Int32Array(64);
(()=>{let n=2,c=0,d=0;while(c<64){let pr=1;for(let i=2;i*i<=n;i++)if(n%i===0){pr=0;break}if(pr){K256[c++]=(Math.pow(n,1/3)%1)*4294967296|0;if(d<8)H256[d++]=(Math.pow(n,.5)%1)*4294967296|0}n++}})();
function h0(B){ /* один блок SHA-256, возвращает первые 32 бита хэша */
 for(let i=0;i<16;i++)W256[i]=(B[i*4]<<24)|(B[i*4+1]<<16)|(B[i*4+2]<<8)|B[i*4+3];
 for(let i=16;i<64;i++){const a=W256[i-15],b=W256[i-2];W256[i]=(W256[i-16]+((a>>>7|a<<25)^(a>>>18|a<<14)^(a>>>3))+W256[i-7]+((b>>>17|b<<15)^(b>>>19|b<<13)^(b>>>10)))|0}
 let a=H256[0],b=H256[1],c=H256[2],d=H256[3],e=H256[4],f=H256[5],g=H256[6],h=H256[7];
 for(let i=0;i<64;i++){const t1=(h+((e>>>6|e<<26)^(e>>>11|e<<21)^(e>>>25|e<<7))+((e&f)^(~e&g))+K256[i]+W256[i])|0,t2=(((a>>>2|a<<30)^(a>>>13|a<<19)^(a>>>22|a<<10))+((a&b)^(a&c)^(b&c)))|0;h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0}
 return(H256[0]+a)|0}
function solvePow(nonce,bits){return new Promise(res=>{
 const pre=new TextEncoder().encode(nonce+':'),B=new Uint8Array(64);let n=0;
 const step=()=>{const t=performance.now();
  while(performance.now()-t<12){
   B.fill(0,pre.length);B.set(pre);const s=String(n),len=pre.length+s.length;
   for(let i=0;i<s.length;i++)B[pre.length+i]=s.charCodeAt(i);
   B[len]=128;const L=len*8;B[62]=(L>>8)&255;B[63]=L&255;
   if(Math.clz32(h0(B))>=bits){res(n);return}
   n++}
  setTimeout(step,0)};
 step()})}
let POWP=null;
function prepPow(){POWP=(async()=>{
 const c=await api('/challenge');if(!c.ok)return{err:c.error||'Не удалось получить задачу защиты.'};
 const t0=Date.now(),counter=await solvePow(c.nonce,c.bits),wait=3200-(Date.now()-t0);
 if(wait>0)await new Promise(r=>setTimeout(r,wait));
 return{token:c.token,counter}})()}
['rTeam','rCap','rContact','rRoster'].forEach(i=>$(i).addEventListener('focus',()=>{if(!POWP)prepPow()}));

/* ===== Заявки ===== */
const stLabel=s=>s==='accepted'?'Принята':s==='rejected'?'Отклонена':(DATA.regAuto?'В очереди':'Ждёт проверки');
function renderInbox(){$('inbList').innerHTML=REGS.length?REGS.map(r=>`<div class="reg"><div><strong>${h(r.team)}</strong> <span class="st ${h(r.status)}">${stLabel(r.status)}</span> <span class="st ${r.confirmed?'cf':''}">${r.confirmed?'✓ Капитан подтвердил':'Ждёт подтверждения'}</span></div><div>Капитан: ${h(r.captain)} · ${h(r.contact)}</div>${r.roster?`<pre>${h(r.roster)}</pre>`:''}<small class="hint">${new Date(r.at).toLocaleString('ru-RU')}</small><div class="acts"><button class="linkbtn" data-a="ok" data-id="${h(r.id)}">Принять</button><button class="linkbtn" data-a="no" data-id="${h(r.id)}">Отклонить</button>${r.confirmed?'':`<button class="linkbtn" data-a="link" data-id="${h(r.id)}">Ссылка подтверждения</button>`}<button class="linkbtn" data-a="del" data-id="${h(r.id)}">Удалить</button></div></div>`).join(''):'<p class="hint">Заявок пока нет. Как только команды начнут регистрироваться — они появятся здесь.</p>'}
async function loadRegs(){const r=await api('/registrations');if(r.ok){REGS=r.items||[];const n=REGS.filter(x=>x.status==='new').length;$('inbN').textContent=n?'('+n+')':'';renderInbox()}}
$('inbBtn').onclick=()=>{loadRegs();openD(inb)};
$('inbPurge').onclick=async()=>{if(!confirm('Удалить ВСЕ заявки с контактами игроков? Команды в сетке останутся. Действие нельзя отменить.'))return;await api('/registrations',{method:'DELETE'});loadRegs()};
$('inbClose').onclick=()=>closeD(inb);
$('inbList').addEventListener('click',async e=>{
 const b=e.target.closest('button[data-a]');if(!b)return;const id=b.dataset.id,a=b.dataset.a,r=REGS.find(x=>x.id===id);
 if(a==='del'){if(!confirm('Удалить заявку?'))return;await api('/registrations/'+id,{method:'DELETE'})}
 else if(a==='link'){const l=location.origin+location.pathname+'?confirm='+r.ctoken;try{await navigator.clipboard.writeText(l);b.textContent='Ссылка скопирована'}catch(x){prompt('Скопируйте ссылку и отправьте капитану на его контакт:',l)}return}
 else{if(a==='ok'&&r&&!r.confirmed&&!confirm('Капитан ещё не подтвердил участие. Принять всё равно?'))return;
  const x=await api('/registrations/'+id,{method:'PATCH',body:{status:a==='ok'?'accepted':'rejected'}});if(!x.ok)alert(x.error||'Не удалось выполнить действие.')}
 loadRegs();pullSite()});
$('rGo').onclick=async()=>{const m=$('rMsg');m.textContent='';
 const body={team:$('rTeam').value.trim(),captain:$('rCap').value.trim(),contact:$('rContact').value.trim(),roster:$('rRoster').value.trim(),web:$('rWeb').value};
 if(body.team.length<2||!body.captain){m.textContent='Заполните название команды и имя капитана.';return}
 if(!$('rOk').checked){m.textContent='Нужно согласие на обработку данных.';return}
 body.consent=true;
 $('rGo').disabled=true;m.textContent='Проверка защиты…';
 if(!POWP)prepPow();const pw=await POWP;POWP=null;
 if(pw.err){$('rGo').disabled=false;m.textContent=pw.err;return}
 body.pow={token:pw.token,counter:pw.counter};m.textContent='';
 const r=await api('/register',{method:'POST',body});$('rGo').disabled=false;if(r.ok)pullSite();else if(r.status!==429)refreshReg();
 if(r.ok){m.textContent='';showDone(r);['rTeam','rCap','rContact','rRoster'].forEach(i=>$(i).value='');$('rOk').checked=false}else m.textContent=r.error||'Не удалось отправить заявку.'};

async function checkConfirm(){
 const t=new URLSearchParams(location.search).get('confirm');if(!t||!API||!/^[a-f0-9]{32}$/.test(t))return;
 const r=await api('/confirm?token='+t),box=$('cfTxt'),yes=$('cfYes');
 if(!r.ok){box.textContent=r.error||'Ссылка недействительна.';yes.hidden=true}
 else if(r.confirmed){box.textContent='Участие команды «'+r.team+'» уже подтверждено. Спасибо!';yes.hidden=true}
 else{box.textContent='Вы подтверждаете, что вы капитан команды «'+r.team+'» и команда участвует в турнире.';yes.hidden=false;
  yes.onclick=async()=>{yes.disabled=true;const x=await api('/confirm',{method:'POST',body:{token:t}});
   if(x.ok){box.textContent='Участие подтверждено. Спасибо! Организаторы получили ваше подтверждение.';yes.hidden=true;history.replaceState(null,'',location.pathname)}
   else{$('cfMsg').textContent=x.error||'Не удалось подтвердить.';yes.disabled=false}}}
 openD($('cfDlg'))}
$('cfNo').onclick=()=>closeD($('cfDlg'));
async function init(){
 try{const r=await fetch('/api/ping');API=r.ok&&(await r.json()).ok===true}catch(e){API=false}
 if(API){const d=await api('/data');if(d.ok&&d.site)BASE=d.site;REGST=d.reg||null;const m=await api('/me');safeSet(m.user||null);
  $('register').hidden=false;renderReg();$('applyNote').hidden=true;$('applyBtn').href='#register';$('applyBtn').removeAttribute('target');$('applyBtn').textContent='Подать заявку';
  $('abNote').textContent='изменения сохраняются на сервере сразу';$('applyTxt').textContent='Заполните форму ниже. При свободном месте заявка принимается автоматически.';$('edHint').textContent='Изменения сохраняются на сервере и сразу видны всем посетителям.'}
 render();checkConfirm()}

init();
