#!/bin/bash
set -e
export PATH="$HOME/.dotnet:$PATH:/usr/share/dotnet:$PATH"
cd "$(dirname "$0")/MajorCss"
mkdir -p data
echo "MAJOR CSS v2.0 → http://localhost:${PORT:-5000}"
PORT="${PORT:-5000}" ADMIN_PASSWORD="${ADMIN_PASSWORD:-ChangeMe_Now1}" dotnet run
